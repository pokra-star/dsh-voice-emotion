@echo off
chcp 65001 >nul
setlocal
set "URL=http://127.0.0.1:3135"

rem 已经有服务就直接开页面
curl -s -o nul --max-time 1 "%URL%/api/ping" && (
  start "" "%URL%"
  exit /b 0
)

set "NODE=node"
where node >nul 2>&1
if errorlevel 1 if exist "%ProgramFiles%\nodejs\node.exe" set "NODE=%ProgramFiles%\nodejs\node.exe"

if not exist "%NODE%" if not exist "%NODE%.exe" (
  echo 找不到 node，没法起控制台。
  echo 也可以在 DSH 里输入 /voice-ui。
  pause
  exit /b 1
)

start "voice-ui" /min "%NODE%" "%~dp0ui\server.mjs"
timeout /t 2 /nobreak >nul
start "" "%URL%"
exit /b 0
