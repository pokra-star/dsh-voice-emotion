﻿param([string]$Version = '0.3.16')
# 打 full 包：一个安装文件（安装.exe，带图标）+ 宣传图 + 说明，其余收进 app\。
# 用法：powershell -ExecutionPolicy Bypass -File tools\build-full.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$pkg = Get-Content (Join-Path $root 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($pkg.version -ne $Version) { throw "package.json 是 $($pkg.version)，和 -Version $Version 不一致" }

$stage = Join-Path $root 'tmp\full-build'
$top = Join-Path $stage "语音情绪插件-$Version-full"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
$app = Join-Path $top 'app'
New-Item -ItemType Directory -Path $app -Force | Out-Null

$items = @(
  'index.js', 'package.json', 'cordis.patch.yml', 'profiles.json',
  'README.md', 'README.detail.md', 'LICENSE', '.gitignore',
  'model-embed.onnx', 'model-neg.json', 'model-v2.json',
  'assets', 'lib', 'python', 'tools', '_installer'
)
foreach ($i in $items) {
  $src = Join-Path $root $i
  if (-not (Test-Path $src)) { throw "缺文件：$i" }
  Copy-Item $src -Destination $app -Recurse -Force
}

# 自带的 whisper-small：优先包根 models，其次本机缓存
New-Item -ItemType Directory -Path (Join-Path $app 'models') -Force | Out-Null
$modelSrc = Join-Path $root 'models'
if (-not (Test-Path (Join-Path $modelSrc 'faster-whisper-small'))) {
  $modelSrc = Join-Path $env:USERPROFILE '.dsh-voice-emotion\models'
}
if (-not (Test-Path (Join-Path $modelSrc 'faster-whisper-small'))) { throw '缺 faster-whisper-small（包根 models 或 %USERPROFILE%\.dsh-voice-emotion\models）' }
Copy-Item (Join-Path $modelSrc 'faster-whisper-small') (Join-Path $app 'models') -Recurse -Force

$promo = Join-Path $root '..\..\docs\语音情绪-一页说明.png'
if (-not (Test-Path $promo)) { throw "缺宣传图：$promo" }
Copy-Item $promo (Join-Path $top '宣传图.png') -Force

$icon = Join-Path $root 'assets\icon.ico'
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path $csc)) { $csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (-not (Test-Path $csc)) { throw '找不到 csc.exe（.NET Framework 4）' }
$exe = Join-Path $top '安装.exe'
& $csc /nologo /target:winexe /codepage:65001 "/win32icon:$icon" /r:System.Windows.Forms.dll "/out:$exe" (Join-Path $root '_installer\launcher.cs')
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $exe)) { throw '编译安装器失败' }

$note = @"
dsh-voice-emotion $Version —— 装之前先看这几行
====================================================
1. 先解压，再双击「安装.exe」。只有一个安装文件，图标是那道白色声波。
   它会检查 Python 3.10+ / Node / DSH，自己在界面上把依赖装好、登记进 DSH。
   没有 Python 的话，界面会给出 winget 命令，复制到 PowerShell 跑一遍就行。
2. 如果 Windows 弹「Windows 已保护你的电脑」，点「更多信息 → 仍要运行」。
   这是本地编译的安装器，没买签名，不是病毒。
3. 它「会听」，但不自带发声引擎。voice_speak 要一个能 POST /speak 的 TTS 服务，
   默认 http://127.0.0.1:3120；没有 TTS 不影响「听」。
4. 装完重启 DSH（或热重载插件）。解压出来的 app 文件夹不要改名、不要拆开。
5. 宣传图.png 就是一页说明，发给别人看的那张。
"@
[IO.File]::WriteAllText((Join-Path $top '安装说明.txt'), $note, (New-Object Text.UTF8Encoding($true)))

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
$zip = Join-Path $dist "dsh-voice-emotion-$Version-full.zip"
if (Test-Path $zip) {
  $bak = Join-Path $root 'tmp\dist-backup'
  New-Item -ItemType Directory -Path $bak -Force | Out-Null
  Move-Item $zip (Join-Path $bak ("dsh-voice-emotion-$Version-full.zip." + (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($top, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)

$z = [IO.Compression.ZipFile]::OpenRead($zip)
try { $n = $z.Entries.Count } finally { $z.Dispose() }
Write-Host ("ok: {0}  ({1:N0} MB, {2} entries)" -f $zip, ((Get-Item $zip).Length / 1MB), $n)
Write-Host "staging: $top"
