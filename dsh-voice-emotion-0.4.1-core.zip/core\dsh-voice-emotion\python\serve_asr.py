"""常驻转写服务（端口 3133）。

为什么要它：`asr_local.py` 是「一条语音起一个进程」，每次都要把 faster-whisper
的模型从磁盘读回来（small 约 10~15 秒）。常驻以后模型只加载一次，之后每条 1~2 秒。

    python serve_asr.py --port 3133 [--model C:\\path\\to\\faster-whisper-small]

接口：
    GET  /health   -> {"ok": true, "model": "...", "pid": 123}
    POST /asr      -> {"path": "C:/x.wav"}  =>  {"ok": true, "text": "...", "seconds": 1.23}
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
HOME = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
DEFAULT_MODEL = HOME / "models" / "faster-whisper-small"
FALLBACK_MODEL = HOME / "models" / "faster-whisper-base"
PARAFORMER_DIR = Path(os.environ.get("PARAFORMER_DIR", str(HOME / "models" / "paraformer-zh")))

_model = None
_model_dir = ""
_funasr = None
_lock = threading.Lock()


def _patch_av() -> None:
    """faster-whisper 给 av.open 传了 metadata_errors，PyAV 19 已删除该参数。"""
    try:
        import av  # type: ignore

        original = av.open

        def open_compat(*args, **kwargs):  # noqa: ANN001
            kwargs.pop("metadata_errors", None)
            return original(*args, **kwargs)

        av.open = open_compat  # type: ignore[assignment]
    except Exception:  # noqa: BLE001
        pass


def _pick_model(explicit: str = "") -> Path:
    if explicit:
        return Path(explicit)
    if DEFAULT_MODEL.exists():
        return DEFAULT_MODEL
    return FALLBACK_MODEL


def load_funasr() -> bool:
    """优先用 FunASR paraformer-zh（本地 848MB）。失败返回 False，回落 whisper。"""
    global _funasr, _model_dir
    if not (PARAFORMER_DIR / "model.pt").exists():
        return False
    try:
        from funasr import AutoModel  # type: ignore
    except Exception:  # noqa: BLE001
        return False
    try:
        _funasr = AutoModel(
            model=str(PARAFORMER_DIR),
            device="cpu",
            disable_update=True,
            disable_pbar=True,
            disable_log=True,
        )
        _model_dir = f"funasr:{PARAFORMER_DIR.name}"
        print(f"[serve_asr] funasr paraformer-zh 已加载：{PARAFORMER_DIR}", flush=True)
        return True
    except Exception as e:  # noqa: BLE001
        print(f"[serve_asr] funasr 加载失败，回落 whisper：{e}", flush=True)
        _funasr = None
        return False


def load(model_dir: Path) -> None:
    global _model, _model_dir
    _patch_av()
    from faster_whisper import WhisperModel

    _model = WhisperModel(str(model_dir), device="cpu", compute_type="int8", cpu_threads=8, num_workers=1)
    _model_dir = str(model_dir)


def transcribe(path: str) -> dict:
    if _funasr is not None:
        t0 = time.time()
        try:
            r = _funasr.generate(input=str(path), batch_size_s=0, use_itn=True)
            text = ""
            if isinstance(r, list) and r:
                text = (r[0] or {}).get("text", "") or ""
            return {
                "ok": True,
                "text": text.strip(),
                "language": "zh",
                "seconds": round(time.time() - t0, 2),
                "model": _model_dir,
            }
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"funasr: {type(e).__name__}: {e}", "model": _model_dir}
    if _model is None:
        return {"ok": False, "error": "模型还没加载好"}
    t0 = time.time()
    with _lock:  # faster-whisper 的内部状态不是线程安全的
        segments, info = _model.transcribe(
            path,
            language="zh",  # 强制中文：不指定语言时 whisper 会对糊音频猜成日语并整段幻觉
        vad_filter=True,
            beam_size=5, condition_on_previous_text=False,
            initial_prompt=('以下是普通话的日常聊天，可能有错别字。常见词：男闺蜜、闺蜜、前任、对象、直播、弹幕、插件、账号、语音、模型、训练、数据集、情绪、语气。'),
        )
        text = "".join(seg.text for seg in segments).strip()
        _HALLU = ("点赞", "订阅", "打赏", "明镜", "栏目", "字幕由", "字幕提供", "感谢观看", "请不吝")
        if not text or any(h in text for h in _HALLU):
            # 糊音频上 whisper 会整段编造字幕组的推广语；宁可返回空让上游知道没听清
            text = ""

    return {
        "ok": True,
        "text": text,
        "language": getattr(info, "language", ""),
        "seconds": round(time.time() - t0, 2),
        "model": _model_dir,
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def _send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/health"):
            self._send(200, {"ok": True, "model": _model_dir, "pid": os.getpid()})
        else:
            self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self.path.startswith("/asr"):
            self._send(404, {"ok": False, "error": "not found"})
            return
        try:
            length = int(self.headers.get("content-length") or 0)
            payload = json.loads(self.rfile.read(length) or b"{}")
        except Exception as error:  # noqa: BLE001
            self._send(400, {"ok": False, "error": f"请求体不是 JSON：{error}"})
            return
        path = str(payload.get("path") or "").strip()
        if not path or not Path(path).exists():
            self._send(400, {"ok": False, "error": f"文件不存在：{path}"})
            return
        try:
            self._send(200, transcribe(path))
        except Exception as error:  # noqa: BLE001
            self._send(500, {"ok": False, "error": f"{type(error).__name__}: {error}"})

    def log_message(self, fmt: str, *args) -> None:  # noqa: A003
        sys.stderr.write("[asr] " + fmt % args + "\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=3133)
    parser.add_argument("--model", default="")
    args = parser.parse_args()

    t0 = time.time()
    if not args.model and load_funasr():
        print(f"[asr] funasr 就绪（{time.time() - t0:.1f}s），端口 {args.port}", flush=True)
    else:
        target = _pick_model(args.model)
        if not target.exists():
            print(f"[asr] 没有模型目录：{target}", flush=True)
            return 2
        load(target)
        print(f"[asr] 模型已加载 {target}（{time.time() - t0:.1f}s），端口 {args.port}", flush=True)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())



