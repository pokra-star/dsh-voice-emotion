"""把 emotion2vec_plus_large 的 encoder 导出成 ONNX（wav → 1024 维整句向量）。

2026-11-09 定稿的做法：
  - 用 dynamo 导出器（`dynamo=True`）：老 tracer 会把 alibi bias 的尺寸烘进图里，
    换个时长就 `Reshape` 失败；dynamo 出来的图是长度无关的。
  - 导出后合并成**单文件**（默认会被拆成 .onnx + .onnx.data）。
  - 必须装 `onnxscript`（dynamo 导出器依赖它）。
  - 顺便验证：与 torch 逐条比对 cosine、比 speed、比下游 4 类的标签是否一致。

用法：
    python tools/export_onnx.py [--out model-embed.onnx] [--samples 20] [--no-verify]
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch

HOME = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
MODEL_DIR = HOME / "models" / "models" / "iic--emotion2vec_plus_large" / "snapshots" / "master"
PKG = Path(__file__).resolve().parent.parent


class Embedder(torch.nn.Module):
    """只做「标准化 → 抽特征 → 时间维平均」。"""

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.normalize = bool(getattr(model.cfg, "normalize", False))

    def forward(self, wav: torch.Tensor) -> torch.Tensor:
        if self.normalize:
            mean = wav.mean(dim=-1, keepdim=True)
            var = (wav - mean).pow(2).mean(dim=-1, keepdim=True)
            wav = (wav - mean) / torch.sqrt(var + 1e-5)
        out = self.model.extract_features(wav, padding_mask=None)
        feats = out["x"] if isinstance(out, dict) else out[0]
        return feats.mean(dim=1)


def load_embedder(model_dir: Path = MODEL_DIR) -> Embedder:
    from funasr import AutoModel

    auto = AutoModel(
        model="iic/emotion2vec_plus_large",
        model_path=str(model_dir),
        disable_update=True,
        device="cpu",
        disable_pbar=True,
        log_level="ERROR",
    )
    model = auto.model
    model.eval()
    return Embedder(model)


def _load_head() -> dict:
    head = json.loads((PKG / "model-v2.json").read_text(encoding="utf-8"))
    for key in ("mean", "scale", "coef", "intercept"):
        head[key] = np.asarray(head[key], dtype=np.float64)
    return head


def _predict(head: dict, emb: np.ndarray) -> str:
    z = (np.asarray(emb, dtype=np.float64).ravel() - head["mean"]) / head["scale"]
    logits = z @ head["coef"].T + head["intercept"]
    logits = logits - logits.max()
    probs = np.exp(logits) / np.exp(logits).sum()
    return head["labels"][int(probs.argmax())]


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))


def _audio_files(n: int) -> list[Path]:
    roots = [PKG.parent.parent / "tmp" / "voice-emo-dataset", PKG.parent.parent / "tmp" / "ext-audio"]
    out: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for p in sorted(root.rglob("*.wav")):
            out.append(p)
            if len(out) >= n:
                return out
    return out


def export(model_dir: Path, out_path: Path) -> None:
    enc = load_embedder(model_dir)
    dummy = torch.randn(1, 64000)
    import onnx
    from onnx.external_data_helper import convert_model_from_external_data

    tmp_path = out_path.with_suffix(".tmp.onnx")
    torch.onnx.export(
        enc,
        dummy,
        str(tmp_path),
        input_names=["wav"],
        output_names=["emb"],
        dynamic_axes={"wav": {0: "batch", 1: "time"}, "emb": {0: "batch"}},
        opset_version=18,
        do_constant_folding=True,
        dynamo=True,
    )
    model = onnx.load(str(tmp_path))
    convert_model_from_external_data(model)
    onnx.save_model(model, str(out_path), save_as_external_data=False)
    for leftover in (tmp_path, Path(str(tmp_path) + ".data")):
        if leftover.exists():
            leftover.unlink()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default=str(MODEL_DIR))
    ap.add_argument("--out", default=str(PKG / "model-embed.onnx"))
    ap.add_argument("--samples", type=int, default=20)
    ap.add_argument("--no-verify", action="store_true")
    args = ap.parse_args()

    model_dir = Path(args.model_dir)
    out_path = Path(args.out)
    t0 = time.time()
    print(f"[export] 导出 {model_dir} → {out_path}", flush=True)
    export(model_dir, out_path)
    size_mb = out_path.stat().st_size / 1e6
    print(f"[export] 完成 {size_mb:.1f} MB，用时 {time.time() - t0:.0f}s", flush=True)
    if args.no_verify:
        return 0

    import onnxruntime as ort
    import soundfile as sf

    head = _load_head()
    enc = load_embedder(model_dir)
    sess = ort.InferenceSession(str(out_path), providers=["CPUExecutionProvider"])

    files = _audio_files(args.samples)
    sims, t_torch, t_onnx, agree = [], 0.0, 0.0, 0
    for p in files:
        wav, sr = sf.read(p, dtype="float32", always_2d=False)
        if wav.ndim > 1:
            wav = wav.mean(axis=1)
        if sr != 16000:
            import librosa

            wav = librosa.resample(wav, orig_sr=sr, target_sr=16000)
        t = time.time()
        with torch.no_grad():
            a = enc(torch.from_numpy(wav[None, :])).numpy()
        t_torch += time.time() - t
        t = time.time()
        b = sess.run(None, {"wav": wav[None, :].astype(np.float32)})[0]
        t_onnx += time.time() - t
        sims.append(_cosine(a, b))
        agree += _predict(head, a) == _predict(head, b)

    report = {
        "samples": len(files),
        "size_mb": round(size_mb, 1),
        "cosine_min": round(float(np.min(sims)), 6),
        "cosine_mean": round(float(np.mean(sims)), 6),
        "label_agree": f"{agree}/{len(files)}",
        "torch_ms_per_clip": round(t_torch / max(1, len(files)) * 1000, 1),
        "onnx_ms_per_clip": round(t_onnx / max(1, len(files)) * 1000, 1),
    }
    (PKG / "onnx-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[export] {report}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
