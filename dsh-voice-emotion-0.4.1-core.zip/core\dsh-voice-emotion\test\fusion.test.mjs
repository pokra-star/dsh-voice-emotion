import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CLASSES,
  argmax4,
  fuse,
  likelihoodFromModel,
  priorFromEvidence,
} from '../lib/fusion.mjs';

test('显式标签把先验压到 negative，而不是只加一点点', () => {
  const p = priorFromEvidence({ tag: '反讽' });
  assert.ok(p.prior[CLASSES.indexOf('negative')] > 0.7);
  assert.equal(p.sources[0].source, 'tag');
});

test('没有文字证据时先验是均匀的，让声学主导', () => {
  const p = priorFromEvidence({});
  assert.deepEqual(p.prior, [0.25, 0.25, 0.25, 0.25]);
  assert.equal(p.hasEvidence, false);
});

test('后验会被强声学证据拉走：文字说正面，模型说负面', () => {
  const r = fuse({
    text: '太好了',
    model: { probs: [0.82, 0.1, 0.06, 0.02], labels: ['negative', 'neutral', 'positive', 'surprise'] },
    likelihoodTemperature: 1.2,
  });
  assert.equal(r.label, 'negative');
  assert.equal(r.abstain, false);
});

test('先验和似然都不确定时弃权', () => {
  const r = fuse({
    model: { probs: [0.27, 0.26, 0.24, 0.23] },
    minPosterior: 0.5,
    minMargin: 0.1,
  });
  assert.equal(r.abstain, true);
  assert.equal(r.label, null);
});

test('只有很强的显式标签、没有声学时，可以只按语境给标签', () => {
  const r = fuse({ tag: '生气' });
  assert.equal(r.abstain, false);
  assert.equal(r.label, 'negative');
  assert.ok(r.confidence > 0.8);
});

test('top 写成 [emotion, confidence] 数组也能当似然', () => {
  const l = likelihoodFromModel({ top: [['negative', 0.8], ['neutral', 0.2]] });
  assert.equal(argmax4(l.likelihood), 'negative');
  assert.ok(l.likelihood[0] > 0.5);
});

test('二类负面头的似然归一化，且负面高时排第一', () => {
  const l = likelihoodFromModel({ kind: 'neg', pNeg: 0.91 });
  const sum = l.likelihood.reduce((a, b) => a + b, 0);
  assert.ok(Math.abs(sum - 1) < 1e-9);
  assert.equal(argmax4(l.likelihood), 'negative');
});

test('反讽只按大语境，不被声学带跑', () => {
  const r = fuse({
    tag: '反讽',
    model: { probs: [0.05, 0.1, 0.8, 0.05] },
    acoustic: { emotion: 'happy', confidence: 0.9 },
  });
  assert.equal(r.label, 'negative');
  assert.equal(r.abstain, false);
  assert.equal(r.evidence.usedAcoustic, false);
  assert.equal(r.evidence.contextOverride, 'sarcasm');
});

test('context 里写明反讽也走大语境，不靠当前句猜', () => {
  const r = fuse({
    context: '他上一句在阴阳怪气，这一句是顺着说的',
    model: { probs: [0.05, 0.15, 0.75, 0.05] },
    acoustic: { emotion: 'happy', confidence: 0.9 },
  });
  assert.equal(r.label, 'negative');
  assert.equal(r.evidence.contextOverride, 'sarcasm');
});

test('13 类声学判断是弱证据，不会压过很强的语境', () => {
  const r = fuse({
    tag: '生气',
    acoustic: { emotion: 'happy', confidence: 0.8 },
    likelihoodTemperature: 1.5,
  });
  // 标签先验 0.875，happy 的弱似然只有 0.8；负面仍然应该赢。
  assert.equal(r.label, 'negative');
});
