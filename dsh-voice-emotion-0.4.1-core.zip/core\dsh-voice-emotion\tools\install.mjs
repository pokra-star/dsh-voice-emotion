#!/usr/bin/env node
/**
 * 一次性安装脚本：把这一档要用的东西全部下好，之后运行时不联网。
 *
 *   node tools/install.mjs --tier light     # librosa 等（~470MB）
 *   node tools/install.mjs --tier medium    # + whisper.cpp 与 base 模型（~160MB）
 *   node tools/install.mjs --tier full      # + emotion2vec 权重（~1.9GB）
 *
 * 重复跑是安全的：已经就绪的部分会跳过。
 */
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, createWriteStream, statSync, cpSync, readdirSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';
import { get as httpGet } from 'node:https';

const args = process.argv.slice(2);
const tierArg = (args.find((a) => a.startsWith('--tier=')) || '').split('=')[1]
  || (args.includes('--tier') ? args[args.indexOf('--tier') + 1] : '')
  || 'light';
const TIER = ['light', 'medium', 'full'].includes(tierArg) ? tierArg : 'light';

const HOME = process.env.DSH_VOICE_EMOTION_HOME || join(homedir(), '.dsh-voice-emotion');
const VENV = join(HOME, 'venv');
const MODELS = join(HOME, 'models');
const WHISPER_DIR = join(MODELS, 'whisper');
const MIRROR_PIP = 'https://pypi.tuna.tsinghua.edu.cn/simple';
const PKG = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const BUNDLED = join(PKG, 'models');

const say = (m) => console.log(`[install:${TIER}] ${m}`);
const py = () => join(VENV, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');

// ── 每次安装都必须看到的提醒 ──────────────────────────────────────────────
// 用户 2026-11-10 明确要求：「安装时让一定要有提醒」。
const banner = [
  '',
  '  ┌──────────────────────────────────────────────────────────────┐',
  '  │  提醒：这个插件「会听」，但**不自带发声引擎**。             │',
  '  │                                                              │',
  '  │  voice_emotion_* 四个「听」的工具装完就能用；                │',
  '  │  voice_speak（把文字说成带情绪的语音）需要宿主另装 TTS：     │',
  '  │    POST {ttsUrl}/speak  →  { ok, path, seconds }             │',
  '  │  现成实现：GPT-SoVITS 网关 voice-pipeline/tts_server.py      │',
  '  │  默认地址 http://127.0.0.1:3120，可用 VOICE_TTS_URL 改。     │',
  '  │                                                              │',
  '  │  没有 TTS 也不影响「听」；voice_speak 会直接报错说明原因。    │',
  '  └──────────────────────────────────────────────────────────────┘',
  '',
].join('\n');
console.log(banner);


function pythonDeps() {
  if (existsSync(join(VENV, '.ready'))) { say('python 依赖已就绪，跳过'); return; }
  say('装 python 依赖（约 470MB，两四分钟）');
  const script = resolve('python/bootstrap.py');
  const r = spawnSync(process.env.PYTHON || 'python', [script, '--dir', VENV, '--mirror', MIRROR_PIP], { windowsHide: true, stdio: 'inherit' });
  if (r.status !== 0) throw new Error('python 依赖装失败，看上面的日志；也可以换 --mirror 再试');
  say(`python 好了：${py()}`);
}

function download(url, dest, { minBytes = 1024 } = {}) {
  if (existsSync(dest) && statSync(dest).size > minBytes) { say(`已有 ${dest.split(/[\\/]/).pop()}，跳过`); return Promise.resolve(); }
  say(`下 ${url}`);
  mkdirSync(join(dest, '..'), { recursive: true });
  return new Promise((res, rej) => {
    const follow = (u, depth = 0) => {
      if (depth > 5) return rej(new Error('重定向太多'));
      httpGet(u, { headers: { 'user-agent': 'dsh-voice-emotion/install' } }, (r) => {
        if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location) { r.resume(); return follow(r.headers.location, depth + 1); }
        if (r.statusCode !== 200) { r.resume(); return rej(new Error(`HTTP ${r.statusCode}：${u}`)); }
        const total = Number(r.headers['content-length'] || 0);
        let got = 0; let last = 0;
        const out = createWriteStream(dest);
        r.on('data', (c) => {
          got += c.length;
          if (total && got - last > total / 10) { last = got; say(`  ${Math.round((got / total) * 100)}%`); }
        });
        r.pipe(out);
        out.on('finish', () => { out.close(() => res()); });
        out.on('error', rej);
      }).on('error', rej);
    };
    follow(url);
  });
}

async function whisper() {
  const modelDir = join(MODELS, 'faster-whisper-base');
  const model = join(modelDir, 'model.bin');
  say('转写：faster-whisper + base 模型（约 200MB，装完不需要外部 ASR 服务）');
  const r = spawnSync(py(), ['-m', 'pip', 'install', '--upgrade', '-i', MIRROR_PIP,
    'faster-whisper>=1.0', 'tokenizers>=0.19', 'av>=14'], { windowsHide: true, stdio: 'inherit' });
  if (r.status !== 0) throw new Error('faster-whisper 装失败（网络不稳就重跑一次）');
  const base = 'https://hf-mirror.com/Systran/faster-whisper-base/resolve/main';
  mkdirSync(modelDir, { recursive: true });
  for (const [name, min] of [['config.json', 500], ['tokenizer.json', 100000], ['vocabulary.txt', 100000], ['model.bin', 50000000]]) {
    await download(`${base}/${name}`, join(modelDir, name), { minBytes: min });
  }
  say(`转写就绪：${modelDir}`);
}

async function emotion2vec() {
  say('4 类模型：emotion2vec 权重（约 1.9GB）+ funasr / torch');
  const reqs = join(HOME, 'requirements-v2.txt');
  mkdirSync(HOME, { recursive: true });
  const pyReq = [
    'funasr>=1.2', 'modelscope>=1.20', 'torch>=2.4', 'torchaudio>=2.4', 'torchvision>=0.19', 'scikit-learn>=1.5',
  ].join('\n') + '\n';
  (await import('node:fs')).writeFileSync(reqs, pyReq);
  const r = spawnSync(py(), ['-m', 'pip', 'install', '-r', reqs, '-i', MIRROR_PIP], { windowsHide: true, stdio: 'inherit' });
  if (r.status !== 0) throw new Error('funasr/torch 装失败（体积大，网络不稳就重跑）');
  const dl = join(HOME, 'models', 'download_emotion2vec.py');
  mkdirSync(join(HOME, 'models'), { recursive: true });
  (await import('node:fs')).writeFileSync(dl, [
    'from modelscope import snapshot_download',
    `snapshot_download('iic/emotion2vec_plus_large', cache_dir=r'${join(HOME, 'models')}')`,
    'print("ok")',
  ].join('\n'));
  say('下权重（1.9GB，慢但只一次）');
  const d = spawnSync(py(), [dl], { windowsHide: true, stdio: 'inherit' });
  if (d.status !== 0) throw new Error('权重下载失败，检查 modelscope 网络');
  say('4 类模型就绪（服务由插件在首次用到时拉起）');
}

/** 包里自带的模型（标准/完整档）直接拷到家目录，不联网。 */
function useBundled() {
  if (!existsSync(BUNDLED)) return;
  const names = readdirSync(BUNDLED, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name);
  for (const name of names) {
    const src = join(BUNDLED, name);
    const dst = join(MODELS, name);
    if (existsSync(join(dst, 'model.bin'))) { say(`自带的 ${name} 已就位，跳过`); continue; }
    say(`用包里自带的 ${name}（无需下载）`);
    mkdirSync(MODELS, { recursive: true });
    cpSync(src, dst, { recursive: true });
  }
}

try {
  pythonDeps();
  useBundled();
  if (TIER === 'medium' || TIER === 'full') await whisper();
  if (TIER === 'full') await emotion2vec();
  say(`完成。装到：${HOME}`);
} catch (error) {
  console.error(`[install:${TIER}] 失败：${error?.message ?? error}`);
  process.exit(1);
}
