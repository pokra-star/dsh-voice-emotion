# 生成图标 assets\icon.ico（256x256，PNG 内嵌 ICO）
# 用法：powershell -ExecutionPolicy Bypass -File tools\make-icon.ps1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$outDir = Join-Path (Split-Path -Parent $PSScriptRoot) 'assets'
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$png = Join-Path $outDir 'icon-256.png'

$bmp = New-Object System.Drawing.Bitmap 256, 256
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = 'AntiAlias'
$g.TextRenderingHint = 'AntiAliasGridFit'

# 背景圆角方块（深蓝 -> 粉 渐变）
$rect = New-Object System.Drawing.Rectangle 8, 8, 240, 240
$brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, ([System.Drawing.Color]::FromArgb(255, 38, 42, 74)), ([System.Drawing.Color]::FromArgb(255, 214, 92, 140)), 45.0
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$r = 52
$path.AddArc(8, 8, $r, $r, 180, 90)
$path.AddArc(248 - $r, 8, $r, $r, 270, 90)
$path.AddArc(248 - $r, 248 - $r, $r, $r, 0, 90)
$path.AddArc(8, 248 - $r, $r, $r, 90, 90)
$path.CloseFigure()
$g.FillPath($brush, $path)

# 中间「声波」：5 根对称竖条
$pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(240, 255, 255, 255)), 14
$pen.StartCap = 'Round'; $pen.EndCap = 'Round'
$xs = @(72, 100, 128, 156, 184)
$hs = @(58, 112, 156, 112, 58)
for ($i = 0; $i -lt 5; $i++) {
  $x = $xs[$i]; $h = $hs[$i]
  $g.DrawLine($pen, $x, 128 - $h / 2, $x, 128 + $h / 2)
}
$pen.Dispose()

$g.Dispose()
$bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

# PNG -> ICO（单张 256x256，Vista+ 支持）
$pngBytes = [IO.File]::ReadAllBytes($png)
$ms = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter($ms)
$bw.Write([UInt16]0)      # reserved
$bw.Write([UInt16]1)      # type = icon
$bw.Write([UInt16]1)      # count
$bw.Write([Byte]0)        # width 0 = 256
$bw.Write([Byte]0)        # height 0 = 256
$bw.Write([Byte]0)        # palette
$bw.Write([Byte]0)        # reserved
$bw.Write([UInt16]1)      # planes
$bw.Write([UInt16]32)     # bpp
$bw.Write([UInt32]$pngBytes.Length)
$bw.Write([UInt32]22)     # offset
$bw.Write($pngBytes)
$bw.Flush()
[IO.File]::WriteAllBytes((Join-Path $outDir 'icon.ico'), $ms.ToArray())
$bw.Dispose(); $ms.Dispose()

Write-Host "ok: $outDir\icon.ico"
