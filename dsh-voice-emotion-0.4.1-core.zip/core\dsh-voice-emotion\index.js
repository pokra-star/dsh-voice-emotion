/**
 * dsh-voice-emotion —— 语音情绪识别（转写 + 声学 + 内容融合 + 跟历史比）。
 *
 * 完整链路：一条语音进来 → ①转写（复用本机 ASR 服务，3120 的 /asr）②量声学
 * （语速/起音密度、响度与起伏、停顿占比、基频高低与离散、音质抖动/沙哑）
 * ③按「这个说话人自己的基线」给档位 ④跟文字情绪比对 ⑤（可选）4 类 emo2vec 模型。
 *
 * 工具：
 *   voice_emotion_full(path, text?, targetEmotion?, save?)  转写 + 情绪，一条龙的入口
 *   voice_emotion_analyze(path, text?, targetEmotion?, save?)  只做情绪（不转写）
 *   voice_emotion_history(limit?)  历史与基线
 *   voice_emotion_prune(days?, dryRun?, paths?)  清理临时音频
 */
import { join, resolve as resolvePath, extname } from 'node:path';
import { existsSync, copyFileSync, readFileSync } from 'node:fs';
import { execFile, spawn } from 'node:child_process';
import { homedir } from 'node:os';

export const name = 'dsh-voice-emotion';
export const inject = ['tools', 'commands'];
export const version = '0.4.0';

let z = null;
try {
  const m = await import('@deepseek-ai/schemastery');
  z = m.default ?? m;
} catch { /* 没有 schemastery 就用默认值 */ }

let defineTool = null;
try {
  const m = await import('@deepseek-ai/dsh-tools');
  defineTool = m.defineTool;
} catch { /* 兜底 */ }

function localDefineTool(options) {
  const properties = {};
  const required = [];
  for (const [key, def] of Object.entries(options.parameters ?? {})) {
    const node = { type: def.type, description: def.description };
    if (def.type === 'array') node.items = def.items;
    if (def.enum !== undefined) node.enum = def.enum;
    if (def.default !== undefined) node.default = def.default;
    properties[key] = node;
    if (def.required === true) required.push(key);
  }
  return {
    name: options.name,
    description: options.description,
    parameters: { type: 'object', properties, ...(required.length ? { required } : {}), additionalProperties: false },
    output: {
      schema: options.output?.schema ?? { type: 'object', additionalProperties: true },
      render: options.output?.render ?? ((_args, value) => [{
        type: 'text',
        text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
      }]),
    },
    async execute(args, exec) { return options.execute(args, exec); },
  };
}
const makeTool = defineTool ?? localDefineTool;

function compactResult(r, text) {
  const v = r?.verdict && typeof r.verdict === 'object' ? r.verdict.sentence : r?.verdict;
  const out = { ok: true, speaker: r?.speaker, verdict: v };
  if (text) out.text = text;
  const neg = r?.modelNeg;
  if (neg && typeof neg.pNeg === 'number') out.neg = { label: neg.label, p: Math.round(neg.pNeg * 100) / 100 };
  if (r?.unclear) out.unclear = r.reason || '听不清';
  if (r?.acoustic?.stable > 1) out.stable = r.acoustic.stable;
  return out;
}

const TEXT_OUTPUT = {
  schema: { type: 'json' },
  render: (_args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }],
};

export const Config = !z ? undefined : z.object({
  pythonPath: z.string().default(''),
  baselineWindow: z.natural().default(40),
  asrUrl: z.string().default('http://127.0.0.1:3120'),
  asrTimeoutMs: z.natural().default(90000),
  tempKeepHours: z.natural().default(24),
  homeDir: z.string().default(''),
  pipMirror: z.string().default('https://pypi.tuna.tsinghua.edu.cn/simple'),
  autoProvision: z.boolean().default(true),
  // 「说」的能力需要宿主提供 TTS；本插件只带整形层，不带引擎
  ttsUrl: z.string().default(''),
  // 宿主 TTS 的默认引擎与 RVC 参数；留空 = 由宿主决定 / 调用时再传
  ttsEngine: z.string().default(''),
  ttsVoice: z.string().default(''),
  indexRate: z.string().default(''),
  protect: z.string().default(''),
  speakTimeoutMs: z.natural().default(300000),
  // speak: auto=启动时探一下有没有 TTS，没有就不开；on=强制开；off=完全不开（不注册、不暴露 action）
  // 留空 = 跟随包内 variant.json；显式写 on/off/auto 覆盖它
  speak: z.string().default(''),
  // listen: on=注册转写/情绪/历史；off=只做「说」；留空 = 跟随 variant.json
  listen: z.string().default(''),
  // 影子融合：只把「语境→小句文本→声学似然→贝叶斯后验」挂到明细里，不改 verdict
  fusionShadow: z.boolean().default(false),
});

function readVariant() {
  try {
    const p = join(import.meta.dirname ?? '.', 'variant.json');
    if (!existsSync(p)) return {};
    const v = JSON.parse(readFileSync(p, 'utf8'));
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

export function apply(ctx, config) {
  const cfg = config ?? {};
  const home = String(cfg.homeDir || '') || join(homedir(), '.dsh-voice-emotion');
  const venvDir = join(home, 'venv');
  const venvPython = join(venvDir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
  const pipMirror = String(cfg.pipMirror || 'https://pypi.tuna.tsinghua.edu.cn/simple');
  const autoProvision = cfg.autoProvision !== false;
  const configured = String(cfg.pythonPath ?? '');
  const pyPath = () => (configured && existsSync(configured) ? configured : venvPython);
  const baselineWindow = Math.max(3, Number(cfg.baselineWindow) || 40);
  const asrUrl = String(cfg.asrUrl ?? 'http://127.0.0.1:3120');
  const asrTimeoutMs = Math.max(5000, Number(cfg.asrTimeoutMs) || 90000);
  const tempKeepHours = Math.max(0.5, Number(cfg.tempKeepHours) || 24);
  const ttsUrl = String(cfg.ttsUrl ?? '') || String(process.env.VOICE_TTS_URL || 'http://127.0.0.1:3120');
  const speakTimeoutMs = Math.max(10000, Number(cfg.speakTimeoutMs) || 300000);
  // 按需加载：默认只注册一个路由工具，六个细分工具在 action 命中时才走对应实现
  const lazy = cfg.lazy !== false;
  const variant = readVariant();
  const listenMode = String(cfg.listen || variant.listen || 'on').toLowerCase();
  const listenOn = listenMode !== 'off';
  const fusionShadow = Boolean(cfg.fusionShadow);
  const speakMode = String(cfg.speak || variant.speak || 'auto').toLowerCase();
  let speakOn = speakMode !== 'off';
  const collected = [];
  const collect = (tool) => { collected.push(tool); if (!lazy) ctx.tools.register(tool); };

  let provisioning = null;   // Promise | null
  let lastProvision = null;  // { ok, python, error, at }

  function runBootstrap() {
    const script = resolvePath(join(import.meta.dirname ?? '.', 'python', 'bootstrap.py'));
    return new Promise((resolve) => {
      execFile(process.env.PYTHON || 'python', [script, '--dir', venvDir, '--mirror', pipMirror],
        { timeout: 15 * 60 * 1000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
        (error, stdout, stderr) => {
          const out = String(stdout || '');
          const py = out.trim().split(/\r?\n/).filter((l) => /python(\.exe)?$/i.test(l.trim())).pop() || '';
          const ok = !error && existsSync(venvPython);
          lastProvision = { ok, python: py || venvPython, error: error ? String(stderr || error.message).slice(-400) : '', at: Date.now() };
          resolve(lastProvision);
        });
    });
  }

  /** 拿到可用的解释器；缺依赖且允许自动装就装一次（并发调用共享同一个 Promise）。 */
  async function ensurePython() {
    const p = pyPath();
    if (existsSync(p)) return p;
    if (!autoProvision) {
      throw new Error(`没找到 Python 环境：${p}。可以设 config.pythonPath，或跑 python python/bootstrap.py 自动装。`);
    }
    provisioning = provisioning || runBootstrap();
    const r = await provisioning;
    provisioning = null;
    if (r.ok && existsSync(venvPython)) return venvPython;
    throw new Error(`自动准备 Python 依赖失败：${r.error || '未知原因'}。可手动跑 python python/bootstrap.py 重试。`);
  }

  async function analyzeOne({ path, text, targetEmotion, save, context }) {
    const { analyze, predictV2Model } = await import('./lib/emotion.mjs');
    const file = resolvePath(String(path));
    const python = await ensurePython();
    const r = analyze({ file, text: text ?? '', target: targetEmotion ?? '', save, config: { pythonPath: python, baselineWindow } });
    if (r.unclear) return r; // 太空/太短：不叠模型，也不写基线
    const modelNeg = await predictV2Model(file);
    if (modelNeg) r.modelNeg = modelNeg;
    if (fusionShadow) {
      try {
        const { shadowFusion } = await import('./lib/context-prior.mjs');
        r.fusion = shadowFusion({ text: text ?? '', context, acoustic: r.acoustic });
      } catch (e) {
        r.fusion = { error: String(e?.message ?? e) };
      }
    }
    return r;
  }

  const fullTool = makeTool({
    name: 'voice_emotion_full',
    description: '一条语音 → 说了什么 + 什么语气（转写、声学、与本人基线比、负面程度）。只吃本地路径，不吃 URL。brief=true 只要结论。',
    parameters: {
      path: { type: 'string', required: true, description: '本地音频绝对路径' },
      text: { type: 'string', description: '已知原文，传了就不转写' },
      targetEmotion: { type: 'string', description: '这条本来是哪个情绪（用于核对）' },
      brief: { type: 'boolean', default: false, description: '只要结论（约 60 字），不要明细' },
      save: { type: 'boolean', default: true, description: '写不写进基线' },
      context: { type: 'string', description: '最近几条文本/场景（影子融合用，可传 JSON 或纯文本）' },
    },
    output: TEXT_OUTPUT,
    async execute({ path, text, targetEmotion, brief = false, save = true, context = '' }) {
      const { transcribeFile } = await import('./lib/asr.mjs');
      const file = resolvePath(String(path)); // 常驻服务按自己的 cwd 解析相对路径，这里先转绝对
      let transcript = String(text ?? '').trim();
      let asr = { ok: Boolean(transcript), skipped: Boolean(transcript) };
      if (!transcript) {
        const t = await transcribeFile(file, { url: asrUrl, timeoutMs: asrTimeoutMs, pythonPath: pyPath(), homeDir: home });
        asr = t.ok ? { ok: true, text: t.text, source: t.source } : { ok: false, error: t.error };
        transcript = t.ok ? t.text : '';
      }
      try {
        const r = await analyzeOne({ path: file, text: transcript, targetEmotion, save, context });
        if (brief) {
          return { content: [{ type: 'text', text: JSON.stringify(compactResult(r, transcript)) }] };
        }
        return { content: [{ type: 'text', text: JSON.stringify({ ...r, asr: { ...asr, text: transcript } }, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `分析失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  if (listenOn) collect(fullTool);

  const analyzeTool = makeTool({
    name: 'voice_emotion_analyze',
    description: '已知原文、只要语气（不转写）。brief=true 只要结论。',
    parameters: {
      path: { type: 'string', required: true, description: '本地音频绝对路径' },
      text: { type: 'string', description: '原话（用于声音 vs 内容）' },
      targetEmotion: { type: 'string', description: '本来是什么情绪（核对用）' },
      brief: { type: 'boolean', default: false, description: '只要结论' },
      save: { type: 'boolean', default: true, description: '写不写进基线' },
      context: { type: 'string', description: '最近几条文本/场景（影子融合用，可传 JSON 或纯文本）' },
    },
    output: TEXT_OUTPUT,
    async execute({ path, text, targetEmotion, brief = false, save = true, context = '' }) {
      try {
        const r = await analyzeOne({ path, text, targetEmotion, save, context });
        if (brief) return { content: [{ type: 'text', text: JSON.stringify(compactResult(r, text)) }] };
        return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `情绪分析失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  if (listenOn) collect(analyzeTool);

  const historyTool = makeTool({
    name: 'voice_emotion_history',
    description: '语音情绪历史：条数、分布、基线、最近几条结论。',
    parameters: {
      limit: { type: 'number', default: 3, description: '最近几条（默认 3）' },
      brief: { type: 'boolean', default: true, description: '只要摘要' },
    },
    output: TEXT_OUTPUT,
    async execute({ limit = 3, brief = true }) {
      try {
        const { historySummary } = await import('./lib/emotion.mjs');
        const n = Math.max(1, Math.min(50, Number(limit) || 3));
        const r = historySummary({ limit: n, config: { baselineWindow } });
        if (!brief) return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
        const pick = {
          total: r.total ?? r.count ?? r.totalEntries,
          counts: r.counts ?? r.byEmotion,
          baseline: r.baseline ?? r.baselines,
          recent: (r.recent || r.entries || []).slice(-n).map((x) => ({
            at: x.at || x.time || x.timestamp,
            emo: x.emotion || x.acoustic?.emotion || x.verdict,
          })),
        };
        return { content: [{ type: 'text', text: JSON.stringify(pick) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `读历史失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  if (listenOn) collect(historyTool);

  const setupTool = makeTool({
    name: 'voice_emotion_setup',
    description: '准备/检查 Python 依赖（首次约 470MB）。',
    parameters: {
      force: { type: 'boolean', default: false, description: '强制重建' },
    },
    output: TEXT_OUTPUT,
    async execute({ force = false }) {
      const p = pyPath();
      const ready = existsSync(p);
      if (!force && ready) {
        const { execFile } = await import('node:child_process');
        const version = await new Promise((resolve) => {
          execFile(p, ['-c', 'import librosa,sys;print(librosa.__version__)'], { timeout: 60000, windowsHide: true },
            (e, out) => resolve(e ? null : String(out).trim()));
        });
        return { content: [{ type: 'text', text: JSON.stringify({ ok: Boolean(version), python: p, librosa: version, venvDir, provisioned: false }, null, 2) }] };
      }
      const r = await (provisioning = provisioning || runBootstrap());
      provisioning = null;
      return { content: [{ type: 'text', text: JSON.stringify({ ...r, venvDir, python: venvPython }, null, 2) }] };
    },
  });
  collect(setupTool);

  // 挂载时若没有解释器，后台先准备一次（不阻塞启动）
  if (autoProvision && !existsSync(pyPath())) {
    console.log('[voice-emotion] 没有 Python 环境，后台开始准备（首次约 2~4 分钟）');
    provisioning = runBootstrap();
  }

  const pruneTool = makeTool({
    name: 'voice_emotion_prune',
    description: '按时间+占用清临时音频（默认 200MB/500 个）。只动音频，不碰权重。',
    parameters: {
      days: { type: 'number', default: 1, description: '保留天数（默认 1）' },
      maxMB: { type: 'number', description: '体积上限（默认 200）' },
      maxFiles: { type: 'number', description: '个数上限（默认 500）' },
      dryRun: { type: 'boolean', default: false, description: '只报告不删' },
      paths: { type: 'array', items: { type: 'string' }, description: '额外扫的目录' },
    },
    output: TEXT_OUTPUT,
    async execute({ days = 1, maxMB, maxFiles, dryRun = false, paths = [] }) {
      try {
        const { pruneTemp } = await import('./lib/tempfiles.mjs');
        const r = pruneTemp({
          dirs: Array.isArray(paths) ? paths.filter((p) => typeof p === 'string' && p.trim()) : [],
          maxAgeHours: Math.max(0.5, Number(days) || 1) * 24,
          maxBytes: Number.isFinite(Number(maxMB)) && Number(maxMB) >= 0 ? Number(maxMB) * 1024 * 1024 : undefined,
          maxFiles: Number.isFinite(Number(maxFiles)) && Number(maxFiles) >= 0 ? Number(maxFiles) : undefined,
          dryRun: Boolean(dryRun),
        });
        return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `清理失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  collect(pruneTool);

  // ── 发声：文字 → 一条带情绪语气的语音文件 ────────────────────────────────
  // 依赖宿主提供 TTS（POST /speak）；本插件只做「怎么说」的整形（语速/响度/停顿/闭环音高）。
  const speakTool = makeTool({
    name: 'voice_speak',
    description: '合成一条带情绪的语音，返回文件路径。需要宿主提供 POST /speak（默认 127.0.0.1:3120，VOICE_TTS_URL 可改）。',
    parameters: {
      text: { type: 'string', description: '要说的内容（一两句）' },
      emotion: { type: 'string', default: 'neutral', description: 'neutral/happy/surprised/angry/complaint/firm/urgent/anxious/sad/soft/tired/lazy/aggrieved' },
      intensity: { type: 'number', default: 0.7, description: '强度 0~1' },
      url: { type: 'string', description: 'TTS 地址' },
      outDir: { type: 'string', description: '成品目录' },
      engine: { type: 'string', description: 'gsv 或 rvc' },
      ttsVoice: { type: 'string', description: 'RVC 底声 voice' },
      indexRate: { type: 'number', description: 'RVC 索引比' },
      protect: { type: 'number', description: 'RVC 保护' },
    },
    output: TEXT_OUTPUT,
    async execute({ text, emotion = 'neutral', intensity = 0.7, url, outDir, engine, ttsVoice, indexRate, protect }) {
      if (!speakOn) {
        return { content: [{ type: 'text', text: '这台机器没开「说」：没有可用的 TTS 服务，或配置里 speak="off"。装好 TTS（能 POST /speak）后在配置里把 speak 设成 "on"。' }], isError: true };
      }
      const say = String(text ?? '').trim();
      if (!say) return { content: [{ type: 'text', text: 'text 不能为空' }], isError: true };
      const emo = String(emotion ?? 'neutral').trim().toLowerCase();
      try {
        const { synthSpeech, defaultTtsUrl, fileReady } = await import('./lib/tts.mjs');
        // 控制台存的地址优先；config/env 是后备
        const base = String(url || defaultTtsUrl() || ttsUrl);
        const useEngine = String(engine || cfg.ttsEngine || '');
        const useVoice = String(ttsVoice || cfg.ttsVoice || '');
        const cfgIndex = cfg.indexRate === '' || cfg.indexRate === undefined ? undefined : Number(cfg.indexRate);
        const cfgProtect = cfg.protect === '' || cfg.protect === undefined ? undefined : Number(cfg.protect);
        const useIndex = indexRate === undefined || indexRate === null ? cfgIndex : Number(indexRate);
        const useProtect = protect === undefined || protect === null ? cfgProtect : Number(protect);
        const synth = await synthSpeech(say, {
          url: base,
          timeoutMs: speakTimeoutMs,
          engine: useEngine,
          ttsVoice: useVoice,
          indexRate: Number.isFinite(useIndex) ? useIndex : undefined,
          protect: Number.isFinite(useProtect) ? useProtect : undefined,
        });
        if (!fileReady(synth.path)) throw new Error(`合成结果不存在或为空：${synth.path}`);

        let outPath = synth.path;
        let shaped = null;
        if (emo && emo !== 'neutral') {
          const { shapeVoiceFile, SHAPES } = await import('./lib/shape.mjs');
          if (!SHAPES[emo]) throw new Error(`未知语气：${emo}`);
          shaped = await shapeVoiceFile(synth.path, emo, intensity, { python: pyPath() });
          if (shaped) outPath = shaped;
        }

        if (outDir && existsSync(outDir)) {
          const target = join(outDir, `speak-${Date.now()}${extname(outPath) || '.wav'}`);
          copyFileSync(outPath, target);
          outPath = target;
        }
        return {
          content: [{
            type: 'text',
            text: JSON.stringify({
              ok: true,
              path: outPath,
              seconds: synth.seconds,
              emotion: emo,
              shaped: Boolean(shaped),
              engine: synth.engine || '',
              requestedEngine: useEngine || 'host',
              ttsVoice: useVoice || '',
              url: base,
            }, null, 2),
          }],
        };
      } catch (error) {
        return { content: [{ type: 'text', text: `合成失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  if (speakOn) collect(speakTool);
  else console.warn('[voice-emotion] speak 已按配置关闭（config.speak="off"）：不会注册 voice_speak。');

  if (lazy) {
    const actions = [];
    if (listenOn) actions.push('full', 'analyze', 'history');
    if (speakOn) actions.push('speak');
    actions.push('prune', 'setup');
    const defaultAction = listenOn ? 'full' : 'speak';
    const router = makeTool({
      name: 'voice_emotion',
      description: listenOn
        ? `语音情绪：action=${actions.join('|')}。full 转写+语气 / analyze 只判语气 / history 历史 / prune 清临时音频 / setup 装依赖${speakOn ? ' / speak 合成带情绪的语音（需宿主 TTS）' : '（本机未启用 speak）'}。`
        : '语音情绪（说版）：action=speak 合成带情绪的语音（需宿主 TTS）/ prune 清临时音频 / setup 装依赖。这版不注册「听」的工具。',
      parameters: {
        action: { type: 'string', default: defaultAction, description: actions.join('|') },
        path: { type: 'string', description: '本地音频（full/analyze 必填）' },
        text: { type: 'string', description: '原话或要合成的内容' },
        emotion: { type: 'string', default: 'neutral', description: 'speak 时的语气' },
        intensity: { type: 'number', default: 0.7, description: '强度 0~1' },
        brief: { type: 'boolean', default: true, description: '只要结论' },
        save: { type: 'boolean', default: true, description: '写不写进基线' },
        limit: { type: 'number', default: 3, description: 'history 条数' },
        days: { type: 'number', default: 1, description: 'prune 保留天数' },
        dryRun: { type: 'boolean', default: false, description: 'prune 只报告' },
        force: { type: 'boolean', default: false, description: 'setup 强制重装' },
        outDir: { type: 'string', description: 'speak 成品目录' },
        url: { type: 'string', description: 'TTS 地址' },
        engine: { type: 'string', description: 'gsv 或 rvc' },
      },
      output: TEXT_OUTPUT,
      async execute(args) {
        const action = String(args.action || defaultAction);
        if (!listenOn && ['full', 'analyze', 'history'].includes(action)) {
          return { content: [{ type: 'text', text: '这版只做「说」，没有注册听/转写/历史的工具。要听说两样都做，用「全」版。' }], isError: true };
        }
        if (action === 'speak' && !speakOn) {
          return { content: [{ type: 'text', text: '这台机器没开「说」：要么没有 TTS 服务，要么配置里 speak=\"off\"。装好 TTS（能 POST /speak）后把 config.speak 设成 "on"，或直接调一次 voice_emotion(action=\"setup\") 看看依赖。' }], isError: true };
        }
        const map = { full: 'voice_emotion_full', analyze: 'voice_emotion_analyze', history: 'voice_emotion_history', speak: 'voice_speak', prune: 'voice_emotion_prune', setup: 'voice_emotion_setup' };
        const want = map[action] || (listenOn ? 'voice_emotion_full' : 'voice_speak');
        const target = collected.find((t) => t.name === want);
        if (!target) return { content: [{ type: 'text', text: `未知 action：${action}` }], isError: true };
        const pass = { ...args };
        delete pass.action;
        if (want !== 'voice_speak' && pass.brief === undefined) pass.brief = true;
        return target.execute(pass);
      },
    });
    ctx.tools.register(router);
  }

  // 独立控制台：/voice-ui 起本地服务并弹浏览器。
  // 不塞进 DSH 设置页——第三方设置 section 要打包客户端 bundle，这里用指令绕开。
  if (ctx.commands?.register) {
    try {
      ctx.commands.register({
        name: 'voice-ui',
        description: '打开语音情绪控制台（TTS / 占用 / 情绪）',
        handler: async () => {
          const ui = join(import.meta.dirname ?? '.', 'ui', 'server.mjs');
          const url = 'http://127.0.0.1:3135';
          const alive = async () => {
            try {
              const r = await fetch(`${url}/api/ping`, { signal: AbortSignal.timeout(700) });
              return r.ok;
            } catch { return false; }
          };
          let up = await alive();
          if (!up) {
            spawn(process.execPath, [ui], { windowsHide: true, stdio: 'ignore',
              detached: true, stdio: 'ignore', windowsHide: true,
              env: { ...process.env, VOICE_UI_PORT: '3135' },
            }).unref();
            for (let i = 0; i < 24 && !up; i += 1) {
              await new Promise((r) => setTimeout(r, 250));
              up = await alive();
            }
          }
          if (!up) return { kind: 'error', text: '控制台没起来。看看 3135 端口是不是被占了，或手动跑 ui/server.mjs。' };
          if (process.platform === 'win32') {
            spawn('cmd.exe', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
          } else if (process.platform === 'darwin') {
            spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
          } else {
            spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
          }
          return { kind: 'success', text: '控制台开在浏览器里了：http://127.0.0.1:3135' };
        },
      });
    } catch (e) {
      console.warn(`[voice-emotion] /voice-ui 注册失败：${String(e?.message || e)}`);
    }
  }

  // 挂载时探一下 TTS：没有就说清楚（不阻塞启动，也不阻止其它工具用）
  void (async () => {
    try {
      const { ttsReachable } = await import('./lib/tts.mjs');
      const ok = await ttsReachable(ttsUrl, 1500);
      if (!ok) {
        if (speakMode === 'auto') {
          speakOn = false;
          console.warn(`[voice-emotion] 没有可用的 TTS 端点（${ttsUrl}）：已自动关闭 speak，其它「听」的工具不受影响。`
            + '装好 TTS 后在配置里把 speak 设成 "on"（或用 config.ttsUrl / VOICE_TTS_URL 指地址）。');
        } else {
          console.warn(`[voice-emotion] 没有可用的 TTS 端点（${ttsUrl}）：voice_speak 会失败，其它工具不受影响。`);
        }
      } else if (speakMode === 'auto') {
        speakOn = true;
      }
    } catch { /* 忽略 */ }
  })();


  // 挂载时顺手清一次很老的临时文件（只删超过 tempKeepHours 的，失败不影响挂载）
  void (async () => {
    try {
      const { pruneTemp } = await import('./lib/tempfiles.mjs');
      const r = pruneTemp({ maxAgeHours: tempKeepHours, dryRun: false });
      if (r?.count) console.log(`[voice-emotion] 清理临时音频 ${r.count} 个（${Math.round(r.bytes / 1024)} KB）`);
    } catch { /* 忽略 */ }
  })();

  // 音色校准（0.4.0）：检测到用户自己跑着 TTS，就顺手把六腔锚点标一次。
  // 只量「音色本身」（TTS 的参考音），不自己合成、不动权重；没 TTS 就安静跳过。
  void (async () => {
    try {
      for (let i = 0; i < 20 && !speakOn; i += 1) await new Promise((r) => setTimeout(r, 250));
      if (!speakOn || process.env.VOICE_PROFILE_AUTO === '0') return;
      const { calibrate, saveResult } = await import('./lib/voice-profile.mjs');
      const r = await calibrate({ ttsUrl, log: () => {} });
      if (r.ok) {
        await saveResult(r);
        console.log(`[voice-emotion] 音色校准${r.skipped ? '（已有，跳过）' : '完成'}：${r.name}`);
      } else {
        console.warn(`[voice-emotion] 音色校准没做：${r.reason || ''} ${r.error || ''}`.trim());
      }
    } catch (e) {
      console.warn(`[voice-emotion] 音色校准异常：${String(e?.message || e)}`);
    }
  })();

  console.log(`[voice-emotion] 已挂载 v${version}（asr: ${asrUrl}，python: ${pyPath()}）`);
  return { name, version };
}

export default { name, inject, version, Config, apply };
