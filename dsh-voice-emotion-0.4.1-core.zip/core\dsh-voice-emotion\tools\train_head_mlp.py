"""在已有 emotion2vec 嵌入（X.npy）上换一个更强的分类头。

为什么不用原来那版「微调最后两层」：实测第一轮验证 acc 0.4314 / macroF1 0.4182，
比线性头在 20k 上的 0.5479 还低——2849 条样本喂不动两块 transformer 层，反传把
本来对齐好的表示带偏了。嵌入本身是对的，问题只在头。

所以这里只换头：
    X.npy (N,1024) + meta.jsonl → 3 折「按说话人分组」交叉验证
    线性（逻辑回归）当基线，MLP（1024→256→4，GELU，dropout，label smoothing）
    同一折切分、同一评估函数，谁好用谁。

选中的头导出成 model-v2-ft.npz（w1/b1/w2/b2/labels），serve_v2 直接读。
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

PKG = Path(__file__).resolve().parent.parent
LABELS = ["negative", "neutral", "positive", "surprise"]
MERGE = {
    "neutral": "neutral",
    "happy": "positive",
    "positive": "positive",
    "anger": "negative",
    "angry": "negative",
    "disgust": "negative",
    "fear": "negative",
    "sad": "negative",
    "negative": "negative",
    "surprise": "surprise",
}


def load_data(x_path: Path, meta_path: Path):
    X = np.load(x_path)
    rows = [json.loads(line) for line in meta_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != len(X):
        raise SystemExit(f"X {X.shape} 与 meta {len(rows)} 条不一致")
    y, groups = [], []
    for r in rows:
        emo = MERGE.get(str(r.get("emo", "")).lower())
        if emo is None:
            continue
        y.append(LABELS.index(emo))
        groups.append(str(r.get("spk") or r.get("f")))
    keep = np.ones(len(y), dtype=bool)
    X2 = X[keep]
    return X2, np.asarray(y, dtype=np.int64), np.asarray(groups)


def macro_f1(y_true: np.ndarray, y_pred: np.ndarray, n: int = 4) -> float:
    f1s = []
    for c in range(n):
        tp = np.sum((y_pred == c) & (y_true == c))
        fp = np.sum((y_pred == c) & (y_true != c))
        fn = np.sum((y_pred != c) & (y_true == c))
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec))
    return float(np.mean(f1s))


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def gelu(x: np.ndarray) -> np.ndarray:
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * x**3)))


def fit_linear(Xtr, ytr, Xva, yva, wd: float = 1e-3):
    import torch

    torch.manual_seed(0)
    lin = torch.nn.Linear(Xtr.shape[1], len(LABELS))
    opt = torch.optim.LBFGS(lin.parameters(), lr=0.5, max_iter=200)
    xt = torch.from_numpy(Xtr)
    yt = torch.from_numpy(ytr)

    def closure():
        opt.zero_grad()
        loss = torch.nn.functional.cross_entropy(lin(xt), yt)
        loss.backward()
        return loss

    opt.step(closure)
    with torch.no_grad():
        pred = lin(torch.from_numpy(Xva)).argmax(dim=1).numpy()
        W, b = lin.weight.detach().numpy(), lin.bias.detach().numpy()
    return pred, W, b


def fit_mlp(Xtr, ytr, Xva, yva, epochs: int = 60, patience: int = 8, seed: int = 0):
    import torch

    torch.manual_seed(seed)
    device = "cpu"
    net = torch.nn.Sequential(
        torch.nn.Linear(Xtr.shape[1], 256),
        torch.nn.GELU(),
        torch.nn.Dropout(0.2),
        torch.nn.Linear(256, len(LABELS)),
    ).to(device)
    opt = torch.optim.AdamW(net.parameters(), lr=1e-3, weight_decay=1e-2)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)

    counts = np.bincount(ytr, minlength=len(LABELS)).astype(np.float64)
    weights = torch.tensor((counts.sum() / (counts + 1e-6)) / len(LABELS), dtype=torch.float32)
    lossf = torch.nn.CrossEntropyLoss(weight=weights, label_smoothing=0.1)

    xt = torch.from_numpy(Xtr)
    yt = torch.from_numpy(ytr)
    xv = torch.from_numpy(Xva)

    best = (-1.0, None, None)
    bad = 0
    for ep in range(epochs):
        net.train()
        perm = torch.randperm(len(xt))
        for i in range(0, len(perm), 512):
            idx = perm[i : i + 512]
            opt.zero_grad()
            loss = lossf(net(xt[idx]), yt[idx])
            loss.backward()
            opt.step()
        sched.step()

        net.eval()
        with torch.no_grad():
            pred = net(xv).argmax(dim=1).numpy()
        f1 = macro_f1(yva, pred)
        if f1 > best[0] + 1e-4:
            best = (f1, {k: v.clone() for k, v in net.state_dict().items()}, ep)
            bad = 0
        else:
            bad += 1
            if bad >= patience:
                break

    sd = best[1]
    w1, b1 = sd["0.weight"].numpy(), sd["0.bias"].numpy()
    w2, b2 = sd["3.weight"].numpy(), sd["3.bias"].numpy()

    def predict(Xm):
        h = gelu(Xm @ w1.T + b1)
        return (h @ w2.T + b2).argmax(axis=1)

    return predict, (w1, b1, w2, b2), best[2]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--x", default=os.environ.get("M3ED_X", "m3ed-emo2vec/X.npy"))
    ap.add_argument("--meta", default=os.environ.get("M3ED_META", "m3ed-emo2vec/meta.jsonl"))
    ap.add_argument("--folds", type=int, default=3)
    ap.add_argument("--out", default=str(PKG / "model-v2-ft.npz"))
    args = ap.parse_args()

    X, y, groups = load_data(Path(args.x), Path(args.meta))
    print(f"[head] {X.shape} 条 / {len(np.unique(groups))} 说话人 / 类别 {np.bincount(y).tolist()}", flush=True)

    # 标准化（对 MLP 有用，对线性头也公平）
    mu = X.mean(axis=0)
    sd = X.std(axis=0) + 1e-6
    Xs = ((X - mu) / sd).astype(np.float32)

    rng = np.random.default_rng(0)
    uniq = np.unique(groups)
    rng.shuffle(uniq)
    fold_of = {g: i % args.folds for i, g in enumerate(uniq)}
    fold_ids = np.asarray([fold_of[g] for g in groups])

    res = {"linear": [], "mlp": []}
    t0 = time.time()
    for f in range(args.folds):
        tr = fold_ids != f
        va = ~tr
        pl, W, b = fit_linear(Xs[tr], y[tr], Xs[va], y[va])
        acc_l = float((pl == y[va]).mean())
        f1_l = macro_f1(y[va], pl)
        pm, (w1, b1, w2, b2), best_ep = fit_mlp(Xs[tr], y[tr], Xs[va], y[va])
        acc_m = float((pm(Xs[va]) == y[va]).mean())
        f1_m = macro_f1(y[va], pm(Xs[va]))
        res["linear"].append((acc_l, f1_l))
        res["mlp"].append((acc_m, f1_m))
        print(
            f"[head] fold{f}: linear acc {acc_l:.4f} F1 {f1_l:.4f} | mlp acc {acc_m:.4f} F1 {f1_m:.4f}（best ep {best_ep}）",
            flush=True,
        )

    lin_acc = float(np.mean([a for a, _ in res["linear"]]))
    lin_f1 = float(np.mean([f for _, f in res["linear"]]))
    mlp_acc = float(np.mean([a for a, _ in res["mlp"]]))
    mlp_f1 = float(np.mean([f for _, f in res["mlp"]]))
    print(f"[head] 平均：linear {lin_acc:.4f}/{lin_f1:.4f}   mlp {mlp_acc:.4f}/{mlp_f1:.4f}", flush=True)

    # 最终模型：全量数据训练（选表现更好的那个头）
    use_mlp = mlp_f1 > lin_f1
    if use_mlp:
        _, (w1, b1, w2, b2), _ = fit_mlp(Xs, y, Xs[:1], y[:1], epochs=20, patience=999)
    else:
        _, W, b = fit_linear(Xs, y, Xs[:1], y[:1])
        w1, b1 = W, b
        w2, b2 = np.zeros((len(LABELS), len(LABELS)), np.float32), np.zeros(len(LABELS), np.float32)

    np.savez(
        args.out,
        w1=w1.astype(np.float32),
        b1=b1.astype(np.float32),
        w2=w2.astype(np.float32),
        b2=b2.astype(np.float32),
        labels=np.array(LABELS),
        mean=mu.astype(np.float32),
        scale=sd.astype(np.float32),
        input_scaled=np.array([1], dtype=np.int8),
        arch=np.array(["mlp" if use_mlp else "linear"]),
        cv_acc=np.array([mlp_acc if use_mlp else lin_acc], dtype=np.float32),
        cv_f1=np.array([mlp_f1 if use_mlp else lin_f1], dtype=np.float32),
    )
    report = {
        "samples": int(X.shape[0]),
        "speakers": int(len(uniq)),
        "folds": args.folds,
        "linear": {"acc": lin_acc, "f1": lin_f1},
        "mlp": {"acc": mlp_acc, "f1": mlp_f1},
        "chosen": "mlp" if use_mlp else "linear",
        "seconds": round(time.time() - t0, 1),
    }
    (PKG / "head-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[head] 选 {report['chosen']}，写出 {args.out}（{report['seconds']}s）", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
