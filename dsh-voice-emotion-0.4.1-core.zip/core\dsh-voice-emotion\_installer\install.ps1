﻿# dsh-voice-emotion 一键安装（Windows）
# 用法：双击包里的「安装.exe」（有界面）；无界面时：
#   powershell -ExecutionPolicy Bypass -File _installer\install.ps1            # 自动选档位并注册
#   powershell -ExecutionPolicy Bypass -File _installer\install.ps1 -Tier full # 指定档位
#   powershell -ExecutionPolicy Bypass -File _installer\install.ps1 -NoRegister # 只装依赖，不碰 DSH 配置
param(
  [ValidateSet('auto', 'light', 'medium', 'full')] [string]$Tier = 'auto',
  [string]$TtsUrl = '',
  [switch]$NoRegister,
  [switch]$Force
)

$ErrorActionPreference = 'Stop'
$pkg = Split-Path -Parent $PSScriptRoot
Set-Location $pkg

function Info($m) { Write-Host "[安装] $m" -ForegroundColor Cyan }
function Bad($m) { Write-Host "[安装] $m" -ForegroundColor Red }

# ── 1. 找一个能用的 Python（3.10+）────────────────────────────────────────
function Find-Python {
  foreach ($c in @('python', 'py -3', 'python3')) {
    try {
      $args = $c.Split(' ')
      $v = & $args[0] $args[1..($args.Length - 1)] -c "import sys;print('%d.%d'%sys.version_info[:2])" 2>$null
      if ($LASTEXITCODE -eq 0 -and $v) {
        $p = $c.Split(' ')[0]
        $ok = ($v -split '\.')[0] -eq '3' -and [int](($v -split '\.')[1]) -ge 10
        if ($ok) { return $c }
      }
    } catch { }
  }
  return $null
}

$python = Find-Python
if (-not $python) {
  Bad '没找到 Python 3.10+。这个插件的声学部分是 Python 写的，必须先有 Python。'
  Write-Host ''
  Write-Host '  两种装法（任选一种，装完重开这个窗口）：' -ForegroundColor Yellow
  Write-Host '    1) winget install -e --id Python.Python.3.13'
  Write-Host '    2) 官网下载 https://www.python.org/downloads/windows/ （安装时勾 Add python.exe to PATH）'
  Write-Host ''
  exit 2
}
Info "用 Python：$python"

# ── 2. 决定档位：包里有模型就按包算 ─────────────────────────────────────
if ($Tier -eq 'auto') {
  if (Test-Path (Join-Path $pkg 'model-embed.onnx')) { $Tier = 'full' }
  elseif (Test-Path (Join-Path $pkg 'models\faster-whisper-small')) { $Tier = 'standard' }
  else { $Tier = 'light' }
}
Info "档位：$Tier"

# ── 3. 装依赖（幂等）────────────────────────────────────────────────────
$env:PYTHON = ($python.Split(' '))[0]
$node = (Get-Command node -ErrorAction SilentlyContinue)
if (-not $node) {
  Bad '没找到 node。DSH 自带 Node，请从 DSH 的终端里跑，或先装 Node 22+。'
  exit 2
}
Info '装 Python 依赖（第一次约 470MB，几分钟）…'
$installTier = $Tier
if ($Tier -eq 'standard') { $installTier = 'medium' }
& node (Join-Path $pkg 'tools\install.mjs') --tier $installTier
if ($LASTEXITCODE -ne 0) { Bad '依赖没装成，看上面的报错；网络不稳就重跑一次。'; exit 1 }

# ── 3.5 核包：补齐模型（全量包会跳过，因为文件已在包里）────────────────
$embed = Join-Path $pkg 'model-embed.onnx'
if (-not (Test-Path $embed)) {
  Info '这是核包，需要下载模型（约 1.1GB，装的时候要联网）…'
  & node (Join-Path $pkg 'tools\fetch-models.mjs')
  if ($LASTEXITCODE -eq 3) {
    Bad '模型没有下载地址，需要手动放。看上面的清单：把全量包里的同名文件复制进去，再重跑安装。'
    exit 3
  } elseif ($LASTEXITCODE -ne 0) {
    Bad '模型没下成。网络不稳就重跑一次（会接着上次的进度继续下）。'
    exit 1
  }
  Info '模型齐了'
}

# ── 4. 注册进 DSH（找 profile，加 dependency + bundle，做 junction）──────
if ($NoRegister) { Info '跳过注册（-NoRegister）'; exit 0 }

$profilesRoot = Join-Path $env:USERPROFILE '.dsh\profiles'
$profile = $null
if (Test-Path $profilesRoot) {
  $cands = Get-ChildItem $profilesRoot -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'package.json') }
  if ($cands.Count -eq 1) { $profile = $cands[0].FullName }
  elseif (Test-Path (Join-Path $profilesRoot 'web\package.json')) { $profile = Join-Path $profilesRoot 'web' }
}
if (-not $profile) {
  Info '没找到 DSH profile（%USERPROFILE%\.dsh\profiles\*），跳过自动注册。'
  Info "手动注册：在 profile 的 package.json 里加 `"dsh-voice-emotion`": `"link:$($pkg -replace '\\','/')`"，再把它加进 dsh.profile.bundles。"
  exit 0
}
Info "DSH profile：$profile"

$pkgJsonPath = Join-Path $profile 'package.json'
$json = Get-Content $pkgJsonPath -Raw -Encoding UTF8 | ConvertFrom-Json
$link = 'link:' + ($pkg -replace '\\', '/')
$changed = $false

if (-not $json.dependencies) { $json | Add-Member -NotePropertyName dependencies -NotePropertyValue ([pscustomobject]@{}) -Force }
if ($json.dependencies.PSObject.Properties.Name -notcontains 'dsh-voice-emotion') {
  $json.dependencies | Add-Member -NotePropertyName 'dsh-voice-emotion' -NotePropertyValue $link -Force
  $changed = $true
}
if (-not $json.dsh) { $json | Add-Member -NotePropertyName dsh -NotePropertyValue ([pscustomobject]@{}) -Force }
if (-not $json.dsh.profile) { $json.dsh | Add-Member -NotePropertyName profile -NotePropertyValue ([pscustomobject]@{}) -Force }
if (-not $json.dsh.profile.bundles) { $json.dsh.profile | Add-Member -NotePropertyName bundles -NotePropertyValue @() -Force }
if ($json.dsh.profile.bundles -notcontains 'dsh-voice-emotion') {
  $json.dsh.profile.bundles = @($json.dsh.profile.bundles) + 'dsh-voice-emotion'
  $changed = $true
}

if ($changed) {
  $backup = "$pkgJsonPath.bak-voiceemo-$([int](Get-Date -UFormat %s))"
  Copy-Item $pkgJsonPath $backup -Force
  # 不能用 Set-Content -Encoding UTF8：PowerShell 5.1 会写 BOM，DSH 读 JSON 会报 Unexpected token
  [IO.File]::WriteAllText($pkgJsonPath, ($json | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding($false)))
  Info "已写进 profile（备份 $(Split-Path $backup -Leaf)）"
} else {
  Info 'profile 里已经登记过，跳过'
}

$nm = Join-Path $profile 'node_modules\dsh-voice-emotion'
if (Test-Path $nm) {
  $item = Get-Item $nm -Force
  if ($item.LinkType -eq 'Junction' -and $item.Target -ne $pkg) { Remove-Item $nm -Force -Recurse }
}
if (-not (Test-Path $nm)) {
  New-Item -ItemType Junction -Path $nm -Target $pkg | Out-Null
  Info "已建 junction：$nm"
} else {
  Info 'node_modules 里已有链接'
}

Write-Host ''
Write-Host '  ✔ 装完了。下一步：重启 DSH（或热重载插件）就生效。' -ForegroundColor Green

# ── 5. 如果给了 TTS 地址，顺手接上（写进 profile 的 cordis.patch.yml）────
if ($TtsUrl) {
  $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
  if ($nodeExe) {
    Info "把发声接到 $TtsUrl …"
    & $nodeExe (Join-Path $pkg 'tools\set-tts.mjs') --url $TtsUrl --profile $profile
    if ($LASTEXITCODE -ne 0) { Bad '写 TTS 配置失败，可稍后手动改 config.ttsUrl / config.speak。' }
  }
}
Write-Host '    提醒：它「会听」但不自带发声引擎；voice_speak 需要宿主提供 POST /speak（默认 127.0.0.1:3120）。' -ForegroundColor Yellow
