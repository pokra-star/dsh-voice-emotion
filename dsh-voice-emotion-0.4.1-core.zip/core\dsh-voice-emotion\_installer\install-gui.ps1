# dsh-voice-emotion 图形安装器（Windows / WinForms）
# 由上一层目录的「安装.exe」拉起；也可手动：
#   powershell -ExecutionPolicy Bypass -File _installer\install-gui.ps1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$pkg = Split-Path -Parent $PSScriptRoot
$iconPath = Join-Path $pkg 'assets\icon.ico'
$logFile = Join-Path $env:TEMP ("voice-emotion-install-{0}.log" -f [int](Get-Date -UFormat %s))

$font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$fontBold = New-Object System.Drawing.Font('Microsoft YaHei UI', 11, [System.Drawing.FontStyle]::Bold)
$fontSmall = New-Object System.Drawing.Font('Microsoft YaHei UI', 8.5)

function Probe-Tts([string]$url) {
  try {
    $u = $url.TrimEnd('/') + '/health'
    $r = Invoke-WebRequest -Uri $u -TimeoutSec 2 -UseBasicParsing
    if ($r.StatusCode -eq 200) { return $true }
  } catch { }
  return $false
}

function Detect-Python {
  foreach ($c in @('python', 'py -3', 'python3')) {
    try {
      $parts = $c.Split(' ')
      $v = & $parts[0] $parts[1..($parts.Length - 1)] -c "import sys;print('%d.%d'%sys.version_info[:2])" 2>$null
      if ($LASTEXITCODE -eq 0 -and $v) {
        $ok = ($v -split '\.')[0] -eq '3' -and [int](($v -split '\.')[1]) -ge 10
        if ($ok) { return "$c ($v)" }
      }
    } catch { }
  }
  return $null
}

# ── 窗体 ────────────────────────────────────────────────────────────────
$form = New-Object System.Windows.Forms.Form
$form.Text = '语音情绪插件 · 安装器'
$form.Size = New-Object System.Drawing.Size(780, 620)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(248, 247, 251)
$form.Font = $font
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
if (Test-Path $iconPath) { $form.Icon = New-Object System.Drawing.Icon $iconPath }

$title = New-Object System.Windows.Forms.Label
$title.Text = '给她一对耳朵，和一张会变调子的嘴'
$title.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 16, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(40, 42, 74)
$title.Location = New-Object System.Drawing.Point(24, 18)
$title.AutoSize = $true
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = '运行时不联网；安装这一次需要联网。装完重启 DSH 生效。'
$sub.Font = $fontSmall
$sub.ForeColor = [System.Drawing.Color]::FromArgb(110, 112, 130)
$sub.Location = New-Object System.Drawing.Point(26, 54)
$sub.AutoSize = $true
$form.Controls.Add($sub)

# 环境检测面板
$boxEnv = New-Object System.Windows.Forms.GroupBox
$boxEnv.Text = ' 1  环境检查 '
$boxEnv.Location = New-Object System.Drawing.Point(24, 84)
$boxEnv.Size = New-Object System.Drawing.Size(716, 104)
$form.Controls.Add($boxEnv)

$lblPy = New-Object System.Windows.Forms.Label
$lblPy.Location = New-Object System.Drawing.Point(16, 26); $lblPy.AutoSize = $true
$boxEnv.Controls.Add($lblPy)
$lblNode = New-Object System.Windows.Forms.Label
$lblNode.Location = New-Object System.Drawing.Point(16, 50); $lblNode.AutoSize = $true
$boxEnv.Controls.Add($lblNode)
$lblDsh = New-Object System.Windows.Forms.Label
$lblDsh.Location = New-Object System.Drawing.Point(16, 74); $lblDsh.AutoSize = $true
$boxEnv.Controls.Add($lblDsh)

$btnRecheck = New-Object System.Windows.Forms.Button
$btnRecheck.Text = '重新检测'
$btnRecheck.Location = New-Object System.Drawing.Point(596, 62)
$btnRecheck.Size = New-Object System.Drawing.Size(104, 28)
$boxEnv.Controls.Add($btnRecheck)

# 发声（TTS）
$boxTts = New-Object System.Windows.Forms.GroupBox
$boxTts.Text = ' 2  发声（可选）—— 插件不带 TTS 引擎 '
$boxTts.Location = New-Object System.Drawing.Point(24, 200)
$boxTts.Size = New-Object System.Drawing.Size(716, 108)
$form.Controls.Add($boxTts)

$chkTts = New-Object System.Windows.Forms.CheckBox
$chkTts.Text = '我有 TTS 服务，帮我接上（开箱就能说话）'
$chkTts.Location = New-Object System.Drawing.Point(16, 26)
$chkTts.AutoSize = $true
$boxTts.Controls.Add($chkTts)

$txtTts = New-Object System.Windows.Forms.TextBox
$txtTts.Text = 'http://127.0.0.1:3120'
$txtTts.Location = New-Object System.Drawing.Point(38, 56)
$txtTts.Size = New-Object System.Drawing.Size(360, 26)
$txtTts.Enabled = $false
$boxTts.Controls.Add($txtTts)

$btnTts = New-Object System.Windows.Forms.Button
$btnTts.Text = '测试'
$btnTts.Location = New-Object System.Drawing.Point(408, 55)
$btnTts.Size = New-Object System.Drawing.Size(80, 28)
$btnTts.Enabled = $false
$boxTts.Controls.Add($btnTts)

$lblTts = New-Object System.Windows.Forms.Label
$lblTts.Text = '没有 TTS？也能装：只做「听」，之后随时把 config.speak 改成 "on"。'
$lblTts.Font = $fontSmall
$lblTts.ForeColor = [System.Drawing.Color]::FromArgb(110, 112, 130)
$lblTts.Location = New-Object System.Drawing.Point(16, 82)
$lblTts.AutoSize = $true
$boxTts.Controls.Add($lblTts)

# 安装
$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = '开始安装'
$btnInstall.Font = $fontBold
$btnInstall.Location = New-Object System.Drawing.Point(24, 320)
$btnInstall.Size = New-Object System.Drawing.Size(716, 44)
$btnInstall.BackColor = [System.Drawing.Color]::FromArgb(214, 92, 140)
$btnInstall.ForeColor = [System.Drawing.Color]::White
$btnInstall.FlatStyle = 'Flat'
$form.Controls.Add($btnInstall)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(24, 372)
$progress.Size = New-Object System.Drawing.Size(716, 10)
$form.Controls.Add($progress)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = 'Vertical'
$logBox.Location = New-Object System.Drawing.Point(24, 392)
$logBox.Size = New-Object System.Drawing.Size(716, 160)
$logBox.BackColor = [System.Drawing.Color]::FromArgb(24, 26, 38)
$logBox.ForeColor = [System.Drawing.Color]::FromArgb(220, 230, 240)
$logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($logBox)

function Log([string]$m) {
  $logBox.AppendText(("{0}  {1}`r`n" -f (Get-Date -Format 'HH:mm:ss'), $m))
}

function Refresh-Env {
  $py = Detect-Python
  $lblPy.Text = if ($py) { "✔ Python：$py" } else { "✘ 没找到 Python 3.10+（安装时会提示一条 winget 命令）" }
  $lblPy.ForeColor = if ($py) { [System.Drawing.Color]::FromArgb(30, 130, 80) } else { [System.Drawing.Color]::FromArgb(190, 60, 60) }
  $node = Get-Command node -ErrorAction SilentlyContinue
  $lblNode.Text = if ($node) { "✔ Node：$(& node -v)" } else { "✘ 没找到 node（DSH 自带，从 DSH 终端跑或先装 Node 22+）" }
  $lblNode.ForeColor = if ($node) { [System.Drawing.Color]::FromArgb(30, 130, 80) } else { [System.Drawing.Color]::FromArgb(190, 60, 60) }
  $prof = Join-Path $env:USERPROFILE '.dsh\profiles'
  $has = $false
  if (Test-Path $prof) { $has = @(Get-ChildItem $prof -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'package.json') }).Count -gt 0 }
  $lblDsh.Text = if ($has) { "✔ 找到 DSH profile：$prof" } else { "✘ 没找到 DSH（%USERPROFILE%\.dsh\profiles），装完要手动登记" }
  $lblDsh.ForeColor = if ($has) { [System.Drawing.Color]::FromArgb(30, 130, 80) } else { [System.Drawing.Color]::FromArgb(190, 60, 60) }
  $t = Probe-Tts 'http://127.0.0.1:3120'
  if ($t) {
    $chkTts.Checked = $true
    Log '检测到本机 3120 有 TTS，已自动勾选「接上」。'
  }
}

$chkTts.Add_CheckedChanged({ $txtTts.Enabled = $chkTts.Checked; $btnTts.Enabled = $chkTts.Checked })
$btnTts.Add_Click({
  $url = $txtTts.Text.Trim()
  if (Probe-Tts $url) { [System.Windows.Forms.MessageBox]::Show("连通了：$url", 'TTS 测试'); Log "TTS 可用：$url" }
  else { [System.Windows.Forms.MessageBox]::Show("连不上 $url`n确认服务已启动、地址带端口。", 'TTS 测试', 'OK', 'Warning'); Log "TTS 连不上：$url" }
})
$btnRecheck.Add_Click({ Refresh-Env })

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 700
$script:readPos = 0
$script:proc = $null
$timer.Add_Tick({
  if (-not (Test-Path $logFile)) { return }
  $fs = [IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
  try {
    $fs.Seek($script:readPos, 'Begin') | Out-Null
    $sr = New-Object IO.StreamReader($fs)
    $chunk = $sr.ReadToEnd()
    if ($chunk) { $logBox.AppendText($chunk); $script:readPos = $fs.Position }
    $sr.Dispose()
  } finally { $fs.Dispose() }
  if ($script:proc -and $script:proc.HasExited) {
    $timer.Stop()
    $progress.Style = 'Blocks'
    $progress.Value = 100
    if ($script:proc.ExitCode -eq 0) {
      $btnInstall.Text = '装完了 ✔  请重启 DSH'
      $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(60, 160, 110)
      [System.Windows.Forms.MessageBox]::Show("装完了。`n`n下一步：完全关掉 DSH 窗口再打开（或让 DSH 管理员热重载插件）。", '完成')
    } else {
      $btnInstall.Text = '失败了，看下面的日志'
      $btnInstall.BackColor = [System.Drawing.Color]::FromArgb(190, 70, 70)
      [System.Windows.Forms.MessageBox]::Show('安装没成功。日志在上面，也可以把日志文件发给帮你装的人。', '失败', 'OK', 'Error')
    }
  }
})

$btnInstall.Add_Click({
  $btnInstall.Enabled = $false
  $progress.Style = 'Marquee'
  $progress.MarqueeAnimationSpeed = 30
  Remove-Item $logFile -ErrorAction SilentlyContinue
  $script:readPos = 0
  $tier = 'auto'
  $args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'install.ps1'), '-Tier', $tier)
  if ($chkTts.Checked) { $args += @('-TtsUrl', $txtTts.Text.Trim()) }
  $cmd = 'powershell ' + ($args | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' '
  Log "执行：$cmd"
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = 'cmd.exe'
  $psi.Arguments = '/c ' + $cmd + ' > "' + $logFile + '" 2>&1'
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $script:proc = [System.Diagnostics.Process]::Start($psi)
  $timer.Start()
})

Refresh-Env
Log "包目录：$pkg"
if (Test-Path (Join-Path $pkg 'model-embed.onnx')) {
    Log '点「开始安装」；装依赖大约几分钟（首次约 470MB）。模型在包里，不用另下。'
  } else {
    Log '点「开始安装」；先装依赖（约 470MB，几分钟），再下模型（约 1.1GB，装这一次要联网）。'
  }
[void]$form.ShowDialog()
