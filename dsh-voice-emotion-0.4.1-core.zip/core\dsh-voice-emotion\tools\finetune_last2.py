"""在 CPU 上微调 emotion2vec_plus_large 的最后两层 + 一个 4 类头。

只训最后两层，不动下面 20 层：数据只有 2 万条、说话人 700 来个，全解冻必然记人。
防过拟合的手段：冻结下层、按说话人分组切验证、label smoothing、dropout、weight decay、
类别平衡采样、按验证集 macro-F1 早停。

用法：
    python tools/finetune_last2.py --epochs 3 --per-class 1200 --out finetune-best.pt
    python tools/finetune_last2.py --smoke 200     # 只跑 200 条，验证脚本能跑通

产出：
    finetune-best.pt          最好那一轮的「最后两层 + norm + 头」权重
    model-v2-ft.json          换成微调头的 4 类线性头（numpy 版，给 ONNX 推理用）
    tmp/finetune-progress.json 进度（给每小时报备用）
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

HOME = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
MODEL_DIR = HOME / "models" / "models" / "iic--emotion2vec_plus_large" / "snapshots" / "master"
PKG = Path(__file__).resolve().parent.parent
MANIFEST = PKG.parent.parent / "tmp" / "m3ed-manifest.json"
PROGRESS = PKG.parent.parent / "tmp" / "finetune-progress.json"

MERGE = {
    "neutral": "neutral",
    "happy": "positive",
    "surprise": "surprise",
    "anger": "negative",
    "sad": "negative",
    "disgust": "negative",
    "fear": "negative",
}
LABELS = ["negative", "neutral", "positive", "surprise"]
SR = 16000
CLIP_SECONDS = 4.0


def write_progress(**kw) -> None:
    kw["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    PROGRESS.parent.mkdir(parents=True, exist_ok=True)
    PROGRESS.write_text(json.dumps(kw, ensure_ascii=False), encoding="utf-8")


def load_rows(per_class: int, seed: int = 7) -> list[dict]:
    rows = json.loads(MANIFEST.read_text(encoding="utf-8"))
    buckets: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        emo = MERGE.get(str(r.get("emo", "")).lower())
        if not emo:
            continue
        path = r.get("f")
        if not path or not Path(path).exists():
            continue
        buckets[emo].append({"f": path, "spk": r.get("spk") or "?", "y": LABELS.index(emo)})

    rng = random.Random(seed)
    out: list[dict] = []
    for label, items in buckets.items():
        rng.shuffle(items)
        out.extend(items[: min(per_class, len(items))])
    rng.shuffle(out)
    return out


def speaker_split(rows: list[dict], val_ratio: float = 0.2, seed: int = 11) -> tuple[list[dict], list[dict]]:
    speakers = sorted({r["spk"] for r in rows})
    rng = random.Random(seed)
    rng.shuffle(speakers)
    n_val = max(1, int(len(speakers) * val_ratio))
    val_spk = set(speakers[:n_val])
    train = [r for r in rows if r["spk"] not in val_spk]
    val = [r for r in rows if r["spk"] in val_spk]
    return train, val


def load_clip(path: str) -> torch.Tensor | None:
    try:
        wav, sr = sf.read(path, dtype="float32", always_2d=False)
    except Exception:
        return None
    if wav.ndim > 1:
        wav = wav.mean(axis=1)
    if sr != SR:
        import librosa

        wav = librosa.resample(wav, orig_sr=sr, target_sr=SR)
    n = int(SR * CLIP_SECONDS)
    if len(wav) >= n:
        start = (len(wav) - n) // 2
        wav = wav[start : start + n]
    else:
        wav = np.pad(wav, (0, n - len(wav)))
    peak = float(np.max(np.abs(wav))) or 1.0
    if peak > 1.0:
        wav = wav / peak
    return torch.from_numpy(wav.astype(np.float32))[None, :]


class FineTuner(torch.nn.Module):
    def __init__(self, model, num_classes: int = 4, dropout: float = 0.2):
        super().__init__()
        self.model = model
        self.normalize = bool(getattr(model.cfg, "normalize", False))
        hidden = 1024
        self.head = torch.nn.Sequential(
            torch.nn.Linear(hidden, 256),
            torch.nn.GELU(),
            torch.nn.Dropout(dropout),
            torch.nn.Linear(256, num_classes),
        )

    def forward(self, wav: torch.Tensor, trainable_from: int) -> torch.Tensor:
        if self.normalize:
            mean = wav.mean(dim=-1, keepdim=True)
            var = (wav - mean).pow(2).mean(dim=-1, keepdim=True)
            wav = (wav - mean) / torch.sqrt(var + 1e-5)

        m = self.model
        fe = m.modality_encoders["AUDIO"]
        with torch.no_grad():
            out = fe(wav, None, False, remove_masked=True, clone_batch=1, mask_seeds=None, precomputed_mask=None)
            x = out["x"]
            masked_padding_mask = out["padding_mask"]
            masked_alibi_bias = out.get("alibi_bias", None)
            alibi_scale = out.get("alibi_scale", None)
            if m.dropout_input is not None:
                x = m.dropout_input(x)

        blocks = m.blocks
        for i, blk in enumerate(blocks):
            ab = masked_alibi_bias
            if ab is not None and alibi_scale is not None and alibi_scale.size(0) > 1:
                ab = ab * alibi_scale[i].type_as(ab)
            if i < trainable_from:
                with torch.no_grad():
                    x = blk(x, padding_mask=masked_padding_mask, alibi_bias=ab)[0]
            else:
                x = blk(x, padding_mask=masked_padding_mask, alibi_bias=ab)[0]

        if m.norm is not None:
            x = m.norm(x)
        pooled = x.mean(dim=1)
        return self.head(pooled)


def baseline_eval(rows: list[dict]) -> tuple[float, float]:
    """用现有的 ONNX embedding + model-v2.json 线性头，在同一批验证样本上打一次分。

    这样报告里的「微调前 / 微调后」是同一个验证集、同一群说话人，能直接比。
    """
    import onnxruntime as ort
    import soundfile as sf

    onnx_path = PKG / "model-embed.onnx"
    head_path = PKG / "model-v2.json"
    if not onnx_path.exists() or not head_path.exists():
        return (float("nan"), float("nan"))
    head = json.loads(head_path.read_text(encoding="utf-8"))
    mean = np.asarray(head["mean"], np.float64)
    scale = np.asarray(head["scale"], np.float64)
    coef = np.asarray(head["coef"], np.float64)
    inter = np.asarray(head["intercept"], np.float64)
    labels = head["labels"]
    sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    cm = np.zeros((len(LABELS), len(LABELS)), dtype=int)
    for r in rows:
        clip = load_clip(r["f"])
        if clip is None:
            continue
        emb = sess.run(None, {"wav": clip.numpy()})[0].ravel().astype(np.float64)
        logits = ((emb - mean) / scale) @ coef.T + inter
        pred = int(np.argmax(logits))
        pred_label = labels[pred]
        cm[LABELS.index(pred_label)][pred] += 1
    total = cm.sum()
    acc = float(np.trace(cm) / total) if total else 0.0
    f1s = []
    for i in range(len(LABELS)):
        tp = cm[i][i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec))
    return acc, float(np.mean(f1s))


def build_model() -> tuple[FineTuner, int]:
    from funasr import AutoModel

    auto = AutoModel(
        model="iic/emotion2vec_plus_large",
        model_path=str(MODEL_DIR),
        disable_update=True,
        device="cpu",
        disable_pbar=True,
        log_level="ERROR",
    )
    model = auto.model
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    total = len(model.blocks)
    trainable_from = total - 2
    for blk in model.blocks[trainable_from:]:
        for p in blk.parameters():
            p.requires_grad_(True)
    if model.norm is not None:
        for p in model.norm.parameters():
            p.requires_grad_(True)
    ft = FineTuner(model)
    for p in ft.head.parameters():
        p.requires_grad_(True)
    return ft, trainable_from


def evaluate(ft: FineTuner, trainable_from: int, rows: list[dict]) -> tuple[float, float, list[list[int]]]:
    ft.eval()
    cm = np.zeros((len(LABELS), len(LABELS)), dtype=int)
    with torch.no_grad():
        for r in rows:
            clip = load_clip(r["f"])
            if clip is None:
                continue
            logits = ft(clip, trainable_from)
            pred = int(logits.argmax(dim=-1))
            cm[r["y"]][pred] += 1
    total = cm.sum()
    acc = float(np.trace(cm) / total) if total else 0.0
    f1s = []
    for i in range(len(LABELS)):
        tp = cm[i][i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec))
    return acc, float(np.mean(f1s)), cm.tolist()


def balanced_batches(rows: list[dict], batch_size: int, seed: int):
    by_class: dict[int, list[dict]] = defaultdict(list)
    for r in rows:
        by_class[r["y"]].append(r)
    rng = random.Random(seed)
    order: list[dict] = []
    classes = [c for c, items in by_class.items() if items]
    while True:
        rng.shuffle(classes)
        for c in classes:
            items = by_class[c]
            if items:
                order.append(rng.choice(items))
        if len(order) >= len(rows):
            break
        if all(len(by_class[c]) < 2 for c in classes):
            break
    rng.shuffle(order)
    for i in range(0, len(order), batch_size):
        yield order[i : i + batch_size]


def save_state(ft: FineTuner, trainable_from: int, path: Path, meta: dict) -> None:
    blocks = ft.model.blocks
    state = {
        "blocks": {f"{i}": blocks[i].state_dict() for i in range(trainable_from, len(blocks))},
        "norm": ft.model.norm.state_dict() if ft.model.norm is not None else None,
        "head": ft.head.state_dict(),
    }
    torch.save({"state": state, "meta": meta}, path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-class", type=int, default=1200)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch-size", type=int, default=6)
    ap.add_argument("--lr-blocks", type=float, default=3e-5)
    ap.add_argument("--lr-head", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--patience", type=int, default=1)
    ap.add_argument("--smoke", type=int, default=0, help="只取 N 条跑一遍流程，用来验证脚本")
    ap.add_argument("--out", default=str(PKG / "finetune-best.pt"))
    args = ap.parse_args()

    torch.manual_seed(7)
    random.seed(7)
    torch.set_num_threads(max(1, (os.cpu_count() or 4) - 2))

    rows = load_rows(args.per_class)
    if args.smoke:
        random.Random(3).shuffle(rows)
        rows = rows[: args.smoke]
    train, val = speaker_split(rows)
    counts = Counter(LABELS[r["y"]] for r in train)
    print(f"[fit] 训练 {len(train)} 条 / 验证 {len(val)} 条，说话人 {len({r['spk'] for r in train})}/{len({r['spk'] for r in val})}", flush=True)
    print(f"[fit] 类别分布 {dict(counts)}", flush=True)

    write_progress(stage="init", total=len(train), done=0, epoch=0, total_epochs=args.epochs)

    if os.environ.get("FT_SKIP_BASELINE") == "1":
        base_acc, base_f1 = float("nan"), float("nan")
        print("[fit] 跳过微调前基线（FT_SKIP_BASELINE=1）", flush=True)
    else:
        base_acc, base_f1 = baseline_eval(val)
        print(f"[fit] 微调前（同一验证集）：acc {base_acc:.4f} macroF1 {base_f1:.4f}", flush=True)

    t0 = time.time()
    ft, trainable_from = build_model()
    print(f"[fit] 模型就绪（{time.time() - t0:.0f}s），解冻 blocks[{trainable_from}:]", flush=True)

    block_params = [
        p for i in range(trainable_from, len(ft.model.blocks)) for p in ft.model.blocks[i].parameters() if p.requires_grad
    ]
    if ft.model.norm is not None:
        block_params += [p for p in ft.model.norm.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(
        [
            {"params": block_params, "lr": args.lr_blocks},
            {"params": list(ft.head.parameters()), "lr": args.lr_head},
        ],
        weight_decay=args.weight_decay,
    )
    criterion = torch.nn.CrossEntropyLoss(label_smoothing=0.1)

    best_f1, best_epoch, bad_epochs = -1.0, 0, 0
    for epoch in range(1, args.epochs + 1):
        ft.train()
        ft.model.eval()  # dropout/BN 保持推理态，只有最后两层的 dropout 想生效的话改成 train
        for blk in ft.model.blocks[trainable_from:]:
            blk.train()
        ft.head.train()

        running, seen = 0.0, 0
        epoch_start = time.time()
        for batch in balanced_batches(train, args.batch_size, seed=epoch):
            clips, labels = [], []
            for r in batch:
                clip = load_clip(r["f"])
                if clip is None:
                    continue
                clips.append(clip)
                labels.append(r["y"])
            if not clips:
                continue
            x = torch.cat(clips, dim=0)
            y = torch.tensor(labels, dtype=torch.long)
            logits = ft(x, trainable_from)
            loss = criterion(logits, y)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in ft.parameters() if p.requires_grad], 1.0)
            optimizer.step()

            running += float(loss.item()) * len(labels)
            seen += len(labels)
            if seen % 60 == 0 or seen == len(train):
                avg = running / max(1, seen)
                per = (time.time() - epoch_start) / max(1, seen)
                eta = per * (len(train) - seen) / 60
                print(f"[fit] e{epoch} {seen}/{len(train)} loss {avg:.4f} {per:.2f}s/条 eta {eta:.0f}min", flush=True)
                write_progress(
                    stage="train",
                    epoch=epoch,
                    total_epochs=args.epochs,
                    done=seen,
                    total=len(train),
                    loss=avg,
                    val_f1=best_f1 if best_f1 >= 0 else None,
                    eta_min=eta,
                )

        acc, f1, cm = evaluate(ft, trainable_from, val)
        print(f"[fit] e{epoch} 验证 acc {acc:.4f} macroF1 {f1:.4f}", flush=True)
        print(f"[fit] 混淆矩阵 {cm}", flush=True)
        write_progress(
            stage="train",
            epoch=epoch,
            total_epochs=args.epochs,
            done=len(train),
            total=len(train),
            val_acc=acc,
            val_f1=f1,
            best_f1=max(best_f1, f1),
            eta_min=0,
        )

        if f1 > best_f1:
            best_f1, best_epoch, bad_epochs = f1, epoch, 0
            save_state(ft, trainable_from, Path(args.out), {"val_acc": acc, "val_f1": f1, "epoch": epoch, "labels": LABELS})
            print(f"[fit] 存了最好的一版（F1 {f1:.4f}）", flush=True)
        else:
            bad_epochs += 1
            if bad_epochs > args.patience:
                print("[fit] 验证集不再涨，早停", flush=True)
                break

    # 把微调后的头导出成 numpy，推理那边直接用
    head = ft.head.state_dict()
    w1 = head["0.weight"].detach().numpy().astype(np.float32)
    b1 = head["0.bias"].detach().numpy().astype(np.float32)
    w2 = head["3.weight"].detach().numpy().astype(np.float32)
    b2 = head["3.bias"].detach().numpy().astype(np.float32)
    np.savez(
        PKG / "model-v2-ft.npz",
        w1=w1,
        b1=b1,
        w2=w2,
        b2=b2,
        labels=np.array(LABELS),
        val_f1=np.array([best_f1], dtype=np.float32),
        val_acc=np.array([0.0], dtype=np.float32),
    )
    write_progress(
        stage="done",
        epoch=best_epoch,
        total_epochs=args.epochs,
        done=len(train),
        total=len(train),
        best_f1=best_f1,
        best_epoch=best_epoch,
    )
    print(f"[fit] 结束，最好 F1 {best_f1:.4f} @ epoch {best_epoch}；权重 {args.out}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
