import test from 'node:test';
import assert from 'node:assert/strict';
import { CLASSES } from '../lib/fusion.mjs';
import { calibrateFusion, fitAbstain, fitTemperature } from '../lib/fusion-calibrate.mjs';

function row(label, p) {
  const probs = CLASSES.map((c) => (c === label ? p : (1 - p) / 3));
  return { label, text: '', model: { probs } };
}

const rows = [
  ...Array.from({ length: 10 }, () => row('negative', 0.9)),
  ...Array.from({ length: 10 }, () => row('neutral', 0.9)),
  ...Array.from({ length: 10 }, () => row('positive', 0.9)),
  ...Array.from({ length: 10 }, () => row('surprise', 0.9)),
];

test('温度网格会返回一个有限的最优点和 Brier', () => {
  const t = fitTemperature(rows);
  assert.ok(Number.isFinite(t.temperature));
  assert.ok(t.brier >= 0 && t.brier <= 1);
  assert.equal(t.n, 40);
});

test('弃权门槛会返回覆盖率与选择性准确率', () => {
  const a = fitAbstain(rows, { temperature: 1.5 });
  assert.ok(a.coverage > 0);
  assert.ok(a.selectiveAccuracy > 0.9);
  assert.ok(a.minPosterior >= 0.3 && a.minPosterior <= 0.8);
});

test('一次校准输出可直接落配置的四个参数', () => {
  const c = calibrateFusion(rows);
  for (const k of ['temperature', 'minPosterior', 'minMargin']) {
    assert.ok(Number.isFinite(c[k]), `${k} 不是数字`);
  }
  assert.ok(c.coverage >= 0 && c.coverage <= 1);
  assert.ok(c.selectiveAccuracy >= 0 && c.selectiveAccuracy <= 1);
});
