const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const LABELS = {
  neutral: ['平常', 'neutral'], happy: ['开心', 'happy'], surprised: ['惊讶', 'surprised'],
  angry: ['生气', 'angry'], complaint: ['吐槽', 'complaint'], firm: ['坚定', 'firm'],
  urgent: ['催促', 'urgent'], anxious: ['不安', 'anxious'], sad: ['低落', 'sad'],
  soft: ['温柔', 'soft'], tired: ['无奈', 'tired'], lazy: ['慵懒', 'lazy'], aggrieved: ['委屈', 'aggrieved'],
};

let state = null;
let toastTimer = null;

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'content-type': 'application/json', ...(opts.headers || {}) },
  });
  const ct = res.headers.get('content-type') || '';
  if (!ct.includes('json')) {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res;
  }
  const j = await res.json();
  if (!res.ok || j.ok === false) throw new Error(j.error || `HTTP ${res.status}`);
  return j;
}

function fmtBytes(n) {
  if (!Number.isFinite(n) || n <= 0) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i += 1; }
  return `${v >= 100 ? v.toFixed(0) : v.toFixed(1)} ${u[i]}`;
}

function fmtNum(n) {
  return Number(n || 0).toLocaleString('zh-CN');
}

const TITLES = {
  overview: ['概览', '今天她替你多花了多少。'],
  tts: ['TTS', '声音从哪来，坏了先看这里。'],
  disk: ['占用', '模型、缓存、临时文件，各占多少。'],
  tuning: ['情绪', '同一句话，换个语气；底下是真人参考值。'],
  voice: ['发语音', '什么时候出声，掷骰子决定。'],
};

function setPage(name) {
  $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.page === name));
  $$('.page').forEach((p) => p.classList.toggle('active', p.id === `page-${name}`));
  const [t, s] = TITLES[name] || ['', ''];
  $('#page-title').textContent = t;
  $('#page-sub').textContent = s;
}

function renderCaps() {
  const caps = state.caps;
  $$('[data-cap]').forEach((el) => {
    const cap = el.dataset.cap;
    el.hidden = !caps[cap];
  });
  const v = caps.variant || {};
  const label = caps.speak && caps.listen ? '说 + 听 · full' : caps.speak ? '说 · speak' : '听 · listen';
  $('#variant').textContent = label;
  $('#listen-only-note').hidden = !(caps.listen && !caps.speak);
  if (!caps.speak && caps.listen) {
    // 这版没有 TTS，别停在看不见的页上
    setPage('overview');
  }
}

function renderTts() {
  const t = state.tts || {};
  $('#tts-url').value = state.config?.ttsUrl || '';
  $('#price-input').value = state.config?.pricePerM ?? 2;
  const ok = t.ok === true;
  $('#tts-dot').className = `dot ${ok ? 'ok' : 'bad'}`;
  $('#tts-state').textContent = ok ? 'TTS 在线' : 'TTS 离线';
  $('#tts-pill').textContent = ok ? '在线' : '离线';
  $('#tts-pill').className = `pill ${ok ? 'ok' : 'bad'}`;
  const params = t.params ? Object.entries(t.params).map(([k, v]) => `${k} ${v}`).join(' · ') : '—';
  $('#health').innerHTML = [
    ['状态', ok ? 'ok' : (t.error || '连不上')],
    ['引擎', t.engine || '—'],
    ['参考音色', t.refer || '—'],
    ['参数', params],
  ].map(([k, v]) => `<div><span>${k}</span><b>${escapeHtml(String(v))}</b></div>`).join('');
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function renderOverview() {
  const tk = state.tokens || {};
  $('#tokens').textContent = fmtNum(tk.extraTokens);
  $('#cost').textContent = Number(tk.cost || 0).toFixed(2);
  $('#price').textContent = tk.pricePerM ?? 2;
  $('#requests').textContent = fmtNum(tk.requests);
  $('#toolcount').textContent = fmtNum(tk.toolCount);
  $('#total-size').textContent = fmtBytes(state.disk?.total);
  $('#token-note').textContent = tk.toolCount
    ? (tk.note || '')
    : '当前会话里没检测到插件工具——插件可能还没加载。这个数字只算实际带进上下文的工具定义。';
  $('#scanned').textContent = fmtNum(tk.scannedFiles);
  $('#scan-time').textContent = tk.at ? new Date(tk.at).toLocaleTimeString('zh-CN', { hour12: false }) : '—';
  const per = tk.requests && tk.extraTokens ? Math.round(tk.extraTokens / tk.requests) : 0;
  $('#meter-tools-val').textContent = per ? `${fmtNum(per)} / 次` : '—';
  const pct = Math.min(100, (per / 20000) * 100);
  $('#meter-tools').style.width = `${pct}%`;
}

function renderDisk() {
  const d = state.disk || { items: [], total: 0, free: 0 };
  $('#disk-total').textContent = fmtBytes(d.total);
  $('#disk-free').textContent = fmtBytes(d.free);
  const total = Math.max(1, d.total);
  $('#disk-list').innerHTML = (d.items || []).map((it) => {
    const cleanable = ['tmp', 'home', 'tts'].includes(it.id);
    const pct = Math.max(1, Math.min(100, (it.bytes / total) * 100));
    return `<div class="disk-row">
      <div><div class="disk-name">${escapeHtml(it.label)}</div><div class="disk-hint">${escapeHtml(it.hint || '')}</div></div>
      <div class="disk-bar"><i style="width:${pct}%"></i></div>
      <div class="disk-size">${fmtBytes(it.bytes)}</div>
      ${cleanable
        ? `<button class="ghost" data-clean="${it.id}">清理</button>`
        : `<button class="ghost" disabled>保留</button>`}
    </div>`;
  }).join('');
  $$('[data-clean]').forEach((b) => b.addEventListener('click', () => doClean(b.dataset.clean, b)));
}

async function doClean(id, btn) {
  const names = { tmp: '临时文件', home: '运行时缓存', tts: '24 小时前的 TTS 语音' };
  if (!confirm(`清理${names[id] || id}？删了就找不回来。`)) return;
  btn.disabled = true;
  try {
    const r = await api('/api/clean', { method: 'POST', body: JSON.stringify({ id }) });
    toast(`清掉了 ${fmtBytes(r.freed)}`);
    await loadStatus(false);
  } catch (e) {
    toast(`没清成：${e.message}`);
  } finally {
    btn.disabled = false;
  }
}

let tuningDirty = false;

function renderTuning() {
  const t = state.tuning;
  if (!t) return;
  $('#tuning-note').textContent = t.overridden
    ? `已改过 ${t.overridden} 组参数；保存后下一次合成生效。`
    : '现在是默认值；保存后下一次合成生效。';
  const host = $('#tuning-list');
  host.innerHTML = '';
  for (const [key, shape] of Object.entries(t.shapes)) {
    const [zh, en] = LABELS[key] || [key, key];
    const row = document.createElement('div');
    row.className = 'tuning-row';
    row.dataset.key = key;
    row.innerHTML = `
      <div class="tuning-name">${zh}<small>${en}</small></div>
      ${slider('speed', shape.speed, 0.8, 1.2, 0.01)}
      ${slider('gain', shape.gain, -4, 4, 0.1)}
      ${slider('lead', shape.lead, 0, 260, 1)}
      ${slider('bright', shape.bright, -2, 2, 0.1)}
      ${slider('f0', t.f0[key] ?? 220, 170, 280, 1)}
    `;
    host.appendChild(row);
  }
  $$('.tuning-cell input', host).forEach((inp) => {
    inp.addEventListener('input', () => {
      const out = inp.parentElement.querySelector('output');
      out.textContent = Number(inp.value).toFixed(inp.dataset.k === 'lead' || inp.dataset.k === 'f0' ? 0 : 2);
      inp.closest('.tuning-row').classList.add('changed');
      tuningDirty = true;
    });
  });
}

function slider(k, value, min, max, step) {
  const digits = k === 'lead' || k === 'f0' ? 0 : 2;
  return `<div class="tuning-cell"><input type="range" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${value}"><output>${Number(value).toFixed(digits)}</output></div>`;
}

const VP_ROWS = [
  { k: 'normalProb', label: '文字转语音概率（平常）', min: 0, max: 100, step: 5, unit: '%',
    hint: '她本来要发文字时，有多大机会改成语音。太高会吵，太低就只剩打字。' },
  { k: 'strongProb', label: '文字转语音概率（激动）', min: 0, max: 100, step: 5, unit: '%',
    hint: '情绪强度过了阈值就用这一档。' },
  { k: 'strongIntensity', label: '激动判定阈值', min: 0, max: 1, step: 0.05, unit: '',
    digits: 2, hint: '情绪强度 ≥ 这个值就算激动。调低＝更容易当成激动。' },
  { k: 'dailyLimit', label: '每天上限', min: 0, max: 200, step: 1, unit: '条', zero: '不限',
    hint: '超过就当天不再转语音，只打字。' },
  { k: 'minIntervalSec', label: '最小间隔', min: 0, max: 600, step: 10, unit: '秒', zero: '不限',
    hint: '两条语音之间至少隔这么久。' },
];

function vpFmt(row, v) {
  const n = Number(v);
  if (row.zero && n === 0) return row.zero;
  const digits = row.digits ?? 0;
  return `${n.toFixed(digits)}${row.unit}`;
}

function renderVoice() {
  const p = (state && state.voicePolicy) || {};
  const host = $('#voice-list');
  if (!host) return;
  host.innerHTML = VP_ROWS.map((row) => {
    const v = p[row.k] ?? row.min;
    return `<div class="tuning-row">
      <div class="tuning-name">${row.label}</div>
      <div class="tuning-cell">
        <input type="range" data-k="${row.k}" min="${row.min}" max="${row.max}" step="${row.step}" value="${v}">
        <small class="hint">${row.hint}</small>
      </div>
      <div class="tuning-cell"><output data-out="${row.k}">${vpFmt(row, v)}</output></div>
    </div>`;
  }).join('');
  $$('#voice-list input[type="range"]').forEach((inp) => {
    inp.addEventListener('input', () => {
      const row = VP_ROWS.find((r) => r.k === inp.dataset.k);
      const out = $(`output[data-out="${inp.dataset.k}"]`);
      if (out && row) out.textContent = vpFmt(row, inp.value);
      inp.closest('.tuning-row').classList.add('changed');
      voiceDirty = true;
    });
  });
  const note = $('#voice-note');
  if (note) {
    note.textContent = `保存立刻生效，下一条文字回复就按新概率掷；不重启桥接。当前：平常 ${p.normalProb ?? '—'}% 改成语音、激动 ${p.strongProb ?? '—'}%、阈值 ${p.strongIntensity ?? '—'}、上限 ${p.dailyLimit ? p.dailyLimit + ' 条/天' : '不限'}、间隔 ${p.minIntervalSec ? p.minIntervalSec + ' 秒' : '不限'}。`;
  }
  voiceDirty = false;
}

function collectVoice() {
  const out = {};
  $$('#voice-list input[type="range"]').forEach((inp) => { out[inp.dataset.k] = Number(inp.value); });
  return out;
}

async function saveVoice() {
  const r = await api('/api/voicepolicy', { method: 'POST', body: JSON.stringify(collectVoice()) });
  state.voicePolicy = r.policy;
  renderVoice();
  toast('已保存，下一条回复就按这组掷');
}

async function saveVoiceAsDefaults() {
  const r = await api('/api/voicepolicy/defaults', { method: 'POST', body: JSON.stringify(collectVoice()) });
  state.voicePolicy = r.policy;
  renderVoice();
  toast('已存为默认值（文件丢了也回到这组）');
}

let voiceDirty = false;
let emphDirty = false;

const EMPH_ORDER = ['neutral', 'happy', 'surprised', 'angry', 'complaint', 'firm', 'urgent',
  'anxious', 'sad', 'soft', 'tired', 'lazy', 'aggrieved'];

function emphDataBox() {
  const data = (state && state.emph) || {};
  return { params: data.params || {}, cap: data.cap || 4.6, stretchOn: data.stretchOn !== false };
}


const EMO_ZH = {
  neutral: '中性', happy: '开心', sad: '难过', angry: '生气', surprised: '惊讶',
  anxious: '焦虑', complaint: '抱怨', aggrieved: '委屈', firm: '坚定',
  urgent: '催促', lazy: '慵懒', tired: '疲惫', soft: '温柔',
};

async function renderRefs() {
  const note = $('#ref-note');
  const host = $('#ref-table');
  if (!host) return;
  try {
    const d = await api('/api/refs');
    if (!d.ok) { note.textContent = d.error || '没有读表的权限'; host.innerHTML = ''; return; }
    const cls = Object.keys(d.classes[d.genderDefault] || {});
    const head = `<thead><tr><th>情绪</th><th>女 f0</th><th>女 语速</th><th>男 f0</th><th>男 语速</th><th>说话人</th></tr></thead>`;
    const rows = cls.map((k) => {
      const f = (d.classes.F || {})[k] || {};
      const m = (d.classes.M || {})[k] || {};
      const low = f.low_sample || m.low_sample ? '<small>样本少</small>' : '';
      return `<tr><td>${EMO_ZH[k] || k}<small>${k}</small></td>
        <td>${f.f0 ? f.f0.toFixed(1) + ' Hz' : '—'}</td>
        <td>${f.rate_chars ? f.rate_chars.toFixed(2) + ' 字/秒' : '—'}</td>
        <td>${m.f0 ? m.f0.toFixed(1) + ' Hz' : '—'}</td>
        <td>${m.rate_chars ? m.rate_chars.toFixed(2) + ' 字/秒' : '—'}</td>
        <td>${f.n_spk || '—'} / ${m.n_spk || '—'} ${low}</td></tr>`;
    }).join('');
    host.innerHTML = head + '<tbody>' + rows + '</tbody>';
    note.textContent = `${cls.length} 类 · ${d.note || ''}` || '';
  } catch (e) {
    note.textContent = `读表失败：${e.message}`;
  }
}

function renderEmphUnused() {
  const host = $('#emph-list');
  if (!host) return;
  const { params, cap, stretchOn } = emphDataBox();
  host.innerHTML = EMPH_ORDER.filter((k) => params[k]).map((k) => {
    const [g, st] = params[k];
    const [zh, en] = LABELS[k] || [k, k];
    const g2 = Math.max(0.4, g < 3 ? (g / 3.5) * g - 1.4 : g - 1.4);
    const g3 = Math.max(0.4, g < 3 ? (g / 3.5) * g - 2.6 : g - 2.6);
    const st2 = 1 + (st - 1) * 0.55;
    return `<div class="tuning-row">
      <div class="tuning-name">${zh}<small>${en}</small></div>
      <div class="tuning-cell">
        <input type="range" data-k="${k}" data-f="g" min="0" max="${cap}" step="0.1" value="${g}">
        <output data-out="${k}-g">${g.toFixed(1)} dB</output>
      </div>
      <div class="tuning-cell">
        <input type="range" data-k="${k}" data-f="s" min="1" max="2" step="0.01" value="${st}">
        <output data-out="${k}-s">${st.toFixed(2)} ×</output>
      </div>
      <div class="tuning-cell"><span class="lv">${g2.toFixed(1)} / ${g3.toFixed(1)} dB　${st2.toFixed(2)} ×</span></div>
    </div>`;
  }).join('');
  $$('#emph-list input[type="range"]').forEach((inp) => {
    inp.addEventListener('input', () => {
      const out = $(`output[data-out="${inp.dataset.k}-${inp.dataset.f}"]`);
      if (out) out.textContent = inp.dataset.f === 'g' ? `${Number(inp.value).toFixed(1)} dB` : `${Number(inp.value).toFixed(2)} ×`;
      inp.closest('.tuning-row').classList.add('changed');
      emphDirty = true;
    });
  });
  const note = $('#emph-note');
  if (note) {
    note.textContent = stretchOn
      ? `保存即生效。二三级按一级自动算（−1.4 / −2.6 dB，拉长 ×0.55）；上限 ${cap} dB。`
      : `保存即生效。拉伸当前关闭（只加音量），上限 ${cap} dB。`;
  }
  emphDirty = false;
}

function collectEmph() {
  const out = {};
  $$('#emph-list .tuning-row').forEach((row) => {
    const gi = $('input[data-f="g"]', row);
    const si = $('input[data-f="s"]', row);
    if (!gi || !si) return;
    out[gi.dataset.k] = [Number(gi.value), Number(si.value)];
  });
  return out;
}

async function saveEmph() {
  const r = await api('/api/emph', { method: 'POST', body: JSON.stringify({ params: collectEmph() }) });
  state.emph = r;
  toast('重点词参数已保存');
}

async function reloadEmph() {
  const r = await api('/api/status');
  state.emph = r.emph;
  toast('已重新读取');
}

function collectTuning() {
  const shapes = {};
  const f0 = {};
  $$('.tuning-row').forEach((row) => {
    const key = row.dataset.key;
    shapes[key] = {};
    $$('input', row).forEach((inp) => {
      if (inp.dataset.k === 'f0') f0[key] = Number(inp.value);
      else shapes[key][inp.dataset.k] = Number(inp.value);
    });
  });
  return { shapes, f0 };
}

async function saveTuning() {
  try {
    const t = await api('/api/tuning', { method: 'POST', body: JSON.stringify(collectTuning()) });
    state.tuning = t;
    tuningDirty = false;
    renderTuning();
    toast('情绪参数存好了');
  } catch (e) {
    toast(`没存成：${e.message}`);
  }
}

async function resetTuning() {
  if (!confirm('恢复全部情绪参数到默认值？')) return;
  try {
    state.tuning = await api('/api/tuning/reset', { method: 'POST' });
    tuningDirty = false;
    renderTuning();
    toast('已复位');
  } catch (e) {
    toast(`没复位：${e.message}`);
  }
}

async function loadStats() {
  try {
    const s = await api('/api/stats');
    state.disk = s.disk;
    state.tokens = s.tokens;
    renderOverview();
    renderDisk();
  } catch (e) {
    toast(`读不到统计：${e.message}`);
  }
}

async function loadStatus(rerenderTuning = true) {
  try {
    state = await api('/api/status');
    $('#version').textContent = state.version || '';
    renderCaps();
    renderTts();
    if (rerenderTuning) renderTuning();
  renderRefs();
    renderVoice();
    await loadStats();
  } catch (e) {
    toast(`读不到状态：${e.message}`);
  }
}

// 页面切换
$$('.nav-item').forEach((b) => b.addEventListener('click', () => setPage(b.dataset.page)));
$('#refresh').addEventListener('click', () => loadStatus(false));

// TTS
$('#tts-test').addEventListener('click', async () => {
  const url = $('#tts-url').value.trim();
  const pill = $('#tts-pill');
  pill.textContent = '测试中…';
  try {
    const h = await api('/api/tts/test', { method: 'POST', body: JSON.stringify({ url }) });
    state.tts = h;
    renderTts();
    toast(h.ok ? '通了' : `没通：${h.error || '连不上'}`);
  } catch (e) {
    toast(`没通：${e.message}`);
  }
});

$('#tts-save').addEventListener('click', async () => {
  try {
    const r = await api('/api/tts/save', {
      method: 'POST',
      body: JSON.stringify({ url: $('#tts-url').value.trim(), pricePerM: Number($('#price-input').value) }),
    });
    state.config = r.config;
    state.tts = r.tts;
    renderTts();
    toast('地址存好了');
  } catch (e) {
    toast(`没存成：${e.message}`);
  }
});

$('#sample-go').addEventListener('click', async () => {
  const text = $('#sample-text').value.trim();
  if (!text) return toast('先写一句');
  const btn = $('#sample-go');
  btn.disabled = true;
  $('#sample-state').textContent = '合成中…';
  try {
    const res = await fetch('/api/tts/sample', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text }),
    });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const audio = $('#sample-audio');
    audio.src = url;
    audio.hidden = false;
    await audio.play();
    $('#sample-state').textContent = '好了';
  } catch (e) {
    $('#sample-state').textContent = '';
    toast(`没合成：${e.message}`);
  } finally {
    btn.disabled = false;
  }
});

$('#tuning-save').addEventListener('click', saveTuning);
$('#tuning-reset').addEventListener('click', resetTuning);
  const vs=$('#voice-save'); if(vs) vs.addEventListener('click', () => saveVoice().catch((e) => toast(e.message)));
  const vd=$('#voice-default'); if(vd) vd.addEventListener('click', () => saveVoiceAsDefaults().catch((e) => toast(e.message)));
  const es=$('#emph-save'); if(es) es.addEventListener('click', () => saveEmph().catch((e) => toast(e.message)));
  const er=$('#emph-refresh'); if(er) er.addEventListener('click', () => reloadEmph().catch((e) => toast(e.message)));

window.addEventListener('beforeunload', (e) => {
  if (tuningDirty || emphDirty || voiceDirty) { e.preventDefault(); e.returnValue = ''; }
});

loadStatus(true);

// 方便截图/收藏某个页：/#tts、/#disk、/#tuning
const initial = location.hash.replace(/^#/, '');
if (TITLES[initial]) setPage(initial);
