﻿param([string]$Version = '0.3.17')
# 只补 听 / 全 两份；复用第一次已经铺好的 base 与 安装.exe，不动 说 的 staging/zip。
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$stage = Join-Path $root 'tmp\variant-build'
$dist = Join-Path $root 'dist'
$base = Join-Path $stage 'base\app'
$exe = Join-Path $stage '安装.exe'
$promo = Join-Path $root '..\..\docs\语音情绪-一页说明.png'
if (-not (Test-Path $base)) { throw "缺 base：$base" }
if (-not (Test-Path $exe)) { throw "缺 安装.exe：$exe" }
if (-not (Test-Path $promo)) { throw "缺宣传图：$promo" }
Add-Type -AssemblyName System.IO.Compression.FileSystem

$variants = @(
  @{ key = 'listen'; label = '听'; listen = 'on'; speak = 'off'; note = '这版只做「听」：不注册 voice_speak，不需要 TTS。' },
  @{ key = 'full';    label = '全'; listen = 'on'; speak = 'auto'; note = '这版「说 + 听」都有：有 TTS 就开说，没有也不影响听。' }
)

foreach ($v in $variants) {
  $top = Join-Path $stage ("语音情绪插件-$Version-$($v.label)")
  $app = Join-Path $top 'app'
  if (Test-Path $top) { Remove-Item $top -Recurse -Force }
  New-Item -ItemType Directory -Path $app -Force | Out-Null
  Copy-Item (Join-Path $base '*') $app -Recurse -Force

  $variantJson = @{ listen = $v.listen; speak = $v.speak; label = $v.label } | ConvertTo-Json -Compress
  [IO.File]::WriteAllText((Join-Path $app 'variant.json'), $variantJson + "`n", (New-Object Text.UTF8Encoding($false)))

  Copy-Item $exe (Join-Path $top '安装.exe') -Force
  Copy-Item $promo (Join-Path $top '宣传图.png') -Force

  $note = @"
dsh-voice-emotion $Version —— $($v.label)版
====================================================
1. 先解压，再双击「安装.exe」。只有一个安装文件，图标是那道白色声波。
2. $($v.note)
3. 这版没有删任何模型文件（按你的要求不做小），所以三份包体积一样。
4. 「说」要一个能 POST /speak 的 TTS 服务，默认 http://127.0.0.1:3120。
   换 RVC：插件配置里设 ttsEngine: rvc、ttsVoice: 角色名，按需加 indexRate/protect；
   或跑 node tools/set-tts.mjs --engine rvc --voice 角色名 --index-rate 0.75 --protect 0.33。
5. 装完重启 DSH（或热重载插件）。解压出来的 app 文件夹不要改名、不要拆开。
"@
  [IO.File]::WriteAllText((Join-Path $top '安装说明.txt'), $note, (New-Object Text.UTF8Encoding($true)))

  $zip = Join-Path $dist "dsh-voice-emotion-$Version-$($v.key).zip"
  if (Test-Path $zip) { Move-Item $zip (Join-Path $root ("tmp\dist-backup\dsh-voice-emotion-$Version-$($v.key).zip." + (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force }
  $sw = [Diagnostics.Stopwatch]::StartNew()
  [IO.Compression.ZipFile]::CreateFromDirectory($top, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
  $z = [IO.Compression.ZipFile]::OpenRead($zip)
  try { $n = $z.Entries.Count } finally { $z.Dispose() }
  $sw.Stop()
  Write-Output ("ok: {0}  ({1:N0} MB, {2} entries, {3:N1}s)" -f $zip, ((Get-Item $zip).Length / 1MB), $n, $sw.Elapsed.TotalSeconds)
}
Write-Output "done: $stage"

