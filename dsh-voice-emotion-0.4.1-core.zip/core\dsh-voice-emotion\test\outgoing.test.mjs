import test from 'node:test';
import assert from 'node:assert/strict';
import { inferOutgoing, parseTag } from '../lib/outgoing.mjs';

test('反讽标签只给平语气，不套 complaint 情绪', () => {
  const r = inferOutgoing('[反讽] 你可真会挑时候。');
  assert.equal(r.tag, '反讽');
  assert.equal(r.emotion, 'neutral');
  assert.equal(r.intensity, 0.5);
  assert.equal(r.speedScale, 0.95);
  assert.equal(r.text, '你可真会挑时候。');
});

test('大语境里写了反讽也认，但当前句不用猜', () => {
  const r = inferOutgoing('你可真会挑时候。', { context: '上一句在阴阳怪气' });
  assert.equal(r.emotion, 'neutral');
  assert.equal(r.speedScale, 0.95);
});

test('普通开心词仍走规则', () => {
  const r = inferOutgoing('太好了');
  assert.equal(r.emotion, 'happy');
});

test('parseTag 剥掉标签但保留正文', () => {
  assert.deepEqual(parseTag('【反讽】你可真会挑时候。'), { tag: '反讽', text: '你可真会挑时候。' });
});
