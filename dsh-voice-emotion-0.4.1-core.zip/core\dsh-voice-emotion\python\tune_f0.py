"""把一段语音的中位基频（f0）拉到目标值：rubberband 保共振峰移调，只往下修、向上最多 3 半音。

用法：python tune_f0.py <in.wav> <emotion> <out.wav>
依赖：librosa、ffmpeg（可用 FFMPEG_PATH 覆盖）

2026-11-10 提速：
- pyin（概率式、要跑两遍）换成 yin（单遍自相关），同精度下快 3~5 倍；
- 目标与当前差不到 1 个半音就直接拷贝，不再动 ffmpeg（多数情绪落在这档）；
- 子进程加 CREATE_NO_WINDOW，从无控制台的宿主拉起时不会弹黑框。
"""
import json
import os
import shutil
import subprocess
import sys

import librosa
import numpy as np

TARGETS = {
    "neutral": 222, "happy": 246, "surprised": 268, "angry": 228,
    "complaint": 228, "firm": 218, "urgent": 238, "anxious": 228,
    "sad": 196, "soft": 208, "tired": 200, "lazy": 204, "aggrieved": 208,
}

NO_WINDOW = 0x08000000 if os.name == "nt" else 0
SKIP_SEMIS = 1.0


def f0_median(path: str) -> float:
    y, sr = librosa.load(path, sr=16000, mono=True)
    if y.size == 0:
        return 0.0
    f0 = librosa.yin(y, fmin=70, fmax=500, sr=sr, frame_length=1024, hop_length=256)
    v = f0[np.isfinite(f0)]
    return float(np.median(v)) if v.size else 0.0


def main() -> None:
    if len(sys.argv) < 4:
        print(json.dumps({"ok": False, "error": "用法: tune_f0.py <in> <emotion> <out>"}))
        return
    src, emo, out = sys.argv[1], sys.argv[2].strip().lower(), sys.argv[3]
    target = TARGETS.get(emo)
    if not target:
        print(json.dumps({"ok": False, "error": f"未知情绪：{emo}"}))
        return
    try:
        cur = f0_median(src)
    except Exception as e:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": f"读不了音频：{e}"}))
        return
    if cur <= 0:
        print(json.dumps({"ok": False, "error": "没测到基频"}))
        return
    semis = 12 * np.log2(target / cur)
    # 只允许大幅下移：很多 TTS 会把生气/惊讶抬得很高，再往上加就尖锐
    semis = max(-7.0, min(3.0, float(semis)))
    if abs(semis) < SKIP_SEMIS:
        shutil.copyfile(src, out)
        print(json.dumps({"ok": True, "cur": round(cur, 1), "target": target,
                          "semis": round(semis, 2), "skipped": True}))
        return
    ratio = 2 ** (semis / 12)
    ffmpeg = os.environ.get("FFMPEG_PATH") or "ffmpeg"
    try:
        subprocess.run([
            ffmpeg, "-y", "-v", "error", "-i", src,
            "-af", f"aresample=44100,rubberband=pitch={ratio:.4f}:formant=preserved:transients=crisp:pitchq=quality,aresample=16000",
            "-ac", "1", "-c:a", "pcm_s16le", out,
        ], check=True, creationflags=NO_WINDOW)
    except Exception as e:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": f"ffmpeg 失败：{e}"}))
        return
    print(json.dumps({"ok": True, "cur": round(cur, 1), "target": target, "semis": round(semis, 2)}))


if __name__ == "__main__":
    main()
