"""常驻声学分析服务（2026-11-07）。

为什么需要它：analyze.py 每次冷启要 import librosa/numpy（1~2 秒），而语音消息、
TTS 标签采样都是高频小请求。这里把模型和依赖驻留在内存里，用 HTTP 暴露同一套结果。

用法：
    python serve.py [--port 3131] [--host 127.0.0.1]

接口：
    POST /analyze   {"file": "C:/path/to.wav", "frames": false}  -> analyze.py 的同一份 JSON
    GET  /health                                                -> {"ok": true, "pid": …}
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyze import analyze  # noqa: E402


def f0_median(path: str) -> float:
    """中位基频：yin（单遍自相关）比 pyin 快 3~5 倍，够用。"""
    import librosa
    import numpy as np
    y, sr = librosa.load(path, sr=16000, mono=True)
    if y.size == 0:
        return 0.0
    f0 = librosa.yin(y, fmin=70, fmax=500, sr=sr, frame_length=1024, hop_length=256)
    v = f0[np.isfinite(f0)]
    return float(np.median(v)) if v.size else 0.0


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # 静默：不要往 stdout 刷访问日志
        pass

    def _send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path.rstrip("/") == "/health":
            self._send(200, {"ok": True, "pid": os.getpid()})
        else:
            self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):  # noqa: N802
        if self.path.rstrip("/") not in ("/analyze", "/f0"):
            self._send(404, {"ok": False, "error": "not found"})
            return
        try:
            length = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            req = json.loads(raw.decode("utf-8") or "{}")
            path = _materialize(req)
            if not path or not os.path.exists(path):
                self._send(400, {"ok": False, "error": "file 不存在"})
                return
            if self.path.rstrip("/") == "/f0":
                self._send(200, {"ok": True, "f0": round(f0_median(path), 1)})
                return
            result = analyze(path, want_frames=bool(req.get("frames")))
            self._send(200, result)
        except Exception as exc:  # 单个请求失败不能拖垮服务
            self._send(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})


def _materialize(req):
    """A 机本机传路径就用路径；跨机器看不到 A 的路径时，从 audio_b64 落地成临时 wav。"""
    path = str(req.get("file") or "").strip()
    if path and os.path.exists(path):
        return path
    raw_b64 = req.get("audio_b64") or req.get("audio")
    if not raw_b64:
        return path
    import base64 as _b64
    import hashlib as _hashlib
    data = _b64.b64decode(raw_b64)
    tmp_dir = os.path.join(tempfile.gettempdir(), "dsh-emo-in")
    os.makedirs(tmp_dir, exist_ok=True)
    out = os.path.join(tmp_dir, _hashlib.sha1(data).hexdigest()[:16] + ".wav")
    if not os.path.exists(out):
        with open(out, "wb") as fh:
            fh.write(data)
    return out

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3131)
    args = parser.parse_args()

    # 预热一次，把 librosa 的懒加载提前做掉（首次调用少 300~800ms）
    try:
        import numpy as np  # noqa: F401
        import librosa  # noqa: F401
    except Exception:
        pass

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(json.dumps({"ok": True, "listening": f"http://{args.host}:{args.port}", "pid": os.getpid()}), flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
