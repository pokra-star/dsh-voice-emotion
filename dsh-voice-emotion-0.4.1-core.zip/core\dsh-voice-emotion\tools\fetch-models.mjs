#!/usr/bin/env node
/** 核包：装依赖之后补齐模型。用法：node tools/fetch-models.mjs [--force] [--check]
 *
 *  --check  只检查缺什么，不下载
 *  退出码：0 齐全 / 3 需要手动放 / 1 下载失败
 */
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ensureModels, explain } from '../lib/model-fetch.mjs';

const pkg = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const checkOnly = args.includes('--check');
const force = args.includes('--force');

const log = (m) => console.log(`[models] ${m}`);

if (checkOnly) {
  const r = await ensureModels(pkg, { log, force: false });
  console.log(explain({ missing: r.missing, manual: r.manual }, pkg));
  process.exit(r.ok ? 0 : 3);
}

const r = await ensureModels(pkg, { log, force });
console.log(explain(r, pkg));
if (r.ok) { log('模型齐全，可以用了'); process.exit(0); }
process.exit(r.manual.length ? 3 : 1);
