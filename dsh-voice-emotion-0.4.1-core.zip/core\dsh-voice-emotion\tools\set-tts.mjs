// 给 DSH profile 的 dsh-voice-emotion 写 TTS 配置（speak=on + ttsUrl）
// 用法：node tools/set-tts.mjs --url http://127.0.0.1:3120 [--profile <dir>] [--off]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const argv = process.argv.slice(2);
const getArg = (k, d = null) => {
  const i = argv.indexOf(k);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : d;
};
const off = argv.includes('--off');
const url = getArg('--url', 'http://127.0.0.1:3120');
const engine = getArg('--engine', '');
const voice = getArg('--voice', '');
const indexRate = getArg('--index-rate', '');
const protect = getArg('--protect', '');
let profile = getArg('--profile');

if (!profile) {
  const root = path.join(os.homedir(), '.dsh', 'profiles');
  if (!fs.existsSync(root)) {
    console.error('[set-tts] 没找到 profile 目录：' + root);
    process.exit(2);
  }
  const cands = fs.readdirSync(root, { withFileTypes: true })
    .filter((d) => d.isDirectory() && fs.existsSync(path.join(root, d.name, 'package.json')))
    .map((d) => path.join(root, d.name));
  if (cands.length === 1) profile = cands[0];
  else if (cands.find((p) => path.basename(p) === 'web')) profile = cands.find((p) => path.basename(p) === 'web');
  else { console.error('[set-tts] 有多个 profile，请用 --profile 指定：' + cands.join(', ')); process.exit(2); }
}

const yml = path.join(profile, 'cordis.patch.yml');
if (!fs.existsSync(yml)) {
  console.error('[set-tts] 没找到 ' + yml);
  process.exit(2);
}
let text = fs.readFileSync(yml, 'utf8');
const backup = yml + '.bak-settts-' + Date.now();
fs.writeFileSync(backup, text);

const lines = text.split(/\r?\n/);
const idx = lines.findIndex((l) => /^\s*-\s*id:\s*dsh-voice-emotion\s*$/.test(l));
const speakVal = off ? 'auto' : 'on';

if (idx < 0) {
  if (off) {
    console.log('[set-tts] 配置里没有该插件块，无需关闭');
    fs.unlinkSync(backup);
    process.exit(0);
  }
  lines.push('');
  lines.push('- id: dsh-voice-emotion');
  lines.push('  name: dsh-voice-emotion');
  lines.push('  config:');
  lines.push('    ttsUrl: ' + JSON.stringify(url));
  lines.push('    speak: ' + JSON.stringify(speakVal));
  if (engine) lines.push('    ttsEngine: ' + JSON.stringify(engine));
  if (voice) lines.push('    ttsVoice: ' + JSON.stringify(voice));
  if (indexRate) lines.push('    indexRate: ' + JSON.stringify(String(indexRate)));
  if (protect) lines.push('    protect: ' + JSON.stringify(String(protect)));
} else {
  // 找 config: 行与块结束
  let cfgIdx = -1;
  for (let i = idx + 1; i < lines.length; i++) {
    if (/^\s*-\s*id:/.test(lines[i])) break;
    if (/^\s*config:\s*$/.test(lines[i])) { cfgIdx = i; break; }
  }
  if (cfgIdx < 0) {
    let insertAt = idx + 1;
    for (let i = idx + 1; i < lines.length; i++) {
      if (/^\s*-\s*id:/.test(lines[i])) break;
      insertAt = i + 1;
    }
    lines.splice(insertAt, 0, '  config:', '    ttsUrl: ' + JSON.stringify(url), '    speak: ' + JSON.stringify(speakVal));
  } else {
    let end = cfgIdx + 1;
    for (let i = cfgIdx + 1; i < lines.length; i++) {
      if (/^\s*-\s*id:/.test(lines[i]) || /^\S/.test(lines[i])) break;
      end = i + 1;
    }
    const body = lines.slice(cfgIdx + 1, end);
    const keep = {};
    for (const l of body) {
      const m = l.match(/^\s*(ttsEngine|ttsVoice|indexRate|protect)\s*:\s*(.+?)\s*$/);
      if (m) keep[m[1]] = m[2];
    }
    let filtered = body.filter((l) => !/^\s*(ttsUrl|speak|ttsEngine|ttsVoice|indexRate|protect)\s*:/.test(l));
    while (filtered.length && filtered[filtered.length - 1].trim() === '') filtered.pop();
    filtered.push('    ttsUrl: ' + JSON.stringify(url));
    filtered.push('    speak: ' + JSON.stringify(speakVal));
    const extra = [
      ['ttsEngine', engine],
      ['ttsVoice', voice],
      ['indexRate', indexRate ? String(indexRate) : ''],
      ['protect', protect ? String(protect) : ''],
    ];
    for (const [key, val] of extra) {
      const raw = val ? JSON.stringify(val) : keep[key];
      if (raw) filtered.push('    ' + key + ': ' + raw);
    }
    lines.splice(cfgIdx + 1, end - (cfgIdx + 1), ...filtered);
  }
}

fs.writeFileSync(yml, lines.join('\n'));
console.log('[set-tts] 写入 ' + yml);
console.log('[set-tts] speak=' + speakVal + '  ttsUrl=' + (off ? '(保留)' : url));
console.log('[set-tts] 备份 ' + path.basename(backup));
