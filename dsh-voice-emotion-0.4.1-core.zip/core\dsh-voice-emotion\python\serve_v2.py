"""emotion2vec + 线性头的常驻推理服务（端口 3132）。

POST /predict  {"file": "C:/...wav"}
  -> {"ok": true, "emotion": "angry", "confidence": 0.53,
      "top": [["angry", 0.53], ["sad", 0.21], ["neutral", 0.12]],
      "trained": {...模型元信息...}}

GET /health -> {"ok": true, "pid": ..., "labels": [...]}

模型参数来自 model-v2.json（由 tools/train_m3ed.py --export 生成），
推理 = 标准化 → 线性 logits → softmax。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

_TMP_IN = Path(tempfile.gettempdir()) / "dsh-emo-in"


def _materialize(payload):
    """A 机本机传路径就直接用；跨机器（B 机）看不到 A 的路径时，改从 audio_b64 落地成临时 wav。"""
    file_path = str(payload.get("file") or "").strip()
    if file_path and Path(file_path).exists():
        return file_path
    raw_b64 = payload.get("audio_b64") or payload.get("audio")
    if not raw_b64:
        return file_path
    import base64 as _b64
    import hashlib as _hashlib
    data = _b64.b64decode(raw_b64)
    _TMP_IN.mkdir(parents=True, exist_ok=True)
    out = _TMP_IN / (_hashlib.sha1(data).hexdigest()[:16] + ".wav")
    if not out.exists():
        out.write_bytes(data)
    return str(out)
HERE = Path(__file__).resolve().parent
PKG = HERE.parent
HOME_DIR = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
WEIGHTS = Path(os.environ.get("VOICE_EMO_WEIGHTS", str(PKG / "model-v2.json")))
MODEL_FT = Path(os.environ.get("VOICE_EMO_FT_ONNX", str(PKG / "model-ft.onnx")))
HEAD_NPZ = Path(os.environ.get("VOICE_EMO_HEAD_NPZ", str(PKG / "model-v2-ft.npz")))
NEG_JSON = Path(os.environ.get("VOICE_EMO_NEG_MODEL", str(PKG / "model-neg.json")))
FT_LABELS = ["negative", "neutral", "positive", "surprise"]


def find_model_dir() -> str:
    """找 emotion2vec 权重目录：环境变量 → 插件 home 下的 modelscope 缓存 → 开发机老路径。

    modelscope 的路径是 models/<org>--<name>/snapshots/<rev>，这里扫一遍，取第一个带 config 的。"""
    env = os.environ.get("VOICE_EMO2VEC_DIR")
    if env and Path(env).is_dir():
        return env
    roots = [HOME_DIR / "models", Path.home() / ".dsh-voice-emo2vec" / "models"]
    for root in roots:
        if not root.is_dir():
            continue
        for cfg in root.glob("**/iic--emotion2vec_plus_large/snapshots/*/configuration.json"):
            return str(cfg.parent)
        for cfg in root.glob("**/emotion2vec_plus_large/**/configuration.json"):
            return str(cfg.parent)
    return str(HOME_DIR / "models" / "models" / "iic--emotion2vec_plus_large" / "snapshots" / "master")


MODEL_DIR = find_model_dir()

_lock = threading.Lock()
_model = None
_params = None


def load_params(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    data["mean"] = np.asarray(data["mean"], dtype=np.float32)
    data["scale"] = np.asarray(data["scale"], dtype=np.float32)
    data["coef"] = np.asarray(data["coef"], dtype=np.float32)
    data["intercept"] = np.asarray(data["intercept"], dtype=np.float32)
    return data


def load_embedder():
    from funasr import AutoModel

    return AutoModel(
        model="iic/emotion2vec_plus_large",
        model_path=MODEL_DIR,
        device="cpu",
        disable_update=True,
        disable_pbar=True,
        log_level="ERROR",
    )


def load_onnx_session():
    """2026-11-09：优先用导出好的 ONNX（621MB，不需要 torch，速度快 1.7 倍）。

    图里已经含「逐条标准化 + 均值池化」，所以进来只要 16k 单声道 float32。
    """
    path = PKG / "model-embed.onnx"
    if not path.exists():
        return None
    try:
        import onnxruntime as ort

        sess = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
        print(f"[serve_v2] onnx {path.name} 已加载", flush=True)
        return sess
    except Exception as error:  # noqa: BLE001
        print(f"[serve_v2] onnx 加载失败，回退 torch：{error}", flush=True)
        return None


def _read_16k(wav: str) -> np.ndarray:
    import soundfile as sf

    data, sr = sf.read(wav, dtype="float32", always_2d=False)
    if data.ndim > 1:
        data = data.mean(axis=1)
    if sr != 16000:
        import librosa

        data = librosa.resample(data, orig_sr=sr, target_sr=16000)
    return np.asarray(data, dtype=np.float32)


def embed(model, wav: str) -> np.ndarray:
    if isinstance(model, dict) and model.get("kind") == "onnx":
        data = _read_16k(wav)
        out = model["session"].run(None, {"wav": data[None, :]})[0]
        return np.asarray(out, dtype=np.float32).reshape(-1)
    out = model.generate(wav, granularity="utterance", extract_embedding=True, disable_pbar=True)
    if isinstance(out, list):
        out = out[0]
    emb = out.get("feats") if isinstance(out, dict) else None
    if emb is None and isinstance(out, dict):
        emb = out.get("embedding")
    if emb is None:
        raise RuntimeError(f"no embedding: {list(out)[:6] if isinstance(out, dict) else type(out)}")
    return np.asarray(emb, dtype=np.float32).reshape(-1)


def load_neg(path: Path):
    """二分类（负面 vs 非负面）头：{'mean','scale','coef'(1,N),'intercept'(1,),'metrics'}"""
    if not path.exists():
        return None
    try:
        j = json.loads(path.read_text(encoding='utf-8'))
        return {
            'mean': np.asarray(j['mean'], dtype=np.float64),
            'scale': np.asarray(j['scale'], dtype=np.float64),
            'coef': np.asarray(j['coef'], dtype=np.float64),
            'intercept': np.asarray(j['intercept'], dtype=np.float64),
            'metrics': j.get('metrics') or {},
        }
    except Exception as e:  # noqa: BLE001
        print(f"[serve_v2] 负面头加载失败：{e}", flush=True)
        return None


def load_ft_head():
    """微调头的 numpy 版本（Linear 1024→256 → GELU → Linear 256→4）。

    微调时头是吃「原始均值池化向量」的，所以这里不做 z-score。"""
    if not HEAD_NPZ.exists():
        return None
    try:
        z = np.load(HEAD_NPZ)
        head = {
            "w1": z["w1"].astype(np.float32),
            "b1": z["b1"].astype(np.float32),
            "w2": z["w2"].astype(np.float32),
            "b2": z["b2"].astype(np.float32),
            "labels": [str(x) for x in z["labels"]] if "labels" in z else FT_LABELS,
            "mean": z["mean"].astype(np.float32) if "mean" in z else None,
            "scale": z["scale"].astype(np.float32) if "scale" in z else None,
            "scaled": bool(int(z["input_scaled"][0])) if "input_scaled" in z else False,
            "arch": str(z["arch"][0]) if "arch" in z else "mlp",
        }
        return head
    except Exception as error:  # noqa: BLE001
        print(f"[serve_v2] 微调头读取失败：{error}", flush=True)
        return None


def load_ft_session():
    """微调后的整图：wav -> logits（4 类）。头已经焊在 ONNX 里。"""
    if not MODEL_FT.exists():
        return None
    try:
        import onnxruntime as ort

        sess = ort.InferenceSession(str(MODEL_FT), providers=["CPUExecutionProvider"])
        print(f"[serve_v2] 微调 onnx {MODEL_FT.name} 已加载", flush=True)
        return sess
    except Exception as error:  # noqa: BLE001
        print(f"[serve_v2] 微调 onnx 加载失败：{error}", flush=True)
        return None


def gelu(x: np.ndarray) -> np.ndarray:
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * x**3)))


def load_backend():
    ft = load_ft_session()
    if ft is not None:
        return {"kind": "onnx-ft", "session": ft}
    session = load_onnx_session()
    if session is not None:
        head = load_ft_head()
        return {"kind": "onnx", "session": session, "head": head}
    return load_embedder()


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


_neg = load_neg(NEG_JSON)


def predict(wav: str) -> dict:
    global _model, _params
    if _neg is not None:
        if _model is None:
            _model = load_backend()
        vec = np.asarray(embed(_model, wav), dtype=np.float64).reshape(-1)
        z = (vec - _neg['mean']) / _neg['scale']
        logit = float(np.dot(_neg['coef'].reshape(-1), z) + float(_neg['intercept'].reshape(-1)[0]))
        p = float(1.0 / (1.0 + np.exp(-logit)))
        return {
            'ok': True,
            'kind': 'neg',
            'pNeg': round(p, 4),
            'label': 'negative' if p >= 0.5 else 'other',
            'metrics': _neg['metrics'],
        }
    if not Path(wav).exists():
        raise FileNotFoundError(wav)
    if _model is None:
        _model = load_backend()
    if _params is None:
        _params = load_params(WEIGHTS)
    if isinstance(_model, dict) and _model.get("kind") == "onnx-ft":
        data = _read_16k(wav)
        logits = np.asarray(_model["session"].run(None, {"wav": data[None, :]})[0], dtype=np.float32).reshape(-1)
        probs = softmax(logits)
        order = np.argsort(-probs)
        labels = FT_LABELS
        return {
            "emotion": labels[int(order[0])],
            "confidence": round(float(probs[int(order[0])]), 4),
            "top": [[labels[i], round(float(probs[i]), 4)] for i in order[:3]],
            "trained": {"source": "finetuned", "labels": labels},
        }
    vec = embed(_model, wav)
    head = _model.get("head") if isinstance(_model, dict) else None
    if head is not None:
        if head.get("scaled") and head.get("mean") is not None:
            vec = (vec - head["mean"]) / head["scale"]
        if head.get("arch") == "linear":
            logits = head["w1"] @ vec + head["b1"]
        else:
            h = gelu(head["w1"] @ vec + head["b1"])
            logits = head["w2"] @ h + head["b2"]
        probs = softmax(logits)
        order = np.argsort(-probs)
        labels = head["labels"]
        return {
            "emotion": labels[int(order[0])],
            "confidence": round(float(probs[int(order[0])]), 4),
            "top": [[labels[i], round(float(probs[i]), 4)] for i in order[:3]],
            "trained": {"source": "finetuned-head", "labels": labels},
        }
    p = _params
    z = (vec - p["mean"]) / p["scale"]
    logits = p["coef"] @ z + p["intercept"]
    probs = softmax(logits)
    order = np.argsort(-probs)
    labels = p["labels"]
    top = [[labels[i], round(float(probs[i]), 4)] for i in order[:3]]
    return {
        "emotion": labels[int(order[0])],
        "confidence": round(float(probs[int(order[0])]), 4),
        "top": top,
        "trained": {
            "cvAccuracy": p.get("cvAccuracy"),
            "cvMacroF1": p.get("cvMacroF1"),
            "majorityBaseline": p.get("majorityBaseline"),
            "trainedOn": p.get("trainedOn"),
            "labels": labels,
        },
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):  # noqa: A003
        sys.stderr.write("[serve_v2] " + fmt % args + "\n")

    def _json(self, code: int, obj: dict):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path.startswith("/health"):
            labels = _params["labels"] if _params else None
            if _neg is not None:
                labels = ["negative", "other"]
            backend = _model.get("kind") if isinstance(_model, dict) else ("torch" if _model else None)
            self._json(200, {"ok": True, "pid": os.getpid(), "labels": labels, "backend": backend})
        else:
            self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):  # noqa: N802
        if not self.path.startswith("/predict"):
            self._json(404, {"ok": False, "error": "not found"})
            return
        try:
            n = int(self.headers.get("content-length") or 0)
            payload = json.loads(self.rfile.read(n) or b"{}")
            wav = _materialize(payload)
            if not wav:
                self._json(400, {"ok": False, "error": "missing file"})
                return
            with _lock:
                res = predict(wav)
            self._json(200, {"ok": True, **res})
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=3132)
    ap.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()
    global _params
    if WEIGHTS.exists():
        _params = load_params(WEIGHTS)
        print(f"[serve_v2] weights {WEIGHTS} labels={_params['labels']}", flush=True)
    else:
        print(f"[serve_v2] weights missing: {WEIGHTS}（先跑 train --export）", flush=True)
    global _model
    try:
        _model = load_backend()
        print("[serve_v2] emotion2vec loaded", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[serve_v2] embedder load failed: {e}", flush=True)
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"[serve_v2] listening http://{args.host}:{args.port}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()

