#!/usr/bin/env node
// 用法：
//   node tools/voice-profile.mjs                 # 探 TTS，没有 profile 就校准一次
//   node tools/voice-profile.mjs --force         # 强制重标
//   node tools/voice-profile.mjs --tts http://127.0.0.1:3120
//   node tools/voice-profile.mjs --probe         # 只探，不动
//
// 校准内容：让 TTS 说三句 → 量 F0/F1/F2/F3 → 换成六腔比例锚点 → 推回 TTS。
// 没有 TTS 时不报错退出，只提示「没检测到合成服务，跳过」——插件本身不合成。

import { calibrate, probe, saveResult } from '../lib/voice-profile.mjs'

function arg(name, def = '') {
  const i = process.argv.indexOf(`--${name}`)
  if (i === -1) return def
  const v = process.argv[i + 1]
  return v && !v.startsWith('--') ? v : 'true'
}

const ttsUrl = arg('tts', process.env.VOICE_TTS_URL || 'http://127.0.0.1:3120')
const force = arg('force') === 'true'
const onlyProbe = arg('probe') === 'true'

const log = (m) => console.log(`[profile] ${m}`)

const info = await probe(ttsUrl)
if (!info.ok) {
  console.log(`[profile] 没检测到合成服务（${ttsUrl}），跳过校准。插件本身不带合成，这不影响听的那一半。`)
  process.exit(0)
}
log(`TTS 在线：${ttsUrl}（参考音 ${info.info.refer || '未知'}）`)
if (onlyProbe) {
  console.log(JSON.stringify(info.info, null, 2))
  process.exit(0)
}

const result = await calibrate({ ttsUrl, force, log })
const file = await saveResult(result)
if (result.ok) {
  log(`已推给 TTS：${JSON.stringify(result.pushed || {})}`)
  log(`结果另存 ${file}`)
} else {
  log(`没校准成功：${result.reason} ${result.error || ''}`)
  process.exitCode = 1
}
