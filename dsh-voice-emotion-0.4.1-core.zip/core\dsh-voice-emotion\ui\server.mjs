// 语音情绪 · 本地控制台
// 只监听 127.0.0.1:3135，给 DSH 的 /voice-ui 指令和桌面快捷方式用。
// 不依赖任何前端构建：三个静态文件 + 几个 JSON 接口。
import { createServer } from 'node:http';
import { readFileSync, existsSync, statSync, readdirSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { readdir, stat, readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, resolve, dirname, basename, extname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { homedir, tmpdir } from 'node:os';
import { execFile } from 'node:child_process';
import { zstdDecompressSync } from 'node:zlib';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const STATE = join(ROOT, 'state');
const HOME = join(homedir(), '.dsh-voice-emotion');
const PORT = Number(process.env.VOICE_UI_PORT) || 3135;
const WORKSPACE = resolve(ROOT, '..', '..');
const TTS_AUDIO = join(WORKSPACE, 'qq-bridge-main', 'audio');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };

function json(res, code, value) {
  const body = JSON.stringify(value);
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(body);
}

function safeRead(p, fallback) {
  try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return fallback; }
}

function ensureState() {
  try { mkdirSync(STATE, { recursive: true }); } catch { /* ignore */ }
}

const DEFAULT_CONFIG = { ttsUrl: 'http://127.0.0.1:3120', pricePerM: 2 };

function getConfig() {
  return { ...DEFAULT_CONFIG, ...safeRead(join(STATE, 'ui-config.json'), {}) };
}

async function dirSize(p) {
  let total = 0;
  try {
    const entries = await readdir(p, { withFileTypes: true });
    for (const ent of entries) {
      const full = join(p, ent.name);
      try {
        if (ent.isDirectory()) total += await dirSize(full);
        else if (ent.isFile()) total += (await stat(full)).size;
      } catch { /* ignore */ }
    }
  } catch { /* missing */ }
  return total;
}

function fileSize(p) {
  try { return statSync(p).size; } catch { return 0; }
}

function readVariant() {
  const v = safeRead(join(ROOT, 'variant.json'), {});
  return {
    speak: String(v.speak || 'auto').toLowerCase(),
    listen: String(v.listen || 'on').toLowerCase(),
    label: v.label || '',
  };
}

function capabilities() {
  const v = readVariant();
  return { speak: v.speak !== 'off', listen: v.listen !== 'off', variant: v };
}

async function ttsHealth(url) {
  const base = String(url || '').replace(/\/+$/, '');
  if (!base) return { ok: false, error: '没有填地址' };
  try {
    const r = await fetch(`${base}/health`, { signal: AbortSignal.timeout(3000) });
    const j = await r.json().catch(() => ({}));
    return { ok: r.ok && j?.ok !== false, ...j, url: base };
  } catch (e) {
    return { ok: false, error: String(e?.message || e), url: base };
  }
}

// —— 今日插件额外 token 估算 ——
// 会话日志里没有 usage；只能按每次 request/header 携带的插件工具定义体积估算。
// 明确标成「估算」，UI 上不写成实际账单。
let tokenCache = { at: 0, value: null };

function estimateToolTokens(tools) {
  let chars = 0;
  let count = 0;
  for (const t of tools || []) {
    const n = String(t?.name || '');
    if (!n.startsWith('voice_emotion_') && n !== 'voice_speak') continue;
    chars += JSON.stringify(t).length;
    count += 1;
  }
  return { tokens: Math.ceil(chars / 4), count };
}

async function scanTodayTokens() {
  if (tokenCache.value && Date.now() - tokenCache.at < 5 * 60 * 1000) return tokenCache.value;
  const sessionsRoot = join(process.env.DSH_HOME || join(homedir(), '.dsh'), 'sessions');
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const files = [];
  async function walk(dir, depth = 0) {
    if (depth > 3) return;
    let entries = [];
    try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const ent of entries) {
      const full = join(dir, ent.name);
      if (ent.isDirectory()) await walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.zstd')) {
        try { const st = await stat(full); if (st.mtimeMs >= start.getTime() && st.size < 90 * 1024 * 1024) files.push(full); } catch { /* ignore */ }
      }
    }
  }
  await walk(sessionsRoot);
  files.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs);
  let requests = 0, toolCount = 0, extraTokens = 0, scanned = 0;
  for (const f of files.slice(0, 160)) {
    let text = '';
    try { text = zstdDecompressSync(readFileSync(f)).toString('utf8'); } catch { continue; }
    scanned += 1;
    for (const line of text.split('\n')) {
      if (!line || !line.includes('"request/header"')) continue;
      let ev; try { ev = JSON.parse(line); } catch { continue; }
      if (ev?.type !== 'request/header') continue;
      const tools = ev?.data?.header?.tools;
      if (!Array.isArray(tools)) continue;
      const t = estimateToolTokens(tools);
      if (t.count === 0) continue;
      requests += 1;
      toolCount = Math.max(toolCount, t.count);
      extraTokens += t.tokens;
    }
  }
  const cfg = getConfig();
  const price = Number(cfg.pricePerM) || 0;
  const value = {
    ok: true,
    requests, toolCount, extraTokens,
    cost: Math.round((extraTokens / 1e6) * price * 100) / 100,
    pricePerM: price,
    scannedFiles: scanned,
    note: '按每次请求携带的插件工具定义估算，不含工具返回内容',
    at: Date.now(),
  };
  tokenCache = { at: Date.now(), value };
  return value;
}

// —— 磁盘占用 ——
// 第一次扫要几十秒（QQ 语音缓存可能有几万个 wav）。结果落盘，下次开机先拿旧的，
// 后台再刷新；面板不为了一次统计卡住。
const DISK_CACHE = join(STATE, 'disk-cache.json');
let diskCache = { at: 0, value: null };
try {
  const c = JSON.parse(readFileSync(DISK_CACHE, 'utf8'));
  if (c?.value?.items) diskCache = { at: Number(c.at) || 0, value: c.value };
} catch { /* 没缓存 */ }
let diskScanning = false;

async function diskUsage() {
  if (diskCache.value) return diskCache.value;
  return diskUsageUncached();
}

async function refreshDisk() {
  if (diskScanning) return;
  diskScanning = true;
  try {
    const value = await diskUsageUncached();
    diskCache = { at: Date.now(), value };
    ensureState();
    await writeFile(DISK_CACHE, JSON.stringify(diskCache), 'utf8');
  } catch { /* ignore */ } finally { diskScanning = false; }
}

void refreshDisk();

async function diskUsageUncached() {
  const modelFiles = ['model-embed.onnx', 'model-v2.json', 'model-neg.json'].map((n) => fileSize(join(ROOT, n)));
  const whisper = await dirSize(join(ROOT, 'models', 'faster-whisper-small'));
  const models = modelFiles.reduce((a, b) => a + b, 0) + whisper;
  // 不算 dist（打包产物）和 tmp，装到用户机器上本来就不会有；
  // 根目录递归扫 12GB 的 zip 会让面板等半分钟。
  let code = 0;
  for (const d of ['lib', 'python', 'tools', 'ui', 'assets']) code += await dirSize(join(ROOT, d));
  for (const f of ['index.js', 'package.json', 'README.md', '安装说明.txt', 'variant.json']) code += fileSize(join(ROOT, f));
  const pluginTmp = await dirSize(join(ROOT, 'tmp'));
  const homeData = await dirSize(HOME);
  const ttsAudio = await dirSize(TTS_AUDIO);
  const items = [
    { id: 'code', label: '插件代码', bytes: code, hint: 'lib / python / tools / ui' },
    { id: 'models', label: '模型', bytes: models, hint: '声学 ONNX + whisper-small' },
    { id: 'home', label: '运行时数据', bytes: homeData, hint: HOME },
    { id: 'tts', label: 'TTS 音频缓存', bytes: ttsAudio, hint: TTS_AUDIO },
    { id: 'tmp', label: '临时文件', bytes: pluginTmp + await tempSize(), hint: '可清理' },
  ];
  const total = items.reduce((a, b) => a + b.bytes, 0);
  return { items, total, free: await freeSpace(ROOT) };
}

async function tempSize() {
  let total = 0;
  try {
    for (const n of await readdir(tmpdir())) {
      if (!n.startsWith('voice-emotion-')) continue;
      const p = join(tmpdir(), n);
      try { total += (await stat(p)).isDirectory() ? await dirSize(p) : (await stat(p)).size; } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
  return total;
}

async function freeSpace(p) {
  try {
    const { statfs } = await import('node:fs/promises');
    const s = await statfs(p);
    return Number(s.bavail) * Number(s.bsize);
  } catch { return 0; }
}

function rmSafe(p) {
  try { rmSync(p, { recursive: true, force: true }); return true; } catch { return false; }
}

async function clean(id) {
  const before = await diskUsage();
  if (id === 'tmp') {
    rmSafe(join(ROOT, 'tmp'));
    try {
      for (const n of await readdir(tmpdir())) {
        if (!n.startsWith('voice-emotion-')) continue;
        const p = join(tmpdir(), n);
        let st; try { st = await stat(p); } catch { continue; }
        if (Date.now() - st.mtimeMs > 60 * 60 * 1000) rmSafe(p);
      }
    } catch { /* ignore */ }
  } else if (id === 'home') {
    rmSafe(join(HOME, 'cache'));
    rmSafe(join(HOME, 'tmp'));
  } else if (id === 'tts') {
    try {
      for (const n of await readdir(TTS_AUDIO)) {
        if (!/^reply_.*\.wav$/i.test(n)) continue;
        const p = join(TTS_AUDIO, n);
        const st = await stat(p).catch(() => null);
        if (st && Date.now() - st.mtimeMs > 24 * 60 * 60 * 1000) rmSafe(p);
      }
    } catch { /* ignore */ }
  } else {
    return { ok: false, error: '这个不能清' };
  }
  diskCache = { at: 0, value: null };
  await refreshDisk();
  const after = diskCache.value || await diskUsage();
  return { ok: true, freed: Math.max(0, before.total - after.total), disk: after };
}

// —— 情绪参数 ——
let shapeMod = null;
async function getShapeModule() {
  if (!shapeMod) shapeMod = await import(pathToFileURL(join(ROOT, 'lib', 'shape.mjs')).href);
  return shapeMod;
}

const VOICE_POLICY_DIR = join(WORKSPACE, 'vendor', 'dsh-voice-emotion', 'state');
const VOICE_POLICY_FILE = join(VOICE_POLICY_DIR, 'voice-policy.json');
const VOICE_POLICY_DEFAULTS_FILE = join(VOICE_POLICY_DIR, 'voice-policy.defaults.json');
const VOICE_POLICY_DEFAULTS = { dailyLimit: 0, minIntervalSec: 0, strongProb: 90, normalProb: 40, strongIntensity: 0.7 };

function voicePolicy() {
  let raw = safeRead(VOICE_POLICY_FILE, {});
  if (!raw || !Object.keys(raw).length) raw = safeRead(VOICE_POLICY_DEFAULTS_FILE, {});
  const num = (v, lo, hi, dft) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : dft;
  };
  return {
    dailyLimit: Math.round(num(raw.dailyLimit, 0, 100000, VOICE_POLICY_DEFAULTS.dailyLimit)),
    minIntervalSec: Math.round(num(raw.minIntervalSec, 0, 86400, VOICE_POLICY_DEFAULTS.minIntervalSec)),
    strongProb: num(raw.strongProb, 0, 100, VOICE_POLICY_DEFAULTS.strongProb),
    normalProb: num(raw.normalProb, 0, 100, VOICE_POLICY_DEFAULTS.normalProb),
    strongIntensity: num(raw.strongIntensity, 0, 1, VOICE_POLICY_DEFAULTS.strongIntensity),
  };
}

async function saveVoiceDefaults(body) {
  const cur = voicePolicy();
  const n = (v, lo, hi, dft) => {
    const x = Number(v);
    return Number.isFinite(x) ? Math.max(lo, Math.min(hi, x)) : dft;
  };
  const next = {
    dailyLimit: Math.round(n(body.dailyLimit, 0, 100000, cur.dailyLimit)),
    minIntervalSec: Math.round(n(body.minIntervalSec, 0, 86400, cur.minIntervalSec)),
    strongProb: n(body.strongProb, 0, 100, cur.strongProb),
    normalProb: n(body.normalProb, 0, 100, cur.normalProb),
    strongIntensity: n(body.strongIntensity, 0, 1, cur.strongIntensity),
  };
  await writeFile(VOICE_POLICY_DEFAULTS_FILE, JSON.stringify(next, null, 2), 'utf8');
  await writeFile(VOICE_POLICY_FILE, JSON.stringify(next, null, 2), 'utf8');
  return next;
}

async function saveVoicePolicy(body) {
  const cur = voicePolicy();
  const n = (v, lo, hi, dft) => {
    const x = Number(v);
    return Number.isFinite(x) ? Math.max(lo, Math.min(hi, x)) : dft;
  };
  const next = {
    dailyLimit: Math.round(n(body.dailyLimit, 0, 100000, cur.dailyLimit)),
    minIntervalSec: Math.round(n(body.minIntervalSec, 0, 86400, cur.minIntervalSec)),
    strongProb: n(body.strongProb, 0, 100, cur.strongProb),
    normalProb: n(body.normalProb, 0, 100, cur.normalProb),
    strongIntensity: n(body.strongIntensity, 0, 1, cur.strongIntensity),
  };
  await writeFile(VOICE_POLICY_FILE, JSON.stringify(next, null, 2), 'utf8');
  return next;
}

async function emphData() {
  const cfg = getConfig();
  const base = String(cfg.ttsUrl || '').replace(/\/+$/, '');
  if (!base) return { ok: false, error: '未配置 TTS 地址' };
  try {
    const r = await fetch(`${base}/emph`);
    const j = await r.json();
    return j?.ok ? j : { ok: false, error: j?.error || `HTTP ${r.status}` };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function saveEmph(params) {
  const cfg = getConfig();
  const base = String(cfg.ttsUrl || '').replace(/\/+$/, '');
  const r = await fetch(`${base}/emph`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ params }),
  });
  const j = await r.json();
  if (!j?.ok) throw new Error(j?.error || `TTS ${r.status}`);
  return j;
}

async function tuningData() {
  const mod = await getShapeModule();
  const overrides = safeRead(join(STATE, 'tuning.json'), {});
  const shapes = {};
  for (const [name, base] of Object.entries(mod.SHAPES)) shapes[name] = { ...base, ...(overrides[name] || {}) };
  return {
    ok: true,
    baseSpeed: mod.BASE_SPEED,
    shapes,
    f0: { ...mod.F0_TARGETS, ...(overrides.f0 || {}) },
    overridden: Object.keys(overrides).filter((k) => k !== 'f0').length + (overrides.f0 ? 1 : 0),
  };
}

function clampNum(n, lo, hi, fallback) {
  const v = Number(n);
  return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : fallback;
}

async function saveTuning(body) {
  const mod = await getShapeModule();
  const out = {};
  for (const [name, base] of Object.entries(mod.SHAPES)) {
    const src = body?.shapes?.[name] || {};
    out[name] = {
      speed: clampNum(src.speed, 0.8, 1.2, base.speed),
      gain: clampNum(src.gain, -4, 4, base.gain),
      lead: Math.round(clampNum(src.lead, 0, 260, base.lead)),
      bright: clampNum(src.bright, -2, 2, base.bright),
    };
  }
  out.f0 = {};
  for (const name of Object.keys(mod.F0_TARGETS)) {
    out.f0[name] = Math.round(clampNum(body?.f0?.[name], 170, 280, mod.F0_TARGETS[name]));
  }
  ensureState();
  await writeFile(join(STATE, 'tuning.json'), JSON.stringify(out, null, 2), 'utf8');
  return tuningData();
}

// —— 静态文件 / 路由 ——
async function readBody(req, limit = 2 * 1024 * 1024) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new Error('请求太大');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return {}; }
}


// 13 类真人参考值：合成时「本句现量 → 判男女 → 参考值浮动 ≤0.5% → 算倍率」
async function refsData() {
  const cands = [join(ROOT, 'state', 'emo-ref.json'), join(ROOT, 'python', 'emo-ref.json'), join(ROOT, 'emo-ref.json')];
  for (const p of cands) {
    if (!existsSync(p)) continue;
    const j = safeRead(p, null);
    if (!j || !j.classes) continue;
    return { ok: true, path: p, mtime: statSync(p).mtimeMs, note: j.note || '', genderDefault: j.gender_default || 'F', classes: j.classes };
  }
  return { ok: false, error: '没找到 emo-ref.json（参考值表）' };
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  try {
    if (url.pathname === '/api/ping') {
      return json(res, 200, { ok: true, service: 'voice-ui' });
    }
    if (url.pathname === '/api/status') {
      const cfg = getConfig();
      const health = await ttsHealth(cfg.ttsUrl);
      return json(res, 200, {
        ok: true,
        version: safeRead(join(ROOT, 'package.json'), {}).version || '',
        root: ROOT,
        caps: capabilities(),
        config: cfg,
        tts: health,
        tuning: await tuningData(),
        emph: await emphData(),
        voicePolicy: voicePolicy(),
        service: `http://127.0.0.1:${PORT}`,
      });
    }
    if (url.pathname === '/api/refs') {
      return json(res, 200, await refsData());
    }
    if (url.pathname === '/api/stats') {
      const [disk, tokens] = await Promise.all([diskUsage(), scanTodayTokens()]);
      return json(res, 200, { ok: true, disk, tokens });
    }
    if (url.pathname === '/api/tts/test' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, await ttsHealth(body.url));
    }
    if (url.pathname === '/api/tts/save' && req.method === 'POST') {
      const body = await readBody(req);
      const cfg = getConfig();
      cfg.ttsUrl = String(body.url || cfg.ttsUrl).trim().replace(/\/+$/, '');
      cfg.pricePerM = clampNum(body.pricePerM, 0, 1000, cfg.pricePerM);
      ensureState();
      await writeFile(join(STATE, 'ui-config.json'), JSON.stringify(cfg, null, 2), 'utf8');
      tokenCache.at = 0;
      return json(res, 200, { ok: true, config: cfg, tts: await ttsHealth(cfg.ttsUrl) });
    }
    if (url.pathname === '/api/tts/sample' && req.method === 'POST') {
      const body = await readBody(req);
      const cfg = getConfig();
      const text = String(body.text || '').slice(0, 80);
      if (!text) return json(res, 400, { ok: false, error: '没填文本' });
      const base = String(cfg.ttsUrl).replace(/\/+$/, '');
      const r = await fetch(`${base}/speak`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text, emotion: 'neutral', intensity: 1, pitch: 0, rate: '+0%' }),
        signal: AbortSignal.timeout(120000),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j?.ok || !j?.path) return json(res, 502, { ok: false, error: j?.error || `TTS ${r.status}` });
      const buf = await readFile(String(j.path));
      res.writeHead(200, { 'content-type': 'audio/wav', 'content-length': buf.length, 'cache-control': 'no-store' });
      return res.end(buf);
    }
    if (url.pathname === '/api/clean' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, await clean(String(body.id || '')));
    }
    if (url.pathname === '/api/voicepolicy/defaults' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, { ok: true, policy: await saveVoiceDefaults(body || {}) });
    }
    if (url.pathname === '/api/voicepolicy' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, { ok: true, policy: await saveVoicePolicy(body || {}) });
    }
    if (url.pathname === '/api/emph' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, await saveEmph(body?.params || body || {}));
    }
    if (url.pathname === '/api/tuning' && req.method === 'POST') {
      const body = await readBody(req);
      return json(res, 200, await saveTuning(body));
    }
    if (url.pathname === '/api/tuning/reset' && req.method === 'POST') {
      rmSafe(join(STATE, 'tuning.json'));
      return json(res, 200, await tuningData());
    }
    if (url.pathname === '/' || url.pathname === '/index.html') {
      const buf = await readFile(join(HERE, 'index.html'));
      res.writeHead(200, { 'content-type': MIME['.html'], 'cache-control': 'no-store' });
      return res.end(buf);
    }
    const file = join(HERE, basename(url.pathname));
    if (existsSync(file) && statSync(file).isFile() && MIME[extname(file)]) {
      const buf = await readFile(file);
      res.writeHead(200, { 'content-type': MIME[extname(file)], 'cache-control': 'no-store' });
      return res.end(buf);
    }
    json(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    json(res, 500, { ok: false, error: String(e?.stack || e) });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`voice-ui http://127.0.0.1:${PORT}`);
});

// 给 /voice-ui 指令用：被拉起后活了就自己退出？不，常驻。
