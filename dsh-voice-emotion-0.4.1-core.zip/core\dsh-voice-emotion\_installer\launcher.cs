using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

// 「安装.exe」的源码：只做一件事——找到 app\_installer\install-gui.ps1 并拉起。
// 不读写任何文件，避免被杀软/权限拦。
internal static class Launcher
{
    [STAThread]
    private static void Main()
    {
        string here = AppDomain.CurrentDomain.BaseDirectory;
        string ps1 = Path.Combine(here, @"app\_installer\install-gui.ps1");

        if (!File.Exists(ps1))
        {
            MessageBox.Show(
                "没找到安装脚本：\n" + ps1 + "\n\n请先把整个压缩包解压到一个文件夹，再双击本程序。",
                "语音情绪插件 · 安装", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        Process.Start("powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + ps1 + "\"");
    }
}
