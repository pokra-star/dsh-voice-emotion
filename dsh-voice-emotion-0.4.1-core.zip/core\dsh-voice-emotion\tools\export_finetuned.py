"""把微调过的 emotion2vec（最后两层 + MLP 头）导成单文件 ONNX。

输入 wav[1,T]（16k 单声道，float32），输出 4 类 logits[1,4]。
头一起焊进图里，推理端只需要 softmax，不用再拼 numpy。

用法：
    python tools/export_finetuned.py [--weights finetune-best.pt] [--out model-ft.onnx]
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from finetune_last2 import LABELS, PKG, FineTuner, load_clip  # noqa: E402
from export_onnx import load_embedder, sample_files  # noqa: E402


class Wrapped(torch.nn.Module):
    """把 FineTuner 的 forward 收成一个参数：wav -> logits。"""

    def __init__(self, ft: FineTuner, trainable_from: int):
        super().__init__()
        self.ft = ft
        self.trainable_from = trainable_from

    def forward(self, wav: torch.Tensor) -> torch.Tensor:
        return self.ft(wav, self.trainable_from)


def load_finetuned(weights: Path) -> tuple[Wrapped, int]:
    blob = torch.load(weights, map_location="cpu", weights_only=False)
    meta = blob.get("meta", {})
    state = blob["state"]
    trainable_from = int(meta.get("trainable_from", 6))

    enc = load_embedder(Path(meta.get("model_dir", "")) if meta.get("model_dir") else _default_model_dir())
    ft = FineTuner(enc.model, num_classes=len(LABELS))
    model = ft.model
    for idx_key, sd in state.get("blocks", {}).items():
        model.blocks[int(idx_key)].load_state_dict(sd)
    if state.get("norm") is not None and model.norm is not None:
        model.norm.load_state_dict(state["norm"])
    ft.head.load_state_dict(state["head"])
    ft.eval()
    return Wrapped(ft, trainable_from), trainable_from


def _default_model_dir() -> Path:
    import os

    home = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
    found = sorted((home / "models").rglob("iic--emotion2vec_plus_large/snapshots/*/configuration.json"))
    if found:
        return found[0].parent
    return home / "models" / "models" / "iic--emotion2vec_plus_large" / "snapshots" / "master"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=str(PKG / "finetune-best.pt"))
    ap.add_argument("--out", default=str(PKG / "model-ft.onnx"))
    ap.add_argument("--samples", type=int, default=24)
    args = ap.parse_args()

    weights = Path(args.weights)
    if not weights.exists():
        print(f"[ft-export] 没有微调权重：{weights}", flush=True)
        return 2

    print("[ft-export] 加载微调后的模型…", flush=True)
    t0 = time.time()
    wrapped, trainable_from = load_finetuned(weights)
    print(f"[ft-export] 就绪（{time.time() - t0:.1f}s，解冻起始层 {trainable_from}）", flush=True)

    dummy = torch.randn(1, 16000 * 4)
    with torch.no_grad():
        logits = wrapped(dummy)
    print(f"[ft-export] 前向 logits {tuple(logits.shape)}", flush=True)

    out_tmp = str(Path(args.out).with_name("model-ft-dynamo.onnx"))
    t0 = time.time()
    torch.onnx.export(
        wrapped,
        dummy,
        out_tmp,
        input_names=["wav"],
        output_names=["logits"],
        dynamic_axes={"wav": {0: "batch", 1: "time"}, "logits": {0: "batch"}},
        opset_version=18,
        dynamo=True,
    )
    print(f"[ft-export] dynamo 导出 {time.time() - t0:.1f}s → {out_tmp}", flush=True)

    import onnx
    from onnx.external_data_helper import convert_model_from_external_data

    model_proto = onnx.load(out_tmp)
    if Path(out_tmp + ".data").exists():
        convert_model_from_external_data(model_proto)
        onnx.save_model(model_proto, args.out, save_as_external_data=False)
        print(f"[ft-export] 合并成单文件 → {args.out}", flush=True)
    else:
        Path(out_tmp).replace(args.out)

    size_mb = Path(args.out).stat().st_size / 1e6
    print(f"[ft-export] {args.out}（{size_mb:.1f} MB）", flush=True)

    import onnxruntime as ort

    sess = ort.InferenceSession(args.out, providers=["CPUExecutionProvider"])
    files = sample_files(args.samples)
    agree = 0
    sims: list[float] = []
    t_t, t_o = 0.0, 0.0
    for p in files:
        clip = load_clip(str(p))
        if clip is None:
            continue
        with torch.no_grad():
            t = time.time()
            a = wrapped(clip)
            t_t += time.time() - t
        t = time.time()
        b = sess.run(None, {"wav": clip.numpy()})[0]
        t_o += time.time() - t
        la, lb = int(a.argmax()), int(b.argmax())
        agree += int(la == lb)
        va, vb = a.numpy().ravel(), np.asarray(b).ravel()
        sims.append(float(np.dot(va, vb) / (np.linalg.norm(va) * np.linalg.norm(vb) + 1e-12)))

    n = max(1, len(sims))
    report = {
        "weights": str(weights),
        "out": args.out,
        "size_mb": round(size_mb, 1),
        "samples": len(sims),
        "label_agree": f"{agree}/{len(sims)}",
        "logit_cosine_mean": round(float(np.mean(sims)), 6) if sims else None,
        "torch_ms": round(t_t / n * 1000, 1),
        "onnx_ms": round(t_o / n * 1000, 1),
        "labels": LABELS,
    }
    print(f"[ft-export] 标签一致 {report['label_agree']}，logits cosine {report['logit_cosine_mean']}", flush=True)
    print(f"[ft-export] 速度 torch {report['torch_ms']} ms → onnx {report['onnx_ms']} ms", flush=True)
    (PKG / "onnx-ft-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
