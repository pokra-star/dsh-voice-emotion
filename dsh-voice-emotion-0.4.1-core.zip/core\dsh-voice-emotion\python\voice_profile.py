"""量一段语音的 F0/F1/F2/F3，给出六腔锚点（比例锚点）。

用法：
  python voice_profile.py --wav <样本.wav> [--name <音色名>] [--out <json>]
打印 JSON：
  {"ok":true,"name":"refB_zh02_trim","f0":231.0,"F1":677.0,"F2":1377.0,"F3":2687.0,
   "anchors":{"nasal_fc":900.4,"pharynx_fc":2848.2,...},"ratios":{"nasal":1.33,...}}

为什么要有这个：六腔的染色峰如果写死绝对 Hz（鼻腔 900、咽腔 2850），换成女声就落到
别的谐波上，同一个「胸腔 +0.4」听起来完全不是一回事。改成按该音色自己的共振峰取比例，
同一套权重才能在男女声之间保持方向一致。
"""
import argparse
import json
import sys


def _load(wav):
    import numpy as np
    import soundfile as sf
    import librosa
    y, sr = sf.read(str(wav), dtype="float32")
    if y.ndim > 1:
        y = y.mean(1)
    if sr != 32000:
        y = librosa.resample(y, orig_sr=sr, target_sr=32000)
        sr = 32000
    return y, sr


def formants(y, sr):
    import numpy as np
    import parselmouth
    snd = parselmouth.Sound(y, sampling_frequency=sr)
    pitch = snd.to_pitch(time_step=0.01, pitch_floor=70, pitch_ceiling=600)
    fm = snd.to_formant_burg(time_step=0.01, max_number_of_formants=5,
                             maximum_formant=5500, window_length=0.025)
    rows = []
    for t in np.arange(0.02, snd.duration, 0.01):
        f0 = pitch.get_value_at_time(float(t))
        if f0 != f0 or f0 == 0:
            continue
        vals = [fm.get_value_at_time(k, float(t)) for k in (1, 2, 3)]
        if any(v != v for v in vals):
            continue
        rows.append([f0] + vals)
    if not rows:
        raise RuntimeError("没量到浊音帧（样本太短或全清音）")
    m = np.nanmedian(np.array(rows), axis=0)
    return {"f0": round(float(m[0]), 1), "F1": round(float(m[1]), 1),
            "F2": round(float(m[2]), 1), "F3": round(float(m[3]), 1)}


# 比例锚点：和 voice-pipeline/voice-profile.py 保持一致
RATIOS = {
    "nasal": ("F1", 1.33),
    "pharynx": ("F3", 1.06),
    "ventricle": ("F3", 1.27),
    "presence": ("F3", 0.93),
    "subglottal": ("F1", 1.00),
}


def anchors_of(fm):
    out = {}
    for k, (base, r) in RATIOS.items():
        key = "nasal_fc" if k == "nasal" else (
            "pharynx_fc" if k == "pharynx" else (
                "ventricle_fc" if k == "ventricle" else (
                    "presence_fc" if k == "presence" else "subglottal_fc")))
        out[key] = round(r * fm[base], 1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wav", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    try:
        y, sr = _load(a.wav)
        fm = formants(y, sr)
        res = {"ok": True, "name": a.name or "", "seconds": round(len(y) / sr, 2),
               **fm, "anchors": anchors_of(fm),
               "ratios": {k: v[1] for k, v in RATIOS.items()}}
    except Exception as e:  # noqa: BLE001
        res = {"ok": False, "error": f"{type(e).__name__}: {e}"}

    text = json.dumps(res, ensure_ascii=False)
    if a.out:
        import pathlib
        pathlib.Path(a.out).write_text(text, encoding="utf-8")
    print(text)
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
