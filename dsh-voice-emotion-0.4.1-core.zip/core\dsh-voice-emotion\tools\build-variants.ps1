param([string]$Version = '0.4.0')
# 打三个独立包：说 / 听 / 全。
# 三份都放同一套完整 app（不删模型、不做小），只改 app\variant.json 的默认开关。
# 用法：powershell -ExecutionPolicy Bypass -File tools\build-variants.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$pkg = Get-Content (Join-Path $root 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($pkg.version -ne $Version) { throw "package.json 是 $($pkg.version)，和 -Version $Version 不一致" }

$stage = Join-Path $root 'tmp\variant-build'
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
$base = Join-Path $stage 'base\app'
New-Item -ItemType Directory -Path $base -Force | Out-Null

$items = @(
  'index.js', 'package.json', 'cordis.patch.yml', 'profiles.json',
  'README.md', 'README.detail.md', 'LICENSE', '.gitignore',
  'model-embed.onnx', 'model-neg.json', 'model-v2.json',
  'assets', 'lib', 'python', 'tools', 'ui', '_installer', '启动语音控制台.cmd'
)
foreach ($i in $items) {
  $src = Join-Path $root $i
  if (-not (Test-Path $src)) { throw "缺文件：$i" }
  Copy-Item $src -Destination $base -Recurse -Force
}

New-Item -ItemType Directory -Path (Join-Path $base 'models') -Force | Out-Null
$modelSrc = Join-Path $root 'models'
if (-not (Test-Path (Join-Path $modelSrc 'faster-whisper-small'))) {
  $modelSrc = Join-Path $env:USERPROFILE '.dsh-voice-emotion\models'
}
if (-not (Test-Path (Join-Path $modelSrc 'faster-whisper-small'))) { throw '缺 faster-whisper-small（包根 models 或 %USERPROFILE%\.dsh-voice-emotion\models）' }
Copy-Item (Join-Path $modelSrc 'faster-whisper-small') (Join-Path $base 'models') -Recurse -Force

$promo = Join-Path $root '..\..\docs\语音情绪-一页说明.png'
if (-not (Test-Path $promo)) { throw "缺宣传图：$promo" }
$report = Join-Path $root '..\..\docs\语音情绪-技术报告.md'
$changes = Join-Path $root '..\..\docs\语音情绪-更新内容-0.3.18.md'
if (-not (Test-Path $report)) { throw "缺技术报告：$report" }
if (-not (Test-Path $changes)) { throw "缺更新内容：$changes" }

$icon = Join-Path $root 'assets\icon.ico'
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path $csc)) { $csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (-not (Test-Path $csc)) { throw '找不到 csc.exe（.NET Framework 4）' }
$exe = Join-Path $stage '安装.exe'
& $csc /nologo /target:winexe /codepage:65001 "/win32icon:$icon" /r:System.Windows.Forms.dll "/out:$exe" (Join-Path $root '_installer\launcher.cs')
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $exe)) { throw '编译安装器失败' }

$variants = @(
  @{ key = 'speak';    label = '说'; listen = 'off'; speak = 'on';   note = '这版只做「说」：不注册转写/情绪/历史。' },
  @{ key = 'listen'; label = '听'; listen = 'on';  speak = 'off';  note = '这版只做「听」：不注册 voice_speak，不需要 TTS。' },
  @{ key = 'full';    label = '全'; listen = 'on';  speak = 'auto'; note = '这版「说 + 听」都有：有 TTS 就开说，没有也不影响听。' }
)

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$bak = Join-Path $root 'tmp\dist-backup'
New-Item -ItemType Directory -Path $bak -Force | Out-Null

foreach ($v in $variants) {
  $top = Join-Path $stage ("语音情绪插件-$Version-$($v.label)")
  $app = Join-Path $top 'app'
  New-Item -ItemType Directory -Path $app -Force | Out-Null
  Copy-Item (Join-Path $base '*') $app -Recurse -Force

  $variantJson = @{ listen = $v.listen; speak = $v.speak; label = $v.label } | ConvertTo-Json -Compress
  [IO.File]::WriteAllText((Join-Path $app 'variant.json'), $variantJson + "`n", (New-Object Text.UTF8Encoding($false)))

  Copy-Item $exe (Join-Path $top '安装.exe') -Force
  Copy-Item $promo (Join-Path $top '宣传图.png') -Force
  Copy-Item $report (Join-Path $top '语音情绪-技术报告.md') -Force
  Copy-Item $changes (Join-Path $top '更新内容.md') -Force

  $note = @"
dsh-voice-emotion $Version —— $($v.label)版
====================================================
1. 先解压，再双击「安装.exe」。只有一个安装文件，图标是那道白色声波。
2. $($v.note)
3. 这版没有删任何模型文件（按你的要求不做小），所以三份包体积一样。
4. 「说」要一个能 POST /speak 的 TTS 服务，默认 http://127.0.0.1:3120。
   换 RVC：插件配置里设 ttsEngine: rvc、ttsVoice: 角色名，按需加 indexRate/protect；
   或跑 node tools/set-tts.mjs --engine rvc --voice 角色名 --index-rate 0.75 --protect 0.33。
5. 装完重启 DSH（或热重载插件）。解压出来的 app 文件夹不要改名、不要拆开。
6. 控制台：DSH 里输 /voice-ui，或双击桌面「语音控制台.cmd」，会开 127.0.0.1:3135。
7. 根目录的「语音情绪-技术报告.md」和「更新内容.md」是这一版的说明，别删。
"@
  [IO.File]::WriteAllText((Join-Path $top '安装说明.txt'), $note, (New-Object Text.UTF8Encoding($true)))

  $zip = Join-Path $dist "dsh-voice-emotion-$Version-$($v.key).zip"
  if (Test-Path $zip) { Move-Item $zip (Join-Path $bak ("dsh-voice-emotion-$Version-$($v.key).zip." + (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force }
  [IO.Compression.ZipFile]::CreateFromDirectory($top, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
  $z = [IO.Compression.ZipFile]::OpenRead($zip)
  try { $n = $z.Entries.Count } finally { $z.Dispose() }
  Write-Host ("ok: {0}  ({1:N0} MB, {2} entries)" -f $zip, ((Get-Item $zip).Length / 1MB), $n)
}
Write-Host "staging: $stage"

