"""emotion2vec + 线性头的常驻推理服务（端口 3132）。

POST /predict  {"file": "C:/...wav"}
  -> {"ok": true, "emotion": "angry", "confidence": 0.53,
      "top": [["angry", 0.53], ["sad", 0.21], ["neutral", 0.12]],
      "trained": {...模型元信息...}}

GET /health -> {"ok": true, "pid": ..., "labels": [...]}

模型参数来自 model-v2.json（由 tools/train_m3ed.py --export 生成），
推理 = 标准化 → 线性 logits → softmax。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
HOME_DIR = Path(os.environ.get("DSH_VOICE_EMOTION_HOME") or (Path.home() / ".dsh-voice-emotion"))
WEIGHTS = Path(os.environ.get("VOICE_EMO_WEIGHTS", str(PKG / "model-v2.json")))


def find_model_dir() -> str:
    """找 emotion2vec 权重目录：环境变量 → 插件 home 下的 modelscope 缓存 → 开发机老路径。

    modelscope 的路径是 models/<org>--<name>/snapshots/<rev>，这里扫一遍，取第一个带 config 的。"""
    env = os.environ.get("VOICE_EMO2VEC_DIR")
    if env and Path(env).is_dir():
        return env
    roots = [HOME_DIR / "models", Path.home() / ".dsh-voice-emo2vec" / "models"]
    for root in roots:
        if not root.is_dir():
            continue
        for cfg in root.glob("**/iic--emotion2vec_plus_large/snapshots/*/configuration.json"):
            return str(cfg.parent)
        for cfg in root.glob("**/emotion2vec_plus_large/**/configuration.json"):
            return str(cfg.parent)
    return str(HOME_DIR / "models" / "models" / "iic--emotion2vec_plus_large" / "snapshots" / "master")


MODEL_DIR = find_model_dir()

_lock = threading.Lock()
_model = None
_params = None


def load_params(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    data["mean"] = np.asarray(data["mean"], dtype=np.float32)
    data["scale"] = np.asarray(data["scale"], dtype=np.float32)
    data["coef"] = np.asarray(data["coef"], dtype=np.float32)
    data["intercept"] = np.asarray(data["intercept"], dtype=np.float32)
    return data


def load_embedder():
    from funasr import AutoModel

    return AutoModel(
        model="iic/emotion2vec_plus_large",
        model_path=MODEL_DIR,
        device="cpu",
        disable_update=True,
        disable_pbar=True,
        log_level="ERROR",
    )


def embed(model, wav: str) -> np.ndarray:
    out = model.generate(wav, granularity="utterance", extract_embedding=True, disable_pbar=True)
    if isinstance(out, list):
        out = out[0]
    emb = out.get("feats") if isinstance(out, dict) else None
    if emb is None and isinstance(out, dict):
        emb = out.get("embedding")
    if emb is None:
        raise RuntimeError(f"no embedding: {list(out)[:6] if isinstance(out, dict) else type(out)}")
    return np.asarray(emb, dtype=np.float32).reshape(-1)


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


def predict(wav: str) -> dict:
    global _model, _params
    if not Path(wav).exists():
        raise FileNotFoundError(wav)
    if _model is None:
        _model = load_embedder()
    if _params is None:
        _params = load_params(WEIGHTS)
    vec = embed(_model, wav)
    p = _params
    z = (vec - p["mean"]) / p["scale"]
    logits = p["coef"] @ z + p["intercept"]
    probs = softmax(logits)
    order = np.argsort(-probs)
    labels = p["labels"]
    top = [[labels[i], round(float(probs[i]), 4)] for i in order[:3]]
    return {
        "emotion": labels[int(order[0])],
        "confidence": round(float(probs[int(order[0])]), 4),
        "top": top,
        "trained": {
            "cvAccuracy": p.get("cvAccuracy"),
            "cvMacroF1": p.get("cvMacroF1"),
            "majorityBaseline": p.get("majorityBaseline"),
            "trainedOn": p.get("trainedOn"),
            "labels": labels,
        },
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):  # noqa: A003
        sys.stderr.write("[serve_v2] " + fmt % args + "\n")

    def _json(self, code: int, obj: dict):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path.startswith("/health"):
            labels = _params["labels"] if _params else None
            self._json(200, {"ok": True, "pid": os.getpid(), "labels": labels})
        else:
            self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):  # noqa: N802
        if not self.path.startswith("/predict"):
            self._json(404, {"ok": False, "error": "not found"})
            return
        try:
            n = int(self.headers.get("content-length") or 0)
            payload = json.loads(self.rfile.read(n) or b"{}")
            wav = str(payload.get("file") or "").strip()
            if not wav:
                self._json(400, {"ok": False, "error": "missing file"})
                return
            with _lock:
                res = predict(wav)
            self._json(200, {"ok": True, **res})
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=3132)
    ap.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()
    global _params
    if WEIGHTS.exists():
        _params = load_params(WEIGHTS)
        print(f"[serve_v2] weights {WEIGHTS} labels={_params['labels']}", flush=True)
    else:
        print(f"[serve_v2] weights missing: {WEIGHTS}（先跑 train --export）", flush=True)
    global _model
    try:
        _model = load_embedder()
        print("[serve_v2] emotion2vec loaded", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[serve_v2] embedder load failed: {e}", flush=True)
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"[serve_v2] listening http://{args.host}:{args.port}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
