"""常驻声学分析服务（2026-11-07）。

为什么需要它：analyze.py 每次冷启要 import librosa/numpy（1~2 秒），而语音消息、
TTS 标签采样都是高频小请求。这里把模型和依赖驻留在内存里，用 HTTP 暴露同一套结果。

用法：
    python serve.py [--port 3131] [--host 127.0.0.1]

接口：
    POST /analyze   {"file": "C:/path/to.wav", "frames": false}  -> analyze.py 的同一份 JSON
    GET  /health                                                -> {"ok": true, "pid": …}
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyze import analyze  # noqa: E402


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # 静默：不要往 stdout 刷访问日志
        pass

    def _send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path.rstrip("/") == "/health":
            self._send(200, {"ok": True, "pid": os.getpid()})
        else:
            self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):  # noqa: N802
        if self.path.rstrip("/") != "/analyze":
            self._send(404, {"ok": False, "error": "not found"})
            return
        try:
            length = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            req = json.loads(raw.decode("utf-8") or "{}")
            path = str(req.get("file") or "").strip()
            if not path or not os.path.exists(path):
                self._send(400, {"ok": False, "error": "file 不存在"})
                return
            result = analyze(path, want_frames=bool(req.get("frames")))
            self._send(200, result)
        except Exception as exc:  # 单个请求失败不能拖垮服务
            self._send(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3131)
    args = parser.parse_args()

    # 预热一次，把 librosa 的懒加载提前做掉（首次调用少 300~800ms）
    try:
        import numpy as np  # noqa: F401
        import librosa  # noqa: F401
    except Exception:
        pass

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(json.dumps({"ok": True, "listening": f"http://{args.host}:{args.port}", "pid": os.getpid()}), flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
