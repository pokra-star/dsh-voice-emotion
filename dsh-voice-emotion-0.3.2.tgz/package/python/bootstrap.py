# -*- coding: utf-8 -*-
"""首次运行自动装依赖（懒人档）：找系统 Python → 建 venv → 从国内镜像装 librosa 等 → 写 .ready。

用法：
    python python/bootstrap.py [--dir <venv 目录>] [--mirror <pip 镜像>] [--force]

退出码：0 成功；2 找不到可用的 Python；3 pip 安装失败。
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REQ = HERE / "requirements.txt"
DEFAULT_DIR = Path(os.environ.get("DSH_VOICE_EMOTION_HOME", Path.home() / ".dsh-voice-emotion")) / "venv"
MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"


def log(msg):
    print(f"[bootstrap] {msg}", flush=True)


def find_python():
    """优先系统 python（3.10+），跳过自己（venv 里的解释器）。"""
    cands = []
    for name in ("python", "python3", "py"):
        exe = shutil.which(name)
        if exe:
            cands.append(exe)
    # 常见的 Windows 安装位置
    for p in (
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Python/Python313/python.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Python/Python312/python.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Python/Python311/python.exe",
        Path("C:/Python313/python.exe"),
    ):
        if p.exists():
            cands.append(str(p))
    me = Path(sys.executable).resolve()
    for exe in cands:
        try:
            if Path(exe).resolve() == me:
                continue
            out = subprocess.run([exe, "-c", "import sys;print(sys.version_info[:2])"],
                                 capture_output=True, text=True, timeout=20)
            if out.returncode != 0:
                continue
            major, minor = [int(x.strip(" ()")) for x in out.stdout.replace("(", " ").replace(",", " ").replace(")", " ").split()][:2]
            if (major, minor) >= (3, 10):
                return exe
        except Exception:
            continue
    return None


def ensure_venv(base_python, venv_dir):
    py = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if py.exists():
        return py
    log(f"建 venv：{venv_dir}")
    venv_dir.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([base_python, "-m", "venv", str(venv_dir)], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"建 venv 失败：{r.stderr.strip()[:400]}")
    return py


def install(py, mirror):
    log(f"装依赖（{REQ.name}）：这一步约 470 MB，国内镜像 2~4 分钟")
    cmd = [str(py), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQ), "-i", mirror]
    env = dict(os.environ, PIP_DEFAULT_TIMEOUT="120")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env)
    for line in p.stdout:
        line = line.rstrip()
        if line and ("Downloading" in line or "Installing" in line or "Successfully" in line or "ERROR" in line):
            log(line[:160])
    if p.wait() != 0:
        return False
    return True


def verify(py):
    r = subprocess.run([str(py), "-c", "import librosa, soundfile, numpy;print(librosa.__version__)"],
                       capture_output=True, text=True)
    return r.returncode == 0 and r.stdout.strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(DEFAULT_DIR))
    ap.add_argument("--mirror", default=MIRROR)
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    venv_dir = Path(a.dir)
    marker = venv_dir / ".ready"

    if marker.exists() and not a.force:
        py = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        if py.exists() and verify(py):
            print(str(py))
            return 0

    base = find_python()
    if not base:
        log("没找到 Python 3.10+。请先装 Python（https://www.python.org/downloads/ ，安装时勾 Add to PATH），再重试。")
        return 2
    log(f"用 {base}")
    py = ensure_venv(base, venv_dir)
    if not install(py, a.mirror):
        log("pip 安装失败：换镜像重试 `--mirror https://pypi.org/simple`，或检查网络")
        return 3
    ver = verify(py)
    if not ver:
        log("装完但 import 失败，看看 pip 日志")
        return 3
    marker.write_text(ver + "\n", encoding="utf-8")
    log(f"好了：{py}（librosa {ver}）")
    print(str(py))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
