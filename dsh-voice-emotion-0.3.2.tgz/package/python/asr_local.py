#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""本地转写：faster-whisper，模型在 ~/.dsh-voice-emotion/models/faster-whisper-base。

用法：python asr_local.py <wav> [--model DIR]
输出：单行 JSON {"ok":true,"text":"...","language":"zh","seconds":1.2}
失败：  {"ok":false,"error":"..."}
"""
import argparse
import json
import os
import sys
import time

HOME = os.environ.get('DSH_VOICE_EMOTION_HOME') or os.path.join(os.path.expanduser('~'), '.dsh-voice-emotion')
DEFAULT_MODEL = os.path.join(HOME, 'models', 'faster-whisper-base')

_model = None


def _patch_av():
    """新版 PyAV 去掉了 av.open(metadata_errors=...) 这个参数，而 faster-whisper 还在传。
    这里包一层，把它吞掉——只是 metadata 报错策略，不影响解码。"""
    import av
    original = av.open

    def compat_open(*args, **kwargs):
        kwargs.pop('metadata_errors', None)
        return original(*args, **kwargs)

    av.open = compat_open


def load(model_dir):
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        _model = WhisperModel(model_dir, device='cpu', compute_type='int8')
    return _model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('file')
    ap.add_argument('--model', default=DEFAULT_MODEL)
    ap.add_argument('--language', default='zh')
    args = ap.parse_args()

    if not os.path.isfile(args.file):
        print(json.dumps({'ok': False, 'error': f'找不到文件：{args.file}'}, ensure_ascii=False))
        return 0
    if not os.path.isdir(args.model):
        print(json.dumps({'ok': False, 'error': f'模型目录不存在：{args.model}'}, ensure_ascii=False))
        return 0

    t0 = time.time()
    try:
        _patch_av()
        model = load(args.model)
        segments, info = model.transcribe(
            args.file,
            language=args.language,
            vad_filter=True,
            beam_size=5,
            initial_prompt='以下是普通话的句子。',
        )
        text = ''.join(s.text for s in segments).strip()
        print(json.dumps({
            'ok': True,
            'text': text,
            'language': getattr(info, 'language', args.language),
            'seconds': round(time.time() - t0, 2),
        }, ensure_ascii=False))
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({'ok': False, 'error': f'{type(exc).__name__}: {exc}'}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
