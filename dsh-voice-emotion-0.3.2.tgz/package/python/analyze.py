#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音情绪分析：只测声学特征，不做语义判断。

用法：
    python analyze.py <audio-file> [--no-frames]

输出（stdout，单行 JSON）。所有「时间」单位是秒，「音高」类都是半音（相对本条中位数）。
"""
import json
import sys
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import librosa

HOP = 160      # 10ms
FRAME = 400    # 25ms


def analyze(path, want_frames=False):
    y, sr = librosa.load(path, sr=16000, mono=True)
    if y.size == 0:
        raise ValueError("空音频")
    duration = float(len(y) / sr)
    peak_db = float(20 * np.log10(max(float(np.max(np.abs(y))), 1e-6)))

    rms = librosa.feature.rms(y=y, frame_length=FRAME, hop_length=HOP)[0]
    db = 20 * np.log10(np.maximum(rms, 1e-6))
    thr = float(np.max(db) - 25.0)
    voiced = db > thr
    voiced_ratio = float(np.mean(voiced)) if voiced.size else 0.0
    rms_db_mean = float(np.mean(db[voiced])) if voiced.any() else float(np.mean(db))
    loud_var = float(np.std(db[voiced])) if voiced.any() else 0.0

    # 停顿：连续 >0.15s 的静音段
    frame_sec = HOP / sr
    pauses = []
    run = 0
    for v in voiced:
        if not v:
            run += 1
        else:
            if run * frame_sec >= 0.15:
                pauses.append(run * frame_sec)
            run = 0
    if run * frame_sec >= 0.15:
        pauses.append(run * frame_sec)
    pause_count = len(pauses)
    pause_mean = float(np.mean(pauses)) if pauses else 0.0
    pause_max = float(np.max(pauses)) if pauses else 0.0

    # 起音（语速代理）+ 音节峰（平滑能量包络的峰）
    onset_env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=HOP)
    onsets = librosa.onset.onset_detect(onset_envelope=onset_env, sr=sr, hop_length=HOP, units="time")
    onset_count = int(len(onsets))
    speech_rate = float(onset_count / max(duration, 1e-3))
    try:
        tempo = float(np.atleast_1d(librosa.beat.tempo(onset_envelope=onset_env, sr=sr, hop_length=HOP))[0])
    except Exception:
        tempo = 0.0
    # 音节率：把 onset 包络平滑后找峰（0.09s 内只留一个）
    try:
        env = librosa.util.normalize(onset_env)
        peaks = librosa.util.peak_pick(env, pre_max=5, post_max=5, pre_avg=9, post_avg=9, delta=0.10, wait=9)
        syllable_rate = float(len(peaks) / max(duration, 1e-3))
    except Exception:
        syllable_rate = 0.0

    # 基频（去掉八度跳变）
    seg = y[: int(min(len(y), 20 * sr))]
    f0 = librosa.yin(seg, fmin=70, fmax=420, sr=sr, frame_length=1024, hop_length=HOP)
    f0 = f0[np.isfinite(f0) & (f0 > 60) & (f0 < 450)]
    if f0.size:
        med0 = float(np.median(f0))
        f0 = f0[(f0 > med0 / 1.9) & (f0 < med0 * 1.9)]
    if f0.size >= 4:
        f0_median = float(np.median(f0))
        st = 12.0 * np.log2(np.maximum(f0, 1e-3) / f0_median)
        f0_std_st = float(np.std(st))
        f0_range_st = float(np.percentile(st, 95) - np.percentile(st, 5))
        # 首尾走向：后 20% 平均 - 前 20% 平均（>0 上扬，<0 下坠）
        k = max(1, int(len(st) * 0.2))
        f0_end_st = float(np.mean(st[-k:]) - np.mean(st[:k]))
        # 整体走势（每分钟半音）
        xs = np.arange(len(st), dtype=float) * (HOP / sr)
        try:
            slope = float(np.polyfit(xs, st, 1)[0] * 60.0)
        except Exception:
            slope = 0.0
    else:
        f0_median = f0_std_st = f0_range_st = f0_end_st = slope = 0.0

    # 频谱：重心、倾斜（dB/oct，越平越亮）
    S = np.abs(librosa.stft(y, n_fft=1024, hop_length=HOP))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=1024)
    power = S ** 2
    total = float(np.sum(power) + 1e-12)
    centroid = float(np.sum(freqs[:, None] * power) / total) if total > 0 else 0.0
    band_db = 10 * np.log10(np.mean(power, axis=1) + 1e-12)
    mask = freqs >= 100
    try:
        tilt = float(np.polyfit(np.log2(freqs[mask] / 100.0), band_db[mask], 1)[0])
    except Exception:
        tilt = 0.0

    # 能量走势（dB/s）
    if voiced.sum() >= 4:
        xs = np.arange(len(db), dtype=float)[voiced] * (HOP / sr)
        try:
            e_slope = float(np.polyfit(xs, db[voiced], 1)[0])
        except Exception:
            e_slope = 0.0
    else:
        e_slope = 0.0

    # 音质类特征（2026-11-07 加）：跟「说了什么」关系小，跟「怎么说的」关系大。
    # 跨句子容易漂的是 pause/tilt/f0End，这几个才是稳定的情绪线索。
    jitter_pct = 0.0
    if f0.size >= 6:
        dsteps = np.abs(np.diff(f0))
        jitter_pct = float(np.mean(dsteps) / (np.mean(f0[:-1]) + 1e-9) * 100.0)
    shimmer_pct = 0.0
    if int(voiced.sum()) >= 6:
        rv = rms[voiced]
        shimmer_pct = float(np.mean(np.abs(np.diff(rv))) / (np.mean(rv) + 1e-9) * 100.0)
    hnr_db = 0.0
    try:
        harm, perc = librosa.effects.hpss(y)
        eh = float(np.sum(harm ** 2) + 1e-12)
        en = float(np.sum(perc ** 2) + 1e-12)
        hnr_db = float(10.0 * np.log10(eh / en))
    except Exception:
        hnr_db = 0.0

    out = {
        "ok": True,
        "file": path,
        "duration": round(duration, 3),
        "voicedRatio": round(voiced_ratio, 4),
        "pauseRatio": round(1.0 - voiced_ratio, 4),
        "pauseCount": pause_count,
        "pauseMean": round(pause_mean, 3),
        "pauseMax": round(pause_max, 3),
        "speechRate": round(speech_rate, 3),
        "syllableRate": round(syllable_rate, 3),
        "onsetCount": onset_count,
        "rmsDb": round(rms_db_mean, 2),
        "peakDb": round(peak_db, 2),
        "loudnessVarDb": round(loud_var, 2),
        "energySlope": round(e_slope, 2),
        "f0Median": round(f0_median, 2),
        "f0StdSt": round(f0_std_st, 3),
        "f0RangeSt": round(f0_range_st, 3),
        "f0EndSt": round(f0_end_st, 3),
        "f0Slope": round(slope, 2),
        "centroid": round(centroid, 1),
        "tilt": round(tilt, 3),
        "tempo": round(tempo, 1),
        "jitterPct": round(jitter_pct, 3),
        "shimmerPct": round(shimmer_pct, 3),
        "hnrDb": round(hnr_db, 2),
    }

    if want_frames:
        step = max(1, int(round(0.1 * sr / HOP)))
        out["frameDb"] = [round(float(db[i]), 1) for i in range(0, len(db), step)][:600]

    return out


def _emit(text):
    sys.stdout.buffer.write(text.encode("utf-8"))
    sys.stdout.buffer.flush()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        _emit(json.dumps({"ok": False, "error": "用法: analyze.py <audio>"}, ensure_ascii=False))
        return 2
    try:
        _emit(json.dumps(analyze(args[0], want_frames="--frames" in sys.argv), ensure_ascii=False))
        return 0
    except Exception as e:  # noqa: BLE001
        _emit(json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
