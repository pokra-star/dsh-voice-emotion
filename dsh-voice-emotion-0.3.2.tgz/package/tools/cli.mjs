/**
 * CLI：不经过 DSH，直接测一条语音。
 *
 *   node tools/cli.mjs <音频路径> [--text "原话"] [--target happy] [--no-save]
 *   node tools/cli.mjs --history [--limit 10]
 */
import { analyze, historySummary } from '../lib/emotion.mjs';

const argv = process.argv.slice(2);
function flag(n, d = '') {
  const i = argv.indexOf('--' + n);
  return i >= 0 ? (argv[i + 1] ?? '') : d;
}
const has = (n) => argv.includes('--' + n);

if (has('history')) {
  const r = historySummary({ limit: Number(flag('limit', '10')) || 10 });
  console.log(JSON.stringify(r, null, 2));
  process.exit(0);
}

const file = argv.find((a) => !a.startsWith('--') && !argv[argv.indexOf(a) - 1]?.startsWith('--'));
if (!file) {
  console.error('用法：node tools/cli.mjs <音频路径> [--text "..."] [--target happy] [--no-save]');
  process.exit(1);
}

try {
  const r = analyze({
    file,
    text: flag('text', ''),
    target: flag('target', ''),
    save: !has('no-save'),
  });
  console.log('结论：', r.verdict);
  console.log('——细节——');
  console.log('说话人  ', r.speaker, '| 时长', r.seconds + 's');
  console.log('声学情绪', r.acoustic.emotion, `(置信 ${r.acoustic.confidence}${r.acoustic.coldStart ? '，冷启动基线' : ''})`, r.acoustic.reason);
  if (r.acoustic.model) {
    const top = (r.acoustic.model.top ?? []).map((t) => `${t.emotion} ${Math.round(t.confidence * 100)}%`).join(' / ');
    console.log('模型前三', top, `| 训练 LOSO ${Math.round((r.acoustic.model.loso ?? 0) * 100)}%`);
  } else {
    console.log('模型前三', '（model.json 还没生成，只有档位判断）');
  }
  console.log('档位    ', JSON.stringify(r.acoustic.bands?.numbers ?? {}));
  console.log('文本情绪', r.text ? `${r.text.emotion}（命中「${r.text.matched}」）` : '（没给文字）');
  console.log('特征    ', JSON.stringify(r.features));
  if (r.deviation) console.log('比平时  ', JSON.stringify(r.deviation));
  console.log('历史    ', JSON.stringify(r.history));
} catch (e) {
  console.error('失败：', e?.message ?? e);
  process.exit(2);
}
