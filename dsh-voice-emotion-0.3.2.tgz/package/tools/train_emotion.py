#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 TTS 合成参数当监督标签，训练声学情绪分类器。

数据：tmp/voice-emo-dataset/meta.json（13 情绪 × 5 句式 × 2 强度）
评估（三道）：
  1) 5 折分层交叉验证（同句子内部泛化）
  2) Leave-One-Sentence-Out（换句子还能不能认对——这一项才算数）
  3) C 网格 + 强正则（管理员 2026-11-07 要求）
产物：vendor/dsh-voice-emotion/model.json（纯 numpy 推理，不依赖 sklearn）
"""
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]          # vendor/dsh-voice-emotion
sys.path.insert(0, str(ROOT / 'python'))
from analyze import analyze  # noqa: E402

DATA = Path('C:/Users/pokra/ai_manager_workspace/tmp/voice-emo-dataset')

FEATURES = [
    'syllableRate', 'pauseRatio',
    'rmsDb', 'loudnessVarDb',
    'f0StdSt', 'f0RangeSt', 'f0EndSt',
    'jitterPct', 'shimmerPct', 'hnrDb',
]

C_GRID = [0.2, 0.3, 0.5, 1.0]

# 13 → 9 合并（声学上本来就接近的四类并成「低落」）
MERGE = {
    'neutral': 'neutral', 'happy': 'happy', 'surprised': 'surprised',
    'angry': 'angry', 'complaint': 'complaint', 'urgent': 'urgent',
    'anxious': 'anxious', 'firm': 'firm', 'soft': 'soft',
    'aggrieved': 'low', 'sad': 'low', 'tired': 'low', 'lazy': 'low',
}


def load():
    """优先扫目录（生成器还在跑也能训）：s<idx>/<emotion>_<int>.wav；没有目录再回落到 meta.json。"""
    rows = []
    dirs = sorted([d for d in DATA.glob('s*') if d.is_dir()])
    if dirs:
        for d in dirs:
            si = int(d.name[1:])
            for w in sorted(d.glob('*.wav')):
                emo = w.stem.rsplit('_', 1)[0]
                f = analyze(str(w))
                if not f.get('ok'):
                    continue
                rows.append({'sentence': si, 'text': '', 'emotion': emo, 'intensity': 0.5, 'file': str(w), 'feats': f})
        return rows
    meta = json.loads((DATA / 'meta.json').read_text(encoding='utf-8'))
    for m in meta:
        if not Path(m['file']).exists():
            continue
        f = analyze(m['file'])
        if not f.get('ok'):
            continue
        rows.append({**m, 'feats': f})
    return rows


def matrix(rows, merge=False):
    X, y, g = [], [], []
    for r in rows:
        X.append([float(r['feats'].get(k) or 0) for k in FEATURES])
        y.append(MERGE[r['emotion']] if merge else r['emotion'])
        g.append(r['sentence'])
    return np.asarray(X, float), np.asarray(y), np.asarray(g)


def _model(C):
    from sklearn.linear_model import LogisticRegression
    return LogisticRegression(max_iter=5000, C=C, class_weight='balanced', solver='lbfgs')


def loso(X, y, g, C=0.1):
    from sklearn.preprocessing import StandardScaler
    pred = np.empty(len(y), dtype=object)
    for s in sorted(set(g)):
        tr, te = g != s, g == s
        if not tr.any() or not te.any():
            continue
        sc = StandardScaler().fit(X[tr])
        clf = _model(C).fit(sc.transform(X[tr]), y[tr])
        pred[te] = clf.predict(sc.transform(X[te]))
    from sklearn.metrics import accuracy_score
    return accuracy_score(y, pred)


def kfold(X, y, C=0.1, k=5):
    from collections import Counter
    from sklearn.model_selection import StratifiedKFold, cross_val_score
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    k = max(2, min(k, min(Counter(y).values())))
    pipe = make_pipeline(StandardScaler(), _model(C))
    cv = StratifiedKFold(n_splits=k, shuffle=True, random_state=7)
    return float(cross_val_score(pipe, X, y, cv=cv).mean())


def fit_full(X, y, C):
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler().fit(X)
    clf = LogisticRegression(max_iter=5000, C=C, class_weight='balanced', solver='lbfgs').fit(sc.transform(X), y)
    return sc, clf


def main():
    rows = load()
    print(f'样本 {len(rows)} 条，句子 {len(set(r["sentence"] for r in rows))} 句，特征 {len(FEATURES)} 维')
    if not rows:
        print('没有样本，先跑 tmp/gen-emotion-dataset.mjs')
        return

    for merge in (False, True):
        X, y, g = matrix(rows, merge=merge)
        tag = '9类' if merge else '13类'
        kf = kfold(X, y, C=0.1)
        print(f'\n[{tag}] 5 折 CV {kf:.3f}')
        best = (None, -1)
        for C in C_GRID:
            a = loso(X, y, g, C=C)
            print(f'   C={C:<5} LOSO {a:.3f}')
            if a > best[1]:
                best = (C, a)
        print(f'   → 最佳 C={best[0]}，LOSO {best[1]:.3f}')

    # 正式模型：13 类、强正则、用 LOSO 选出的 C
    X, y, g = matrix(rows, merge=False)
    C, acc = 0.1, 0.0
    for c in C_GRID:
        a = loso(X, y, g, C=c)
        if a > acc:
            C, acc = c, a
    sc, clf = fit_full(X, y, C)
    train_acc = float((clf.predict(sc.transform(X)) == y).mean())
    from sklearn.metrics import confusion_matrix
    pred = np.empty(len(y), dtype=object)
    from sklearn.preprocessing import StandardScaler
    for s in sorted(set(g)):
        tr, te = g != s, g == s
        sc2 = StandardScaler().fit(X[tr])
        clf2 = _model(C).fit(sc2.transform(X[tr]), y[tr])
        pred[te] = clf2.predict(sc2.transform(X[te]))
    cm = confusion_matrix(y, pred, labels=sorted(set(y)))
    classes = sorted(set(y))
    per_class = {c: round(float(cm[i, i] / max(1, cm[i].sum())), 2) for i, c in enumerate(classes)}
    print(f'\n训练 acc {train_acc:.3f}  vs  LOSO {acc:.3f}（差 {train_acc - acc:+.3f} = 过拟合程度）')
    print('最差五类:', ', '.join(f'{k} {v:.2f}' for k, v in sorted(per_class.items(), key=lambda kv: kv[1])[:5]))

    model = {
        'version': 1,
        'trainedAt': np.datetime64('now', 's').astype(str) + 'Z',
        'features': FEATURES,
        'classes': [str(c) for c in clf.classes_],
        'mean': sc.mean_.astype(float).tolist(),
        'scale': sc.scale_.astype(float).tolist(),
        'coef': clf.coef_.astype(float).tolist(),
        'intercept': clf.intercept_.astype(float).tolist(),
        'C': C,
        'trainAccuracy': round(train_acc, 4),
        'loso': {'accuracy': round(float(acc), 4), 'perClass': per_class, 'samples': int(len(y))},
        'note': 'TTS 合成语料训练；真人/B站音频外测见外测报告。置信度 <0.45 时只报档位。',
    }
    out = ROOT / 'model.json'
    out.write_text(json.dumps(model, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    print(f'已写 {out}')


if __name__ == '__main__':
    main()
