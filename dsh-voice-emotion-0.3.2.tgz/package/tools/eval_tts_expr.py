﻿"""量她自己 TTS 13 种情绪的表达区分度。

1) 用 emotion2vec_plus_large 自带的 9 类头，看她每条合成语音被判成什么（认不认得出她想要的语气）
2) 用 1024 维 embedding 算「同一情绪内部紧不紧、不同情绪之间离多远」（silhouette）

用法：python eval_tts_expr.py --glob "tmp/voice-emo-dataset/**/*.wav" --out tmp/tts-expr.json
"""
import argparse
import glob
import json
import os
import re
from collections import Counter, defaultdict

import numpy as np

SNAP = r"C:\Users\pokra\.dsh-voice-emo2vec\models\models\iic--emotion2vec_plus_large\snapshots\master"

CANON = {
    "生气/angry": "angry", "生气/愤怒": "angry", "开心/happy": "happy", "开心/高兴": "happy", "难过/sad": "sad", "难过/悲伤": "sad", "恐惧/fearful": "fear", "恐惧": "fear",
    "厌恶/disgusted": "disgust", "厌恶": "disgust", "吃惊/surprised": "surprised", "惊讶": "surprised", "<unk>": "unknown", "其他/other": "other", "其他": "other",
    "中立/neutral": "neutral", "中立": "neutral", "中性": "neutral",
}


def load_model():
    from funasr import AutoModel
    return AutoModel(model="iic/emotion2vec_plus_large", model_path=SNAP, disable_update=True, device="cpu")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", default="tmp/voice-emo-dataset/**/*.wav")
    ap.add_argument("--out", default="tmp/tts-expr.json")
    ap.add_argument("--limit-per-class", type=int, default=12)
    a = ap.parse_args()

    files = sorted(glob.glob(a.glob, recursive=True))
    items = []
    for f in files:
        base = os.path.basename(f)
        emo = base.rsplit("_", 1)[0]
        items.append((f, emo))
    by = defaultdict(list)
    for f, e in items:
        by[e].append(f)
    picked = []
    for e, fs in by.items():
        picked += [(f, e) for f in fs[: a.limit_per_class]]
    print(f"[info] {len(files)} files, {len(picked)} picked, {len(by)} classes", flush=True)

    m = load_model()
    X, y, pred = [], [], []
    for i, (f, e) in enumerate(picked, 1):
        r = m.generate(f, granularity="utterance", extract_embedding=True)
        r = r[0]
        emb = np.asarray(r.get("feats", r.get("feat")), dtype=np.float32).ravel()
        lab = r.get("labels") or []
        score = r.get("scores") or []
        top = lab[int(np.argmax(score))] if len(lab) else "?"
        top = CANON.get(top, top)
        X.append(emb)
        y.append(e)
        pred.append((top, float(max(score)) if len(score) else 0.0))
        if i % 20 == 0:
            print(f"[{i}/{len(picked)}]", flush=True)

    X = np.vstack(X)
    # 每类 embedding 均值
    cent = {}
    for e in sorted(set(y)):
        cent[e] = X[[i for i, v in enumerate(y) if v == e]].mean(axis=0)
    names = list(cent)
    d = np.zeros((len(names), len(names)))
    for i, ni in enumerate(names):
        for j, nj in enumerate(names):
            c1, c2 = cent[ni], cent[nj]
            d[i, j] = 1 - float(c1 @ c2 / (np.linalg.norm(c1) * np.linalg.norm(c2) + 1e-8))
    np.fill_diagonal(d, np.nan)
    nearest = {names[i]: names[int(np.nanargmin(d[i]))] for i in range(len(names))}

    # 用 9 类头的标签看「她想要的情绪」被判成什么
    hit = sum(1 for (p, _), e in zip(pred, y) if p == e)
    conf = defaultdict(Counter)
    for (p, s), e in zip(pred, y):
        conf[e][p] += 1

    out = {
        "files": len(files),
        "picked": len(picked),
        "classes": len(by),
        "labelAccuracy9": round(hit / max(1, len(y)), 3),
        "perEmotion": {
            e: {
                "n": len([1 for v in y if v == e]),
                "topPred": conf[e].most_common(3),
                "nearestCentroid": nearest.get(e),
                "meanScore": round(float(np.mean([s for (p, s), t in zip(pred, y) if t == e])), 3),
            }
            for e in names
        },
        "centroidDistance": {
            names[i]: {names[j]: round(float(d[i, j]), 3) for j in range(len(names)) if i != j}
            for i in range(len(names))
        },
    }
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(json.dumps({k: out[k] for k in ("files", "picked", "classes", "labelAccuracy9")}, ensure_ascii=False))
    for e in names:
        print(f"  {e:12s} n={out['perEmotion'][e]['n']:3d} -> {out['perEmotion'][e]['topPred']} 近邻={nearest[e]}")


if __name__ == "__main__":
    main()


