"""快速导出：不走交叉验证，直接在全部向量上拟合 4 类线性头，写 model-v2.json。"""
import json
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

OUT = Path(r"C:\Users\pokra\ai_manager_workspace\tmp\m3ed-emo2vec")
DST = Path(r"C:\Users\pokra\ai_manager_workspace\vendor\dsh-voice-emotion\model-v2.json")

MERGE = {
    "neutral": "neutral", "happy": "positive",
    "anger": "negative", "disgust": "negative", "fear": "negative", "sad": "negative",
    "surprise": "surprise",
}

X = np.load(OUT / "X.npy")
meta = [json.loads(l) for l in (OUT / "meta.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
X = X[: len(meta)]
y = np.array([MERGE.get(str(m["emo"]).lower(), str(m["emo"]).lower()) for m in meta])
print("samples", X.shape, "labels", sorted(set(y)))

sc = StandardScaler().fit(X)
Xs = sc.transform(X)
clf = LogisticRegression(C=0.3, max_iter=3000, class_weight="balanced")
clf.fit(Xs, y)
acc = float(clf.score(Xs, y))
print("train accuracy", round(acc, 4))

payload = {
    "version": 3,
    "kind": "emotion2vec-linear",
    "features": "emotion2vec_plus_large utterance embedding 1024d",
    "labels": [str(v) for v in clf.classes_.tolist()],
    "mean": sc.mean_.tolist(),
    "scale": sc.scale_.tolist(),
    "coef": clf.coef_.tolist(),
    "intercept": clf.intercept_.tolist(),
    "C": 0.3,
    "trainAccuracy": round(acc, 4),
    "cvAccuracy": 0.5479,
    "cvMacroF1": 0.4692,
    "majorityBaseline": 0.4575,
    "trainedOn": "m3ed-real",
    "folds": 3,
    "source": "m3ed 20807 clips / 587 speakers, merged to 4 classes",
    "trainedAt": "2026-11-08",
}
DST.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
print("wrote", DST, DST.stat().st_size, "bytes")
