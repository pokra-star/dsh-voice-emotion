#!/usr/bin/env python
"""Train a 7-class emotion head on M3ED (Chinese TV dialogue) with emotion2vec embeddings.

Stage 1 (--stage embed): turn every wav in the manifest into a 1024-d utterance vector.
Stage 2 (--stage train): speaker-disjoint CV + logistic regression, write metrics.

Progress is written to --progress JSON after every batch so a reporter can read it.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

MODEL_DIR = r"C:\Users\pokra\.dsh-voice-emo2vec\models\models\iic--emotion2vec_plus_large\snapshots\master"
VENV = r"C:\Users\pokra\.dsh-voice-emo2vec\venv"

EMO_CN = {
    "Neutral": "neutral",
    "Happy": "happy",
    "Sad": "sad",
    "Anger": "angry",
    "Surprise": "surprised",
    "Fear": "anxious",
    "Disgust": "complaint",
}


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def write_progress(path, obj):
    if not path:
        return
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)


def load_model(device):
    from funasr import AutoModel

    model = AutoModel(
        model="iic/emotion2vec_plus_large",
        model_path=MODEL_DIR,
        device=device,
        disable_update=True,
        disable_pbar=True,
        log_level="ERROR",
    )
    return model


def embed(model, wav):
    out = model.generate(
        wav,
        granularity="utterance",
        extract_embedding=True,
        disable_pbar=True,
    )
    if isinstance(out, list):
        out = out[0]
    emb = out.get("feats") if isinstance(out, dict) else None
    if emb is None and isinstance(out, dict):
        emb = out.get("embedding")
    if emb is None:
        raise RuntimeError(f"no embedding for {wav}: {list(out)[:6] if isinstance(out, dict) else type(out)}")
    return np.asarray(emb, dtype=np.float32).reshape(-1)


def stage_embed(rows, out_dir, limit, device, progress):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    x_path = out_dir / "X.npy"
    meta_path = out_dir / "meta.jsonl"

    done = 0
    embs = []
    kept = []
    if x_path.exists() and meta_path.exists():
        old = np.load(x_path)
        kept = [json.loads(l) for l in meta_path.read_text(encoding="utf-8").splitlines() if l.strip()]
        if len(old) == len(kept):
            embs = [r for r in old]
            done = len(kept)
            log(f"resume: {done} vectors already on disk")

    model = load_model(device)
    log("emotion2vec loaded")

    todo = rows[done : (limit if limit else len(rows))]
    t0 = time.time()
    MIN_DUR = 0.3
    for i, r in enumerate(todo):
        try:
            import soundfile as _sf
            if _sf.info(r["f"]).duration < MIN_DUR:
                log(f"skip short {r['f']}")
                continue
            v = embed(model, r["f"])
        except Exception as e:  # noqa: BLE001
            log(f"skip {r['f']}: {e}")
            continue
        embs.append(v)
        kept.append(r)
        if (i + 1) % 50 == 0 or i + 1 == len(todo):
            np.save(x_path, np.stack(embs))
            with open(meta_path, "w", encoding="utf-8") as f:
                for k in kept:
                    f.write(json.dumps(k, ensure_ascii=False) + "\n")
            rate = (i + 1) / max(1e-6, time.time() - t0)
            eta = (len(todo) - i - 1) / rate if rate else 0
            write_progress(
                progress,
                {
                    "stage": "embed",
                    "done": len(kept),
                    "total": len(rows),
                    "rate_per_s": round(rate, 2),
                    "eta_min": round(eta / 60, 1),
                    "elapsed_min": round((time.time() - t0) / 60, 1),
                    "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
                },
            )
            log(f"{len(kept)}/{len(rows)}  {rate:.2f}/s  eta {eta/60:.0f}min")

    return np.stack(embs), kept


def stage_train(out_dir, progress, frac=1.0, metrics_name="metrics.json", head="linear", folds=5, c_list="0.1,0.3,1.0,3.0", merge=0, export=None):
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
    from sklearn.model_selection import GroupKFold
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    out_dir = Path(out_dir)
    X = np.load(out_dir / "X.npy")
    meta = [json.loads(l) for l in (out_dir / "meta.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    X = X[: len(meta)]
    if frac < 1.0:
        # 按说话人分层抽样：每个说话人按等距取样，保证各说话人时长/剧集分布均匀
        keep = []
        by_spk = {}
        for i, m in enumerate(meta):
            by_spk.setdefault(m["spk"], []).append(i)
        for spk, idxs in by_spk.items():
            k = max(1, int(round(len(idxs) * frac)))
            picks = np.linspace(0, len(idxs) - 1, k).round().astype(int)
            keep.extend(idxs[j] for j in sorted(set(picks.tolist())))
        keep.sort()
        X = X[keep]
        meta = [meta[i] for i in keep]
        log(f"frac={frac} -> {len(meta)} clips")
    y = np.array([m["emo"] for m in meta])
    groups = np.array([m["spk"] for m in meta])
    log(f"train on {len(y)} clips, {len(set(groups))} speakers, {len(set(y))} labels")

    if merge:
        MERGE_SETS = {
            4: {"neutral": "neutral", "happy": "positive", "anger": "negative",
                "disgust": "negative", "fear": "negative", "sad": "negative",
                "surprise": "surprise"},
            5: {"neutral": "neutral", "happy": "positive", "anger": "angry",
                "disgust": "angry", "fear": "sad", "sad": "sad", "surprise": "surprise"},
        }
        _m = MERGE_SETS.get(int(merge))
        if not _m:
            raise SystemExit("--merge must be 4 or 5")
        _before = sorted(set(y))
        y = np.array([_m.get(str(v).lower(), str(v).lower()) for v in y])
        log(f"merge={merge} -> {len(set(y))} labels, from {_before}")
    labels = sorted(set(y))
    gkf = GroupKFold(n_splits=max(2, int(folds)))
    best = None
    grid = tuple(float(x) for x in str(c_list).split(",") if x.strip()) if head == "linear" else (0.0,)
    for C in grid:
        accs, macro = [], []
        all_true, all_pred = [], []
        for tr, te in gkf.split(X, y, groups):
            if head == "mlp":
                from sklearn.neural_network import MLPClassifier
                clf = make_pipeline(
                    StandardScaler(),
                    MLPClassifier(hidden_layer_sizes=(512,), alpha=1e-4, batch_size=256,
                                  learning_rate_init=1e-3, max_iter=200, early_stopping=False,
                                  random_state=0),
                )
            else:
                clf = make_pipeline(
                    StandardScaler(),
                    LogisticRegression(C=C, max_iter=2000, class_weight="balanced", n_jobs=-1),
                )
            clf.fit(X[tr], y[tr])
            pred = clf.predict(X[te])
            accs.append(accuracy_score(y[te], pred))
            macro.append(f1_score(y[te], pred, average="macro"))
            all_true.extend(y[te])
            all_pred.extend(pred)
        cm = confusion_matrix(all_true, all_pred, labels=labels)
        row = {
            "head": head,
            "C": (C if head == "linear" else None),
            "acc": round(float(np.mean(accs)), 4),
            "acc_std": round(float(np.std(accs)), 4),
            "macro_f1": round(float(np.mean(macro)), 4),
            "confusion": cm.tolist(),
            "labels": labels,
        }
        log(f"C={C}  acc={row['acc']}  macroF1={row['macro_f1']}")
        if best is None or row["acc"] > best["acc"]:
            best = row
        write_progress(progress, {"stage": "train", "last_C": C, **{k: row[k] for k in ("acc", "macro_f1")}})

    baseline = max(np.bincount([labels.index(v) for v in y])) / len(y)
    best["majority_baseline"] = round(float(baseline), 4)
    best["by_class"] = {
        lab: {"support": int((y == lab).sum())} for lab in labels
    }
    (out_dir / metrics_name).write_text(json.dumps(best, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"BEST {json.dumps({k: best[k] for k in ('C', 'acc', 'macro_f1', 'majority_baseline')}, ensure_ascii=False)}")
    write_progress(progress, {"stage": "done", "best": {k: best[k] for k in ("C", "acc", "macro_f1", "majority_baseline")}})
    best["folds"] = int(folds)
    if export and head == "linear":
        export_full(out_dir, y, X, labels, best, export)
    elif export and head == "mlp":
        log("mlp head: 不导出 numpy 参数（linear 才用于线上推理）")


def export_full(out_dir, y, X, labels, best, path_out):
    """在全部数据上重训最终模型并导出 numpy 推理参数（给 serve_v2.py 用）。"""
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler().fit(X)
    Xs = scaler.transform(X)
    C = float(best.get("C") or 0.3)
    clf = LogisticRegression(C=C, max_iter=3000, class_weight="balanced")
    clf.fit(Xs, y)
    payload = {
        "version": 3,
        "kind": "emotion2vec-linear",
        "features": "emotion2vec_plus_large utterance embedding 1024d",
        "labels": [str(v) for v in clf.classes_.tolist()],
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "coef": clf.coef_.tolist(),
        "intercept": clf.intercept_.tolist(),
        "C": C,
        "trainAccuracy": round(float(clf.score(Xs, y)), 4),
        "cvAccuracy": best.get("acc"),
        "cvMacroF1": best.get("macro_f1"),
        "majorityBaseline": best.get("majority_baseline"),
        "trainedOn": "m3ed-real",
        "folds": best.get("folds"),
        "trainedAt": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
    }
    Path(path_out).write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    log(f"EXPORT {path_out} labels={payload['labels']} trainAcc={payload['trainAccuracy']}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=r"C:\Users\pokra\ai_manager_workspace\tmp\m3ed-manifest.json")
    ap.add_argument("--out-dir", default=r"C:\Users\pokra\ai_manager_workspace\tmp\m3ed-emo2vec")
    ap.add_argument("--stage", default="all", choices=["embed", "train", "all"])
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--progress", default=r"C:\Users\pokra\ai_manager_workspace\tmp\voice-emo-progress.json")
    ap.add_argument("--frac", type=float, default=1.0)
    ap.add_argument("--metrics", default="metrics.json")
    ap.add_argument("--head", default="linear", choices=["linear", "mlp"])
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--c-list", default="0.1,0.3,1.0,3.0")
    ap.add_argument("--merge", type=int, default=0, choices=[0, 4, 5])
    ap.add_argument("--export", default="")
    args = ap.parse_args()

    try:
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x4000)  # BELOW_NORMAL
    except Exception:
        pass

    rows = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    if args.limit:
        rows = rows[: args.limit]

    if args.stage in ("embed", "all"):
        stage_embed(rows, args.out_dir, args.limit, args.device, args.progress)
    if args.stage in ("train", "all"):
        stage_train(args.out_dir, args.progress, args.frac, args.metrics, args.head, args.folds, args.c_list, args.merge, (args.export or None))


if __name__ == "__main__":
    main()
