/**
 * 校准：把 tmp/voice-emo 下 13 个情绪的样本测一遍，生成 profiles.json。
 *
 * 这份表现在用来做「冷启动参照」——还没攒够某个人自己的历史时，先拿它当中位参照。
 * 真正判情绪靠档位组合（lib/emotion.mjs 的 classifyAcoustic），不靠 13 分类。
 *
 * 用法：node tools/calibrate.mjs [样本目录]
 * 样本命名：<情绪>.wav
 */
import { readdirSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { analyzeFile, EMOTIONS } from '../lib/emotion.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = dirname(HERE);
const dir = process.argv[2] || 'C:/Users/pokra/ai_manager_workspace/tmp/voice-emo';
if (!existsSync(dir)) {
  console.error('样本目录不存在：' + dir);
  process.exit(1);
}

const samples = {};
for (const f of readdirSync(dir)) {
  const m = /^([a-z]+)\.wav$/i.exec(f);
  if (!m) continue;
  const emo = m[1].toLowerCase();
  if (EMOTIONS.includes(emo)) samples[emo] = join(dir, f);
}
const missing = EMOTIONS.filter((e) => !samples[e]);
if (missing.length) {
  console.error('缺样本：' + missing.join(', '));
  process.exit(2);
}

const features = {};
for (const emo of EMOTIONS) {
  const f = analyzeFile(samples[emo]);
  features[emo] = f;
  console.log(emo.padEnd(10), 'syll', f.syllableRate, 'f0', f.f0Median, 'rms', f.rmsDb, 'pause', f.pauseRatio, 'f0end', f.f0EndSt);
}

const agg = (k) => {
  const vals = EMOTIONS.map((e) => Number(features[e][k])).filter((x) => Number.isFinite(x)).sort((a, b) => a - b);
  return vals.length ? Math.round(vals[Math.floor(vals.length / 2)] * 1000) / 1000 : 0;
};

const pickFields = ['speechRate', 'syllableRate', 'f0Median', 'rmsDb', 'pauseRatio', 'pauseMean', 'loudnessVarDb', 'f0StdSt', 'f0EndSt', 'tilt'];
const aggregateRef = Object.fromEntries(pickFields.map((k) => [k, agg(k)]));

const out = {
  version: 2,
  calibratedAt: new Date().toISOString(),
  samples: Object.fromEntries(EMOTIONS.map((e) => [e, samples[e]])),
  aggregateRef,
  emotions: Object.fromEntries(EMOTIONS.map((e) => [e, {
    features: Object.fromEntries(pickFields.map((k) => [k, features[e][k]])),
  }])),
};

const target = join(PKG_ROOT, 'profiles.json');
writeFileSync(target, JSON.stringify(out, null, 2) + '\n', 'utf8');
console.log('\n写入', target);
console.log('aggregateRef', JSON.stringify(aggregateRef));
