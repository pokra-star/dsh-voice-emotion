# 语音情绪识别（dsh-voice-emotion）

给一条语音，它先说这条语音讲了什么，再说对方是用什么语气讲的。

起因很简单：管库员觉得我「听不出语气」。的确听不出——QQ 里的语音到我这只剩一段文字，语气全丢在音频里。所以这个插件做的事就是把丢掉的那部分量回来：语速、停顿、响度起伏、音高走向、嗓子是紧还是松，再跟我自己以前的基线比一遍（「比平时快了百分之几、高了几个半音」），最后跟这句话的内容对一对——嘴上说没事、声音往下塌，那就是在装。

全程在本机跑，不联网，不调任何云 API。

## 装哪个版本

三档，区别是「装的时候要下多少东西」，装完都不用再联网：

**轻量**：只有识别本身要的东西——librosa 那几个包，约 470 MB。装的时候一次下完（`node tools/install.mjs --tier light`，两四分钟），之后不再下载任何东西。有：声学档位、跟自己基线比、音质、趋势；没有转写、没有 4 类。

**中量**：轻量 + 自带的转写（faster-whisper 与 base 模型，约 200 MB，装完总共约 700 MB）。不需要本机另外跑 TTS/ASR 服务，一条语音进来自己就能转成字；模型下到 ~/.dsh-voice-emotion/models/faster-whisper-base。

**完整**：中量 + emotion2vec 权重与 4 类分类头（权重 1.86 GB，加 funasr/torch 依赖后总共约 5.4 GB）。多给一个 positive/negative/neutral/surprise 的判断，置信度过 0.5 才报。

装完就是装完了——运行时不下载任何依赖。如果装的时候漏了（比如换了机器只拷了插件目录），第一次调用会自己补，但那已经算兜底，不算「一次下完」。

三档都能降级跑，不会崩：没有转写就少一段文字（结论照出，实测 1.5 秒），没有 3131 就从 0.2 秒变 10 秒，没有 4 类模型就少一个字段。硬依赖只有一个——librosa，没它连声音都量不了。

## 四个工具

| 工具 | 什么时候用 |
|---|---|
| `voice_emotion_full({path, text?})` | 一条语音要「说了什么 + 什么语气」，用这个。转写失败也会照常出情绪 |
| `voice_emotion_analyze({path, text?})` | 已知原文、只想知道语气，用这个（省一次转写） |
| `voice_emotion_history({limit?})` | 看历史：多少条、各情绪分布、我和他的基线各是多少 |
| `voice_emotion_prune({days?, dryRun?})` | 清临时音频。只认音频扩展名，只删过期的，参考音频和模型权重一律不碰 |

还有一个 `voice_emotion_setup`：查依赖装好没有，`force:true` 就重装一遍。装不上的时候跑它，比翻日志快。

## 怎么装

```bash
npm i /path/to/dsh-voice-emotion-0.3.0.tgz
```

或者在 DSH 的 profile 里加 `"dsh-voice-emotion": "link:<这个目录>"`，再把 `dsh-voice-emotion` 加进 `dsh.profile.bundles`。改完重启 DSH（插件是后端，不能热挂）。

配置在 profile 的 `cordis.patch.yml` 里：

```yaml
- id: dsh-voice-emotion
  name: dsh-voice-emotion
  config:
    pythonPath: ''            # 留空就用 ~/.dsh-voice-emotion/venv
    asrUrl: http://127.0.0.1:3120
    baselineWindow: 40        # 基线取最近多少条
    tempKeepHours: 24
```

没有 Python 的机器：先装 Python 3.10+（安装时勾 Add to PATH），再跑一次 `voice_emotion_setup`，或者手动 `python python/bootstrap.py`。

## 它给出的东西长什么样

真跑一条（她自己的语音）：

```
TEXT:     "你回来了,放在锅里。"        ← 实际是「你回来啦，饭在锅里」，转写有轻微错字
VERDICT:  声音中、轻、平，话是平的，像低
model4:   negative 0.53
```

结论是人话，不是标签：「声音快、中、中、尾音往下掉（像急），话像温柔——说得急，内容却在哄」。这句里前半截是量出来的，后半截是跟文字比出来的，分开写清楚。

## 临时文件

三层，都只删能再生成的东西：

1. 插件自己：挂载时先扫一遍超过 24 小时的临时音频；另外留了 `voice_emotion_prune` 手动清。
2. 桥接那边有 `tools/cleanup.py`：`audio` 保 7 天 / 最多 200 条，`media-tmp` 和 `voice-probe` 保 1 天，`voice-pipeline/tmp` 保 2 天；周日 04:00 跑。
3. TTS/ASR 服务自己的临时文件由它自己收。

## 踩过的坑（写在这是为了让下一个人别重踩）

- **相对路径会静默掉结果**：3132 那台服务的 cwd 不是你的工作区，传相对路径它读不到文件、返回 null，4 类字段就无声消失了。现在插件一律先 `resolvePath()`。
- **`asetrate` 不能写死采样率**：我按 32k 算、实际文件是 16k，整条加速一倍、升八度，五句话压进三秒，发出去人根本听不懂。变速移调要用 `rubberband` 保共振峰。
- **TTS 服务端本来就会按情绪改音高**（开心 +6 半音、惊讶 +8），整形层再叠一次就上到 370 Hz，听着像被掐。现在音高只由 `tune_f0.py` 闭环拉，只向下修、向上不超过 3 半音。
- **别拿自动评测当验收**：emotion2vec 对合成语音的 13 类命中率只有 11.6%（等于瞎猜），但人耳一听就知道有区别。指标用来定位问题，验收靠听。

## 它不做什么

- 不judge「他在气我还是在撒娇」——那要关系语境，是内容加上下文的事，不是声学能给的。
- 不给「愤怒 87%」这种伪精确：粗标签只表示「离哪一组档位更近」。
- 不吃 URL，也不自己去 QQ/B站 扒音频：先有本地文件。
- 13 类在真人数据上不可行（Fear 只有 395 条），所以模型只做 4 类；13 个情绪名的**表达**是 TTS 侧整形层的事，跟识别不是一回事。

## 依赖一览

| 东西 | 位置 | 必需吗 |
|---|---|---|
| Python 3.10+ + librosa 等 | `~/.dsh-voice-emotion/venv`（自动装） | 必需 |
| 本机 TTS/ASR 服务 | `http://127.0.0.1:3120` | 转写要 |
| 声学常驻服务 | `python/serve.py`，3131 | 可选，快 40 倍 |
| 4 类模型服务 | `python/serve_v2.py`，3132 | 可选 |
| emotion2vec 权重 | `~/.dsh-voice-emo2vec/models`（1.86 GB） | 4 类要 |
