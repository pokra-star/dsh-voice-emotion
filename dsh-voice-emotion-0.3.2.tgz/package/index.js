/**
 * dsh-voice-emotion —— 语音情绪识别（转写 + 声学 + 内容融合 + 跟历史比）。
 *
 * 完整链路：一条语音进来 → ①转写（复用本机 ASR 服务，3120 的 /asr）②量声学
 * （语速/起音密度、响度与起伏、停顿占比、基频高低与离散、音质抖动/沙哑）
 * ③按「这个说话人自己的基线」给档位 ④跟文字情绪比对 ⑤（可选）4 类 emo2vec 模型。
 *
 * 工具：
 *   voice_emotion_full(path, text?, targetEmotion?, save?)  转写 + 情绪，一条龙的入口
 *   voice_emotion_analyze(path, text?, targetEmotion?, save?)  只做情绪（不转写）
 *   voice_emotion_history(limit?)  历史与基线
 *   voice_emotion_prune(days?, dryRun?, paths?)  清理临时音频
 */
import { join, resolve as resolvePath } from 'node:path';
import { existsSync } from 'node:fs';
import { execFile } from 'node:child_process';
import { homedir } from 'node:os';

export const name = 'dsh-voice-emotion';
export const inject = ['tools'];
export const version = '0.3.2';

let z = null;
try {
  const m = await import('@deepseek-ai/schemastery');
  z = m.default ?? m;
} catch { /* 没有 schemastery 就用默认值 */ }

let defineTool = null;
try {
  const m = await import('@deepseek-ai/dsh-tools');
  defineTool = m.defineTool;
} catch { /* 兜底 */ }

function localDefineTool(options) {
  const properties = {};
  const required = [];
  for (const [key, def] of Object.entries(options.parameters ?? {})) {
    const node = { type: def.type, description: def.description };
    if (def.type === 'array') node.items = def.items;
    if (def.enum !== undefined) node.enum = def.enum;
    if (def.default !== undefined) node.default = def.default;
    properties[key] = node;
    if (def.required === true) required.push(key);
  }
  return {
    name: options.name,
    description: options.description,
    parameters: { type: 'object', properties, ...(required.length ? { required } : {}), additionalProperties: false },
    output: {
      schema: options.output?.schema ?? { type: 'object', additionalProperties: true },
      render: options.output?.render ?? ((_args, value) => [{
        type: 'text',
        text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
      }]),
    },
    async execute(args, exec) { return options.execute(args, exec); },
  };
}
const makeTool = defineTool ?? localDefineTool;

const TEXT_OUTPUT = {
  schema: { type: 'json' },
  render: (_args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }],
};

export const Config = !z ? undefined : z.object({
  pythonPath: z.string().default(''),
  baselineWindow: z.natural().default(40),
  asrUrl: z.string().default('http://127.0.0.1:3120'),
  asrTimeoutMs: z.natural().default(90000),
  tempKeepHours: z.natural().default(24),
  homeDir: z.string().default(''),
  pipMirror: z.string().default('https://pypi.tuna.tsinghua.edu.cn/simple'),
  autoProvision: z.boolean().default(true),
});

export function apply(ctx, config) {
  const cfg = config ?? {};
  const home = String(cfg.homeDir || '') || join(homedir(), '.dsh-voice-emotion');
  const venvDir = join(home, 'venv');
  const venvPython = join(venvDir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
  const pipMirror = String(cfg.pipMirror || 'https://pypi.tuna.tsinghua.edu.cn/simple');
  const autoProvision = cfg.autoProvision !== false;
  const configured = String(cfg.pythonPath ?? '');
  const pyPath = () => (configured && existsSync(configured) ? configured : venvPython);
  const baselineWindow = Math.max(3, Number(cfg.baselineWindow) || 40);
  const asrUrl = String(cfg.asrUrl ?? 'http://127.0.0.1:3120');
  const asrTimeoutMs = Math.max(5000, Number(cfg.asrTimeoutMs) || 90000);
  const tempKeepHours = Math.max(0.5, Number(cfg.tempKeepHours) || 24);

  let provisioning = null;   // Promise | null
  let lastProvision = null;  // { ok, python, error, at }

  function runBootstrap() {
    const script = resolvePath(join(import.meta.dirname ?? '.', 'python', 'bootstrap.py'));
    return new Promise((resolve) => {
      execFile(process.env.PYTHON || 'python', [script, '--dir', venvDir, '--mirror', pipMirror],
        { timeout: 15 * 60 * 1000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
        (error, stdout, stderr) => {
          const out = String(stdout || '');
          const py = out.trim().split(/\r?\n/).filter((l) => /python(\.exe)?$/i.test(l.trim())).pop() || '';
          const ok = !error && existsSync(venvPython);
          lastProvision = { ok, python: py || venvPython, error: error ? String(stderr || error.message).slice(-400) : '', at: Date.now() };
          resolve(lastProvision);
        });
    });
  }

  /** 拿到可用的解释器；缺依赖且允许自动装就装一次（并发调用共享同一个 Promise）。 */
  async function ensurePython() {
    const p = pyPath();
    if (existsSync(p)) return p;
    if (!autoProvision) {
      throw new Error(`没找到 Python 环境：${p}。可以设 config.pythonPath，或跑 python python/bootstrap.py 自动装。`);
    }
    provisioning = provisioning || runBootstrap();
    const r = await provisioning;
    provisioning = null;
    if (r.ok && existsSync(venvPython)) return venvPython;
    throw new Error(`自动准备 Python 依赖失败：${r.error || '未知原因'}。可手动跑 python python/bootstrap.py 重试。`);
  }

  async function analyzeOne({ path, text, targetEmotion, save }) {
    const { analyze, predictV2Model } = await import('./lib/emotion.mjs');
    const file = resolvePath(String(path));
    const python = await ensurePython();
    const r = analyze({ file, text: text ?? '', target: targetEmotion ?? '', save, config: { pythonPath: python, baselineWindow } });
    const model4 = await predictV2Model(file);
    if (model4) r.model4 = model4;
    return r;
  }

  const fullTool = makeTool({
    name: 'voice_emotion_full',
    description: '一条语音的完整链路：先转写成文字（本机 ASR 服务），再量声学情绪，再跟文字情绪比对，最后可选叠 4 类声学模型。'
      + '适合「这句话说了什么、说的时候是什么语气」一起要的场合。只吃本地文件路径，不吃 URL。',
    parameters: {
      path: { type: 'string', required: true, description: '本地音频文件绝对路径（wav/mp3/m4a/amr/ogg）' },
      text: { type: 'string', description: '已知原文时传进来，可跳过转写（转写失败也有兜底）' },
      targetEmotion: { type: 'string', description: '可选：这条语音本来是按什么情绪合成的，用来核对' },
      save: { type: 'boolean', default: true, description: '是否写进历史基线（默认 true）' },
    },
    output: TEXT_OUTPUT,
    async execute({ path, text, targetEmotion, save = true }) {
      const { transcribeFile } = await import('./lib/asr.mjs');
      let transcript = String(text ?? '').trim();
      let asr = { ok: Boolean(transcript), skipped: Boolean(transcript) };
      if (!transcript) {
        const t = await transcribeFile(path, { url: asrUrl, timeoutMs: asrTimeoutMs, pythonPath: pyPath(), homeDir: home });
        asr = t.ok ? { ok: true, text: t.text } : { ok: false, error: t.error };
        transcript = t.ok ? t.text : '';
      }
      try {
        const r = await analyzeOne({ path, text: transcript, targetEmotion, save });
        return { content: [{ type: 'text', text: JSON.stringify({ ...r, asr: { ...asr, text: transcript } }, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `分析失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  ctx.tools.register(fullTool);

  const analyzeTool = makeTool({
    name: 'voice_emotion_analyze',
    description: '只做情绪（不转写）：量声学档位（语速/响度/起伏/停顿/音高/尾音走向）→ 相对这个说话人自己的基线给粗标签 → 跟内容文字比对 → 出结论；'
      + '还会跟历史比：快了/慢了百分之几、高/低几个半音、响/轻几 dB。粗标签是「像什么」不是概率。',
    parameters: {
      path: { type: 'string', required: true, description: '本地音频文件绝对路径' },
      text: { type: 'string', description: '这条语音说的是什么（原话或转写）。给了才能做「声音 vs 内容」的融合判断' },
      targetEmotion: { type: 'string', description: '可选：这条语音本来是按什么情绪合成的（如 happy/angry/soft），用来核对声学是否对得上' },
      save: { type: 'boolean', default: true, description: '是否把这次结果写进历史基线（默认 true；纯调试可以传 false）' },
    },
    output: TEXT_OUTPUT,
    async execute({ path, text, targetEmotion, save = true }) {
      try {
        const r = await analyzeOne({ path, text, targetEmotion, save });
        return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `情绪分析失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  ctx.tools.register(analyzeTool);

  const historyTool = makeTool({
    name: 'voice_emotion_history',
    description: '看语音情绪的历史：总共分析过多少条、各情绪分布、我自己和对方的基线（平时多快、多高、多响）、最近几条结论。',
    parameters: {
      limit: { type: 'number', default: 10, description: '最近几条，默认 10' },
    },
    output: TEXT_OUTPUT,
    async execute({ limit = 10 }) {
      try {
        const { historySummary } = await import('./lib/emotion.mjs');
        const r = historySummary({ limit: Math.max(1, Math.min(50, Number(limit) || 10)), config: { baselineWindow } });
        return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `读历史失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  ctx.tools.register(historyTool);

  const setupTool = makeTool({
    name: 'voice_emotion_setup',
    description: '准备/检查本插件的 Python 依赖（librosa 等）：没装过就在 ~/.dsh-voice-emotion/venv 里自动建 venv 并从国内镜像安装（约 470 MB，一次）。'
      + '返回解释器路径与当前状态；force=true 强制重装。',
    parameters: {
      force: { type: 'boolean', default: false, description: '强制重建（默认 false，已就绪就只报告）' },
    },
    output: TEXT_OUTPUT,
    async execute({ force = false }) {
      const p = pyPath();
      const ready = existsSync(p);
      if (!force && ready) {
        const { execFile } = await import('node:child_process');
        const version = await new Promise((resolve) => {
          execFile(p, ['-c', 'import librosa,sys;print(librosa.__version__)'], { timeout: 60000, windowsHide: true },
            (e, out) => resolve(e ? null : String(out).trim()));
        });
        return { content: [{ type: 'text', text: JSON.stringify({ ok: Boolean(version), python: p, librosa: version, venvDir, provisioned: false }, null, 2) }] };
      }
      const r = await (provisioning = provisioning || runBootstrap());
      provisioning = null;
      return { content: [{ type: 'text', text: JSON.stringify({ ...r, venvDir, python: venvPython }, null, 2) }] };
    },
  });
  ctx.tools.register(setupTool);

  // 挂载时若没有解释器，后台先准备一次（不阻塞启动）
  if (autoProvision && !existsSync(pyPath())) {
    console.log('[voice-emotion] 没有 Python 环境，后台开始准备（首次约 2~4 分钟）');
    provisioning = runBootstrap();
  }

  const pruneTool = makeTool({
    name: 'voice_emotion_prune',
    description: '清理语音链路的临时音频（插件自己的 tmp/cache、桥接的 media-tmp、voice-probe），只删音频类扩展名且超过保留期的文件；'
      + '不碰参考音频、模型权重、用户点名的文件。默认只看不删会更安全就传 dryRun=true。',
    parameters: {
      days: { type: 'number', default: 1, description: '保留多少天内的文件（默认 1 天，按小时小数也行）' },
      dryRun: { type: 'boolean', default: false, description: '只报告不删' },
      paths: { type: 'array', items: { type: 'string' }, description: '额外要扫的目录（可选）' },
    },
    output: TEXT_OUTPUT,
    async execute({ days = 1, dryRun = false, paths = [] }) {
      try {
        const { pruneTemp } = await import('./lib/tempfiles.mjs');
        const r = pruneTemp({
          dirs: Array.isArray(paths) ? paths.filter((p) => typeof p === 'string' && p.trim()) : [],
          maxAgeHours: Math.max(0.5, Number(days) || 1) * 24,
          dryRun: Boolean(dryRun),
        });
        return { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
      } catch (error) {
        return { content: [{ type: 'text', text: `清理失败：${error?.message ?? error}` }], isError: true };
      }
    },
  });
  ctx.tools.register(pruneTool);

  // 挂载时顺手清一次很老的临时文件（只删超过 tempKeepHours 的，失败不影响挂载）
  void (async () => {
    try {
      const { pruneTemp } = await import('./lib/tempfiles.mjs');
      const r = pruneTemp({ maxAgeHours: tempKeepHours, dryRun: false });
      if (r?.count) console.log(`[voice-emotion] 清理临时音频 ${r.count} 个（${Math.round(r.bytes / 1024)} KB）`);
    } catch { /* 忽略 */ }
  })();

  console.log(`[voice-emotion] 已挂载 v${version}（asr: ${asrUrl}，python: ${pyPath()}）`);
  return { name, version };
}

export default { name, inject, version, Config, apply };
